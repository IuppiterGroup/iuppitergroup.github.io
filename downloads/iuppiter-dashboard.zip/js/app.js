/* ============================================================
   IUPPITER DASHBOARD — app.js
   Main application: layout engine, drag-drop, all 13 widgets,
   settings, widget picker, theme, pages.
   No external dependencies. Chrome Extension MV3.
   ============================================================ */
'use strict';

// ============================================================
// CONSTANTS & DEFAULTS
// ============================================================
const VERSION = '1.0.0';
const STORAGE_KEY = 'iuppiter_dashboard';

const DEFAULT_LINKS = [
  { id: 'g1', url: 'https://google.com', label: 'Google' },
  { id: 'g2', url: 'https://gmail.com', label: 'Gmail' },
  { id: 'g3', url: 'https://github.com', label: 'GitHub' },
  { id: 'g4', url: 'https://youtube.com', label: 'YouTube' },
  { id: 'g5', url: 'https://reddit.com', label: 'Reddit' },
  { id: 'g6', url: 'https://twitter.com', label: 'X / Twitter' }
];

const DEFAULT_WIDGETS = [
  { instanceId: 'search-1',    widgetId: 'search',     size: 'full',   config: { engine: 'google' } },
  { instanceId: 'clock-1',     widgetId: 'clock',      size: 'small',  config: { format: '12h', showDate: true, showSeconds: true } },
  { instanceId: 'weather-1',   widgetId: 'weather',    size: 'medium', config: { city: 'New York', unit: 'f' } },
  { instanceId: 'quote-1',     widgetId: 'quote',      size: 'medium', config: {} },
  { instanceId: 'todo-1',      widgetId: 'todo',       size: 'small',  config: {} },
  { instanceId: 'quicklinks-1',widgetId: 'quicklinks', size: 'medium', config: { links: DEFAULT_LINKS } }
];

const DEFAULT_THEME = {
  bgType: 'gradient',
  bgColor1: '#0a0a0f',
  bgColor2: '#1a1a2e',
  bgGradientDir: '135deg',
  bgSolidColor: '#0a0a0f',
  bgImageUrl: '',
  accent: '#c9a227',
  widgetOpacity: 0.88,
  font: 'system',
  mode: 'dark'
};

const DEFAULT_STATE = {
  version: VERSION,
  userName: '',
  currentPageId: 'page-main',
  pages: [{ id: 'page-main', name: 'Home', widgets: DEFAULT_WIDGETS }],
  theme: { ...DEFAULT_THEME },
  widgetData: {}
};

// ============================================================
// STORAGE
// ============================================================
const Storage = {
  async load() {
    return new Promise(resolve => {
      try {
        chrome.storage.local.get(STORAGE_KEY, result => {
          resolve(result[STORAGE_KEY] || null);
        });
      } catch (e) {
        // Fallback if not in extension context
        try { resolve(JSON.parse(localStorage.getItem(STORAGE_KEY))); }
        catch (_) { resolve(null); }
      }
    });
  },
  async save(data) {
    return new Promise(resolve => {
      try {
        chrome.storage.local.set({ [STORAGE_KEY]: data }, resolve);
      } catch (e) {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
        catch (_) {}
        resolve();
      }
    });
  }
};

// ============================================================
// STATE
// ============================================================
let state = JSON.parse(JSON.stringify(DEFAULT_STATE));
let saveTimer = null;

function saveState() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => Storage.save(state), 400);
}

function currentPage() {
  return state.pages.find(p => p.id === state.currentPageId) || state.pages[0];
}

function getPageWidgets() {
  return currentPage()?.widgets || [];
}

// ============================================================
// THEME ENGINE
// ============================================================
const Theme = {
  apply(theme) {
    const root = document.documentElement;
    const t = theme || state.theme;
    // Background
    const bg = Theme.buildBackground(t);
    document.getElementById('bg-overlay').style.background = bg;
    document.getElementById('bg-overlay').style.backgroundSize = 'cover';
    document.getElementById('bg-overlay').style.backgroundPosition = 'center';
    // Accent
    root.style.setProperty('--accent', t.accent || '#c9a227');
    // Parse accent hex to RGB for dim
    const rgb = Theme.hexToRgb(t.accent || '#c9a227');
    root.style.setProperty('--accent-dim', `rgba(${rgb},0.15)`);
    // Opacity
    root.style.setProperty('--widget-opacity', t.widgetOpacity || 0.88);
    // Font
    const fontMap = {
      system: "system-ui, -apple-system, 'Segoe UI', sans-serif",
      inter: "'Inter', 'Roboto', sans-serif",
      georgia: "Georgia, 'Times New Roman', serif",
      palatino: "Palatino, 'Book Antiqua', serif",
      mono: "'Courier New', Courier, monospace"
    };
    root.style.setProperty('--font', fontMap[t.font] || fontMap.system);
    // Remove old font classes
    document.body.classList.remove('font-inter','font-georgia','font-palatino','font-mono');
    if (t.font && t.font !== 'system') document.body.classList.add('font-' + t.font);
    // Mode
    document.body.classList.toggle('light-mode', t.mode === 'light');
  },
  buildBackground(t) {
    if (t.bgType === 'image' && t.bgImageUrl) {
      return `url('${t.bgImageUrl}') center/cover no-repeat`;
    } else if (t.bgType === 'solid') {
      return t.bgSolidColor || '#0a0a0f';
    } else {
      const c1 = t.bgColor1 || '#0a0a0f';
      const c2 = t.bgColor2 || '#1a1a2e';
      const dir = t.bgGradientDir || '135deg';
      return `linear-gradient(${dir}, ${c1} 0%, ${c2} 50%, ${c1} 100%)`;
    }
  },
  hexToRgb(hex) {
    const r = parseInt(hex.slice(1,3),16);
    const g = parseInt(hex.slice(3,5),16);
    const b = parseInt(hex.slice(5,7),16);
    return `${r},${g},${b}`;
  }
};

// ============================================================
// GREETING
// ============================================================
function updateGreeting() {
  const el = document.getElementById('greeting-text');
  const h = new Date().getHours();
  let greet;
  if (h < 12) greet = 'Good morning';
  else if (h < 17) greet = 'Good afternoon';
  else if (h < 21) greet = 'Good evening';
  else greet = 'Good night';
  const name = state.userName ? `, ${state.userName}` : '';
  el.textContent = greet + name;
}

// ============================================================
// PAGE MANAGER
// ============================================================
const Pages = {
  render() {
    const container = document.getElementById('page-tabs');
    container.innerHTML = '';
    state.pages.forEach(p => {
      const tab = document.createElement('button');
      tab.className = 'page-tab' + (p.id === state.currentPageId ? ' active' : '');
      tab.setAttribute('role', 'tab');
      tab.setAttribute('aria-selected', p.id === state.currentPageId);
      tab.dataset.pageId = p.id;
      tab.innerHTML = `<span class="tab-name">${p.name}</span>` +
        (state.pages.length > 1 ? `<span class="tab-close" data-page-id="${p.id}" title="Remove page">×</span>` : '');
      tab.addEventListener('click', e => {
        if (e.target.classList.contains('tab-close')) {
          Pages.removePage(p.id);
        } else {
          Pages.switchTo(p.id);
        }
      });
      container.appendChild(tab);
    });
  },
  switchTo(pageId) {
    state.currentPageId = pageId;
    saveState();
    Pages.render();
    Grid.render();
  },
  addPage() {
    const name = prompt('Page name:', 'New Page');
    if (!name) return;
    const id = 'page-' + Date.now();
    state.pages.push({ id, name: name.trim(), widgets: [] });
    state.currentPageId = id;
    saveState();
    Pages.render();
    Grid.render();
  },
  removePage(pageId) {
    if (state.pages.length <= 1) { alert('Cannot remove the last page.'); return; }
    if (!confirm('Remove this page and all its widgets?')) return;
    state.pages = state.pages.filter(p => p.id !== pageId);
    if (state.currentPageId === pageId) state.currentPageId = state.pages[0].id;
    saveState();
    Pages.render();
    Grid.render();
  }
};

// ============================================================
// DRAG & DROP
// ============================================================
let dragSrcInstanceId = null;

function setupDragDrop(el, instanceId) {
  el.setAttribute('draggable', 'true');
  el.addEventListener('dragstart', e => {
    dragSrcInstanceId = instanceId;
    e.dataTransfer.effectAllowed = 'move';
    setTimeout(() => el.classList.add('dragging'), 0);
  });
  el.addEventListener('dragend', () => {
    el.classList.remove('dragging');
    document.querySelectorAll('.drag-over').forEach(x => x.classList.remove('drag-over'));
  });
  el.addEventListener('dragover', e => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragSrcInstanceId !== instanceId) el.classList.add('drag-over');
  });
  el.addEventListener('dragleave', e => {
    if (!el.contains(e.relatedTarget)) el.classList.remove('drag-over');
  });
  el.addEventListener('drop', e => {
    e.preventDefault();
    el.classList.remove('drag-over');
    if (dragSrcInstanceId && dragSrcInstanceId !== instanceId) {
      const page = currentPage();
      const ws = page.widgets;
      const aIdx = ws.findIndex(w => w.instanceId === dragSrcInstanceId);
      const bIdx = ws.findIndex(w => w.instanceId === instanceId);
      if (aIdx !== -1 && bIdx !== -1) {
        const tmp = ws[aIdx]; ws[aIdx] = ws[bIdx]; ws[bIdx] = tmp;
        saveState();
        Grid.render();
      }
    }
    dragSrcInstanceId = null;
  });
}

// ============================================================
// GRID / LAYOUT ENGINE
// ============================================================
const Grid = {
  intervals: {},

  render() {
    // Clear old intervals
    Object.values(this.intervals).forEach(clearInterval);
    this.intervals = {};

    const grid = document.getElementById('widget-grid');
    const empty = document.getElementById('empty-state');
    grid.innerHTML = '';

    const widgets = getPageWidgets();
    if (widgets.length === 0) {
      empty.classList.remove('hidden');
      grid.classList.add('hidden');
      return;
    }
    empty.classList.add('hidden');
    grid.classList.remove('hidden');

    widgets.forEach(w => {
      const el = this.createWidgetWrapper(w);
      grid.appendChild(el);
      this.initWidget(w, el);
    });
  },

  createWidgetWrapper(w) {
    const el = document.createElement('div');
    el.className = `widget-wrapper size-${w.size || 'medium'}`;
    el.dataset.instanceId = w.instanceId;

    const def = WidgetRegistry[w.widgetId];
    const title = def ? def.name : w.widgetId;

    el.innerHTML = `
      <div class="widget-header">
        <span class="widget-drag-handle" title="Drag to rearrange">⠿⠿</span>
        <span class="widget-title">${title}</span>
        <div class="widget-controls">
          <button class="widget-btn size-btn" title="Resize">⊞</button>
          ${def && def.getConfigFields && def.getConfigFields(w.config).length > 0
            ? `<button class="widget-btn config-btn" title="Widget settings">⚙</button>`
            : ''}
          <button class="widget-btn remove" title="Remove widget">×</button>
        </div>
      </div>
      <div class="widget-content"></div>
      <div class="size-menu">
        <button data-size="small">Small</button>
        <button data-size="medium">Medium</button>
        <button data-size="large">Large</button>
        <button data-size="full">Full Width</button>
      </div>`;

    // Size buttons
    el.querySelector('.size-btn').addEventListener('click', e => {
      e.stopPropagation();
      const menu = el.querySelector('.size-menu');
      menu.classList.toggle('open');
      // Mark current size
      menu.querySelectorAll('button').forEach(b => {
        b.classList.toggle('active', b.dataset.size === w.size);
      });
    });
    el.querySelector('.size-menu').addEventListener('click', e => {
      if (e.target.dataset.size) {
        w.size = e.target.dataset.size;
        el.className = `widget-wrapper size-${w.size}`;
        el.querySelector('.size-menu').classList.remove('open');
        saveState();
      }
    });
    // Close size menu on outside click
    document.addEventListener('click', e => {
      if (!el.contains(e.target)) el.querySelector('.size-menu')?.classList.remove('open');
    });

    // Remove button
    el.querySelector('.remove').addEventListener('click', e => {
      e.stopPropagation();
      if (confirm('Remove this widget?')) {
        const page = currentPage();
        page.widgets = page.widgets.filter(x => x.instanceId !== w.instanceId);
        saveState();
        Grid.render();
      }
    });

    // Config button
    const configBtn = el.querySelector('.config-btn');
    if (configBtn) {
      configBtn.addEventListener('click', e => {
        e.stopPropagation();
        WidgetConfig.open(w);
      });
    }

    setupDragDrop(el, w.instanceId);
    return el;
  },

  initWidget(w, el) {
    const def = WidgetRegistry[w.widgetId];
    if (!def) {
      el.querySelector('.widget-content').textContent = 'Unknown widget: ' + w.widgetId;
      return;
    }
    const content = el.querySelector('.widget-content');
    def.render(content, w, (interval) => {
      if (!this.intervals[w.instanceId]) this.intervals[w.instanceId] = [];
      if (Array.isArray(this.intervals[w.instanceId])) {
        this.intervals[w.instanceId].push(interval);
      } else {
        this.intervals[w.instanceId] = [interval];
      }
    });
  }
};

// ============================================================
// WIDGET REGISTRY
// ============================================================
const WidgetRegistry = {};

function registerWidget(def) {
  WidgetRegistry[def.id] = def;
}

// ============================================================
// WIDGET PICKER
// ============================================================
const WidgetPicker = {
  open() {
    const grid = document.getElementById('widget-picker-grid');
    grid.innerHTML = '';
    Object.values(WidgetRegistry).forEach(def => {
      const item = document.createElement('div');
      item.className = 'widget-picker-item';
      item.innerHTML = `
        <div class="widget-picker-icon">${def.icon}</div>
        <div class="widget-picker-name">${def.name}</div>
        <div class="widget-picker-desc">${def.description}</div>`;
      item.addEventListener('click', () => {
        WidgetPicker.addWidget(def.id);
        WidgetPicker.close();
      });
      grid.appendChild(item);
    });
    document.getElementById('widget-picker-overlay').classList.remove('hidden');
  },
  close() {
    document.getElementById('widget-picker-overlay').classList.add('hidden');
  },
  addWidget(widgetId) {
    const def = WidgetRegistry[widgetId];
    if (!def) return;
    const instanceId = widgetId + '-' + Date.now();
    const page = currentPage();
    page.widgets.push({
      instanceId,
      widgetId,
      size: def.defaultSize || 'medium',
      config: JSON.parse(JSON.stringify(def.defaultConfig || {}))
    });
    saveState();
    Grid.render();
  }
};

// ============================================================
// WIDGET CONFIG MODAL
// ============================================================
const WidgetConfig = {
  currentWidget: null,
  open(w) {
    const def = WidgetRegistry[w.widgetId];
    if (!def) return;
    this.currentWidget = w;
    document.getElementById('widget-config-title').textContent = def.name + ' Settings';
    const body = document.getElementById('widget-config-body');
    body.innerHTML = '';
    const fields = def.getConfigFields ? def.getConfigFields(w.config) : [];
    if (fields.length === 0) { body.innerHTML = '<p class="text-muted text-sm">No settings available.</p>'; }
    fields.forEach(f => {
      const wrap = document.createElement('label');
      wrap.textContent = f.label;
      let input;
      if (f.type === 'select') {
        input = document.createElement('select');
        f.options.forEach(opt => {
          const o = document.createElement('option');
          o.value = opt.value; o.textContent = opt.label;
          if (String(w.config[f.key]) === String(opt.value)) o.selected = true;
          input.appendChild(o);
        });
      } else if (f.type === 'textarea') {
        input = document.createElement('textarea');
        input.rows = 3;
        input.value = w.config[f.key] !== undefined ? w.config[f.key] : (f.default || '');
        input.placeholder = f.placeholder || '';
      } else if (f.type === 'checkbox') {
        const wrap2 = document.createElement('label');
        wrap2.style.flexDirection = 'row';
        wrap2.style.gap = '8px';
        wrap2.style.alignItems = 'center';
        input = document.createElement('input');
        input.type = 'checkbox';
        input.checked = !!w.config[f.key];
        wrap2.appendChild(input);
        wrap2.append(f.label);
        input.dataset.configKey = f.key;
        body.appendChild(wrap2);
        return;
      } else {
        input = document.createElement('input');
        input.type = f.type || 'text';
        input.value = w.config[f.key] !== undefined ? w.config[f.key] : (f.default || '');
        input.placeholder = f.placeholder || '';
      }
      input.dataset.configKey = f.key;
      wrap.appendChild(input);
      body.appendChild(wrap);
    });
    document.getElementById('widget-config-overlay').classList.remove('hidden');
  },
  save() {
    const w = this.currentWidget;
    if (!w) return;
    const body = document.getElementById('widget-config-body');
    body.querySelectorAll('[data-config-key]').forEach(el => {
      const key = el.dataset.configKey;
      if (el.type === 'checkbox') w.config[key] = el.checked;
      else if (el.type === 'number') w.config[key] = Number(el.value);
      else w.config[key] = el.value;
    });
    saveState();
    Grid.render();
    document.getElementById('widget-config-overlay').classList.add('hidden');
  },
  close() {
    document.getElementById('widget-config-overlay').classList.add('hidden');
    this.currentWidget = null;
  }
};

// ============================================================
// SETTINGS PANEL
// ============================================================
const SettingsPanel = {
  open() {
    const t = state.theme;
    const el = id => document.getElementById(id);
    el('setting-name').value = state.userName || '';
    el('setting-accent').value = t.accent || '#c9a227';
    el('setting-opacity').value = t.widgetOpacity || 0.88;
    el('opacity-val').textContent = Math.round((t.widgetOpacity || 0.88) * 100) + '%';
    el('setting-font').value = t.font || 'system';
    el('setting-mode').value = t.mode || 'dark';
    // Background
    document.querySelectorAll('input[name="bg-type"]').forEach(r => {
      r.checked = r.value === (t.bgType || 'gradient');
    });
    el('bg-color1').value = t.bgColor1 || '#0a0a0f';
    el('bg-color2').value = t.bgColor2 || '#1a1a2e';
    el('bg-gradient-dir').value = t.bgGradientDir || '135deg';
    el('bg-solid-color').value = t.bgSolidColor || '#0a0a0f';
    el('bg-image-url').value = t.bgImageUrl || '';
    SettingsPanel.updateBgControls(t.bgType || 'gradient');
    // Pages
    SettingsPanel.renderPages();
    el('settings-overlay').classList.remove('hidden');
  },
  close() {
    document.getElementById('settings-overlay').classList.add('hidden');
  },
  updateBgControls(type) {
    const el = id => document.getElementById(id);
    el('bg-gradient-controls').classList.toggle('hidden', type !== 'gradient');
    el('bg-solid-controls').classList.toggle('hidden', type !== 'solid');
    el('bg-image-controls').classList.toggle('hidden', type !== 'image');
  },
  save() {
    const el = id => document.getElementById(id);
    state.userName = el('setting-name').value.trim();
    state.theme.accent = el('setting-accent').value;
    state.theme.widgetOpacity = parseFloat(el('setting-opacity').value);
    state.theme.font = el('setting-font').value;
    state.theme.mode = el('setting-mode').value;
    state.theme.bgType = document.querySelector('input[name="bg-type"]:checked')?.value || 'gradient';
    state.theme.bgColor1 = el('bg-color1').value;
    state.theme.bgColor2 = el('bg-color2').value;
    state.theme.bgGradientDir = el('bg-gradient-dir').value;
    state.theme.bgSolidColor = el('bg-solid-color').value;
    state.theme.bgImageUrl = el('bg-image-url').value.trim();
    saveState();
    Theme.apply();
    updateGreeting();
    SettingsPanel.close();
  },
  reset() {
    if (!confirm('Reset all settings to defaults?')) return;
    state.theme = JSON.parse(JSON.stringify(DEFAULT_THEME));
    state.userName = '';
    saveState();
    Theme.apply();
    updateGreeting();
    SettingsPanel.open();
  },
  renderPages() {
    const container = document.getElementById('pages-list');
    container.innerHTML = '';
    state.pages.forEach(p => {
      const row = document.createElement('div');
      row.className = 'page-setting-item';
      const inp = document.createElement('input');
      inp.type = 'text';
      inp.value = p.name;
      inp.addEventListener('blur', () => { p.name = inp.value.trim() || p.name; saveState(); Pages.render(); });
      const del = document.createElement('button');
      del.className = 'danger-btn';
      del.textContent = '🗑';
      del.title = 'Delete page';
      del.addEventListener('click', () => Pages.removePage(p.id));
      row.appendChild(inp);
      if (state.pages.length > 1) row.appendChild(del);
      container.appendChild(row);
    });
  }
};

// ============================================================
// WIDGET: CLOCK
// ============================================================
registerWidget({
  id: 'clock',
  name: 'Clock',
  icon: '🕐',
  description: 'Digital clock with date and day of week',
  defaultSize: 'small',
  defaultConfig: { format: '12h', showDate: true, showSeconds: true, analog: false },
  getConfigFields(config) {
    return [
      { key: 'format', label: 'Time Format', type: 'select', options: [
        { value: '12h', label: '12-hour (AM/PM)' },
        { value: '24h', label: '24-hour' }
      ]},
      { key: 'showDate', label: 'Show Date', type: 'checkbox' },
      { key: 'showSeconds', label: 'Show Seconds', type: 'checkbox' },
      { key: 'analog', label: 'Analog Clock', type: 'checkbox' }
    ];
  },
  render(container, w, addInterval) {
    const c = w.config;
    if (c.analog) {
      container.innerHTML = `<div class="clock-widget">
        <canvas class="clock-canvas" width="160" height="160"></canvas>
        <div class="clock-date" id="clock-date-${w.instanceId}"></div>
        <div class="clock-day" id="clock-day-${w.instanceId}"></div>
      </div>`;
      const canvas = container.querySelector('canvas');
      const tick = () => {
        this._drawAnalog(canvas, w);
        if (c.showDate) {
          const now = new Date();
          const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
          const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
          const dateEl = document.getElementById(`clock-date-${w.instanceId}`);
          const dayEl = document.getElementById(`clock-day-${w.instanceId}`);
          if (dateEl) dateEl.textContent = `${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
          if (dayEl) dayEl.textContent = days[now.getDay()];
        }
      };
      tick();
      addInterval(setInterval(tick, 1000));
    } else {
      container.innerHTML = `<div class="clock-widget">
        <div class="clock-time" id="clock-time-${w.instanceId}">--:--</div>
        <div class="clock-date" id="clock-date-${w.instanceId}"></div>
        <div class="clock-day" id="clock-day-${w.instanceId}"></div>
      </div>`;
      const tick = () => {
        const now = new Date();
        const timeEl = document.getElementById(`clock-time-${w.instanceId}`);
        const dateEl = document.getElementById(`clock-date-${w.instanceId}`);
        const dayEl = document.getElementById(`clock-day-${w.instanceId}`);
        if (!timeEl) return;
        const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
        const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        let h = now.getHours(), m = now.getMinutes(), s = now.getSeconds();
        let ampm = '';
        if (c.format !== '24h') {
          ampm = h >= 12 ? 'PM' : 'AM';
          h = h % 12 || 12;
        }
        const pad = n => String(n).padStart(2,'0');
        const timeStr = `${pad(h)}:${pad(m)}${c.showSeconds ? ':'+pad(s) : ''}`;
        timeEl.innerHTML = timeStr + (ampm ? `<span class="clock-ampm">${ampm}</span>` : '');
        if (c.showDate && dateEl) dateEl.textContent = `${months[now.getMonth()]} ${now.getDate()}, ${now.getFullYear()}`;
        if (c.showDate && dayEl) dayEl.textContent = days[now.getDay()];
      };
      tick();
      addInterval(setInterval(tick, 1000));
    }
  },
  _drawAnalog(canvas, w) {
    const ctx = canvas.getContext('2d');
    const cx = canvas.width / 2, cy = canvas.height / 2, r = cx - 8;
    const now = new Date();
    const h = now.getHours() % 12, m = now.getMinutes(), s = now.getSeconds();
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#c9a227';
    const textColor = getComputedStyle(document.documentElement).getPropertyValue('--text').trim() || '#e8e8e8';
    ctx.clearRect(0,0,canvas.width,canvas.height);
    // Face
    ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2);
    ctx.fillStyle = 'rgba(255,255,255,0.04)'; ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.15)'; ctx.lineWidth=1.5; ctx.stroke();
    // Hour marks
    for(let i=0;i<12;i++){
      const a = (i/12)*Math.PI*2 - Math.PI/2;
      const x1=cx+Math.cos(a)*(r-4), y1=cy+Math.sin(a)*(r-4);
      const x2=cx+Math.cos(a)*(r-10), y2=cy+Math.sin(a)*(r-10);
      ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2);
      ctx.strokeStyle=i%3===0?accent:'rgba(255,255,255,0.2)'; ctx.lineWidth=i%3===0?2:1; ctx.stroke();
    }
    // Hands
    const drawHand = (angle, length, width, color) => {
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(angle)*length, cy + Math.sin(angle)*length);
      ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineCap='round'; ctx.stroke();
    };
    const hourAngle = ((h + m/60)/12)*Math.PI*2 - Math.PI/2;
    const minAngle = (m/60)*Math.PI*2 - Math.PI/2;
    const secAngle = (s/60)*Math.PI*2 - Math.PI/2;
    drawHand(hourAngle, r*0.5, 3, textColor);
    drawHand(minAngle, r*0.75, 2, textColor);
    drawHand(secAngle, r*0.85, 1, accent);
    // Center dot
    ctx.beginPath(); ctx.arc(cx,cy,3,0,Math.PI*2);
    ctx.fillStyle = accent; ctx.fill();
  }
});

// ============================================================
// WIDGET: WEATHER
// ============================================================
registerWidget({
  id: 'weather',
  name: 'Weather',
  icon: '🌤',
  description: 'Current weather + 3-day forecast via wttr.in',
  defaultSize: 'medium',
  defaultConfig: { city: 'New York', unit: 'f' },
  getConfigFields(config) {
    return [
      { key: 'city', label: 'City', type: 'text', placeholder: 'New York' },
      { key: 'unit', label: 'Temperature Unit', type: 'select', options: [
        { value: 'f', label: 'Fahrenheit (°F)' },
        { value: 'c', label: 'Celsius (°C)' }
      ]}
    ];
  },
  render(container, w, addInterval) {
    container.innerHTML = `<div class="weather-widget">
      <div class="weather-loading" style="color:var(--text-muted);text-align:center;padding:20px;font-size:0.85rem;">Loading weather…</div>
    </div>`;
    const load = () => this._fetchWeather(container, w.config);
    load();
    addInterval(setInterval(load, 10 * 60 * 1000)); // Refresh every 10 min
  },
  async _fetchWeather(container, config) {
    const city = encodeURIComponent(config.city || 'New York');
    const isF = config.unit !== 'c';
    const url = `https://wttr.in/${city}?format=j1`;
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      const cur = data.current_condition[0];
      const temp = isF ? cur.temp_F : cur.temp_C;
      const desc = cur.weatherDesc[0].value;
      const feels = isF ? cur.FeelsLikeF : cur.FeelsLikeC;
      const wind = cur.windspeedKmph;
      const humidity = cur.humidity;
      const weatherCode = parseInt(cur.weatherCode);
      const icon = this._weatherIcon(weatherCode);

      const days = data.weather.slice(0,3);
      const dayNames = ['Today','Tomorrow'];
      const dow = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
      const today = new Date().getDay();

      let forecastHtml = days.map((d, i) => {
        const lo = isF ? d.mintempF : d.mintempC;
        const hi = isF ? d.maxtempF : d.maxtempC;
        const dayCode = parseInt(d.hourly[4]?.weatherCode || d.hourly[3]?.weatherCode || 113);
        const name = i < 2 ? dayNames[i] : dow[(today + i) % 7];
        return `<div class="forecast-day">
          <div>${name}</div>
          <span class="f-icon">${this._weatherIcon(dayCode)}</span>
          <div class="f-temps">${hi}° / ${lo}°</div>
        </div>`;
      }).join('');

      const unit = isF ? '°F' : '°C';
      container.innerHTML = `<div class="weather-widget">
        <div class="weather-city">${decodeURIComponent(city)}</div>
        <div class="weather-current">
          <div class="weather-icon">${icon}</div>
          <div class="weather-main">
            <h2>${temp}${unit}</h2>
            <p class="weather-desc">${desc}</p>
            <p style="font-size:0.72rem;color:var(--text-muted)">Feels ${feels}${unit} · Wind ${wind}km/h · Humidity ${humidity}%</p>
          </div>
        </div>
        <div class="weather-forecast">${forecastHtml}</div>
      </div>`;
    } catch(e) {
      container.innerHTML = `<div class="weather-widget">
        <div class="weather-error">⚠ Could not load weather for "${config.city}".<br>
        <small style="color:var(--text-dim)">Check city name in widget settings.</small>
        <br><button onclick="App.refreshWidget('weather')" style="margin-top:8px;padding:4px 12px;border-radius:6px;border:1px solid var(--widget-border);background:none;color:var(--accent);cursor:pointer;font-size:0.8rem">Retry</button></div>
      </div>`;
    }
  },
  _weatherIcon(code) {
    if (code === 113) return '☀️';
    if (code === 116) return '⛅';
    if ([119,122].includes(code)) return '☁️';
    if ([143,248,260].includes(code)) return '🌫️';
    if ([176,293,296,299,302,305,308,353,356,359].includes(code)) return '🌧️';
    if ([179,182,185,227,230,281,284,311,314,317,320,323,326,329,332,335,338,350,362,365,368,371,374,377].includes(code)) return '❄️';
    if ([200,386,389,392,395].includes(code)) return '⛈️';
    return '🌡️';
  }
});

// ============================================================
// WIDGET: QUICK LINKS
// ============================================================
registerWidget({
  id: 'quicklinks',
  name: 'Quick Links',
  icon: '🔗',
  description: 'Customizable shortcut grid with favicons',
  defaultSize: 'medium',
  defaultConfig: { links: [...DEFAULT_LINKS] },
  getConfigFields(config) { return []; }, // Managed inline
  render(container, w, addInterval) {
    this._render(container, w);
  },
  _render(container, w) {
    const c = w.config;
    if (!c.links) c.links = [...DEFAULT_LINKS];
    const links = c.links;
    let html = `<div class="quicklinks-widget">
      <div class="links-grid" id="links-grid-${w.instanceId}">`;
    links.forEach(lnk => {
      const domain = this._domain(lnk.url);
      const favicon = `https://www.google.com/s2/favicons?domain=${domain}&sz=32`;
      html += `<a class="link-item" href="${lnk.url}" target="_blank" rel="noopener" data-link-id="${lnk.id}">
        <img class="link-favicon" src="${favicon}" alt="" loading="lazy" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 32 32%22><rect width=%2232%22 height=%2232%22 rx=%226%22 fill=%22%23333%22/><text x=%2216%22 y=%2222%22 text-anchor=%22middle%22 font-size=%2218%22 fill=%22%23888%22>🔗</text></svg>'">
        <span class="link-label">${lnk.label}</span>
        <span class="link-remove" data-link-id="${lnk.id}">×</span>
      </a>`;
    });
    html += `<button class="link-add-btn" id="link-add-${w.instanceId}">
      <span>+</span><span class="link-add-label">Add</span>
    </button></div></div>`;
    container.innerHTML = html;
    // Remove link buttons
    container.querySelectorAll('.link-remove').forEach(btn => {
      btn.addEventListener('click', e => {
        e.preventDefault(); e.stopPropagation();
        const lid = btn.dataset.linkId;
        c.links = c.links.filter(l => l.id !== lid);
        saveState();
        this._render(container, w);
      });
    });
    // Hover to show remove
    container.querySelectorAll('.link-item').forEach(el => {
      el.addEventListener('mouseenter', () => el.querySelector('.link-remove').style.display='flex');
      el.addEventListener('mouseleave', () => el.querySelector('.link-remove').style.display='none');
    });
    // Add link
    document.getElementById(`link-add-${w.instanceId}`)?.addEventListener('click', () => {
      this._showAddForm(container, w);
    });
  },
  _showAddForm(container, w) {
    const grid = container.querySelector('.quicklinks-widget');
    const existingForm = grid.querySelector('.add-link-form');
    if (existingForm) { existingForm.remove(); return; }
    const form = document.createElement('div');
    form.className = 'add-link-form';
    form.style.cssText = 'padding:10px;background:var(--input-bg);border-radius:8px;display:flex;flex-direction:column;gap:6px;margin-top:8px;';
    form.innerHTML = `
      <input type="text" id="al-url-${w.instanceId}" placeholder="https://example.com" style="width:100%">
      <input type="text" id="al-label-${w.instanceId}" placeholder="Label" style="width:100%">
      <div style="display:flex;gap:6px;">
        <button id="al-save-${w.instanceId}" style="flex:1;background:var(--accent);color:#000;border-radius:6px;padding:6px;font-weight:600;border:none;cursor:pointer">Add</button>
        <button id="al-cancel-${w.instanceId}" style="flex:1;background:var(--input-bg);color:var(--text-muted);border-radius:6px;padding:6px;border:1px solid var(--input-border);cursor:pointer">Cancel</button>
      </div>`;
    grid.appendChild(form);
    document.getElementById(`al-save-${w.instanceId}`)?.addEventListener('click', () => {
      const url = document.getElementById(`al-url-${w.instanceId}`)?.value.trim();
      const label = document.getElementById(`al-label-${w.instanceId}`)?.value.trim();
      if (!url) return;
      if (!w.config.links) w.config.links = [];
      w.config.links.push({ id: 'l-'+Date.now(), url, label: label || this._domain(url) });
      saveState();
      this._render(container, w);
    });
    document.getElementById(`al-cancel-${w.instanceId}`)?.addEventListener('click', () => {
      form.remove();
    });
  },
  _domain(url) {
    try { return new URL(url).hostname.replace('www.',''); } catch(_) { return url; }
  }
});

// ============================================================
// WIDGET: NOTES
// ============================================================
registerWidget({
  id: 'notes',
  name: 'Notes',
  icon: '📝',
  description: 'Sticky notes with colors, fully editable',
  defaultSize: 'medium',
  defaultConfig: { notes: [{ id: 'n1', text: 'Click to edit...', color: '#fef08a' }] },
  getConfigFields(config) { return []; },
  render(container, w, addInterval) {
    this._render(container, w);
  },
  _render(container, w) {
    const notes = w.config.notes || [];
    const colors = ['#fef08a','#bbf7d0','#bfdbfe','#fecaca','#e9d5ff','#fed7aa'];
    let html = '<div class="notes-widget">';
    notes.forEach(n => {
      html += `<div class="note-card" style="background:${n.color};color:#1a1a1a;" data-note-id="${n.id}">
        <textarea data-note-id="${n.id}" style="color:#1a1a1a;font-family:inherit;font-size:0.85rem;">${n.text || ''}</textarea>
        <div class="note-controls">
          ${colors.map(c => `<div class="note-color-dot ${c===n.color?'active':''}" data-color="${c}" data-note-id="${n.id}" style="background:${c}"></div>`).join('')}
          <span class="note-delete" data-note-id="${n.id}" title="Delete note">🗑</span>
        </div>
      </div>`;
    });
    html += `<button class="note-add-btn" id="note-add-${w.instanceId}">+ Add Note</button></div>`;
    container.innerHTML = html;

    // Textarea changes
    container.querySelectorAll('textarea[data-note-id]').forEach(ta => {
      ta.addEventListener('input', () => {
        const note = w.config.notes.find(n => n.id === ta.dataset.noteId);
        if (note) { note.text = ta.value; saveState(); }
      });
    });
    // Color dots
    container.querySelectorAll('.note-color-dot').forEach(dot => {
      dot.addEventListener('click', () => {
        const note = w.config.notes.find(n => n.id === dot.dataset.noteId);
        if (note) { note.color = dot.dataset.color; saveState(); this._render(container, w); }
      });
    });
    // Delete
    container.querySelectorAll('.note-delete').forEach(btn => {
      btn.addEventListener('click', () => {
        w.config.notes = w.config.notes.filter(n => n.id !== btn.dataset.noteId);
        saveState(); this._render(container, w);
      });
    });
    // Add
    document.getElementById(`note-add-${w.instanceId}`)?.addEventListener('click', () => {
      w.config.notes = w.config.notes || [];
      w.config.notes.push({ id: 'n-'+Date.now(), text: '', color: colors[w.config.notes.length % colors.length] });
      saveState(); this._render(container, w);
    });
  }
});

// ============================================================
// WIDGET: TODO LIST
// ============================================================
registerWidget({
  id: 'todo',
  name: 'Todo List',
  icon: '✅',
  description: 'Tasks with checkboxes. Persists across sessions.',
  defaultSize: 'small',
  defaultConfig: { tasks: [] },
  getConfigFields(config) { return []; },
  render(container, w, addInterval) {
    this._render(container, w);
  },
  _render(container, w) {
    const tasks = w.config.tasks || [];
    let html = `<div class="todo-widget">
      <div class="todo-add">
        <input type="text" id="todo-input-${w.instanceId}" placeholder="New task…" maxlength="200">
        <button id="todo-add-${w.instanceId}">Add</button>
      </div>
      <div class="todo-list">`;
    if (tasks.length === 0) html += `<div class="todo-empty">No tasks yet! Add one above.</div>`;
    tasks.forEach(t => {
      html += `<div class="todo-item ${t.done?'done':''}" data-task-id="${t.id}">
        <input type="checkbox" ${t.done?'checked':''} data-task-id="${t.id}">
        <span class="todo-text" data-task-id="${t.id}">${t.text}</span>
        <span class="todo-delete" data-task-id="${t.id}" title="Delete">×</span>
      </div>`;
    });
    html += '</div></div>';
    container.innerHTML = html;

    const addTask = () => {
      const input = document.getElementById(`todo-input-${w.instanceId}`);
      const text = input?.value.trim();
      if (!text) return;
      w.config.tasks = w.config.tasks || [];
      w.config.tasks.push({ id: 't-'+Date.now(), text, done: false });
      input.value = '';
      saveState(); this._render(container, w);
    };
    document.getElementById(`todo-add-${w.instanceId}`)?.addEventListener('click', addTask);
    document.getElementById(`todo-input-${w.instanceId}`)?.addEventListener('keypress', e => {
      if (e.key === 'Enter') addTask();
    });
    container.querySelectorAll('input[type="checkbox"][data-task-id]').forEach(cb => {
      cb.addEventListener('change', () => {
        const task = w.config.tasks.find(t => t.id === cb.dataset.taskId);
        if (task) { task.done = cb.checked; saveState(); this._render(container, w); }
      });
    });
    container.querySelectorAll('.todo-delete').forEach(btn => {
      btn.addEventListener('click', () => {
        w.config.tasks = w.config.tasks.filter(t => t.id !== btn.dataset.taskId);
        saveState(); this._render(container, w);
      });
    });
  }
});

// ============================================================
// WIDGET: STOCK TICKER
// ============================================================
registerWidget({
  id: 'stocks',
  name: 'Stock Ticker',
  icon: '📈',
  description: 'Live stock prices via Yahoo Finance',
  defaultSize: 'small',
  defaultConfig: { symbols: 'AAPL,MSFT,NVDA,SPY' },
  getConfigFields(config) {
    return [
      { key: 'symbols', label: 'Ticker Symbols (comma-separated)', type: 'text', placeholder: 'AAPL,MSFT,NVDA', default: 'AAPL,MSFT,NVDA,SPY' }
    ];
  },
  render(container, w, addInterval) {
    container.innerHTML = `<div class="stocks-widget"><div class="text-muted text-sm" style="padding:10px">Loading quotes…</div></div>`;
    const load = () => this._fetch(container, w.config);
    load();
    addInterval(setInterval(load, 60 * 1000)); // Refresh every minute
  },
  async _fetch(container, config) {
    const symbols = (config.symbols || 'AAPL,MSFT').split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
    const url = `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symbols.join(',')}`;
    try {
      const res = await fetch(url, { headers: { 'Accept': 'application/json' }});
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      const quotes = data.quoteResponse?.result || [];
      if (quotes.length === 0) throw new Error('No data');
      let html = '<div class="stocks-widget"><div class="stocks-list">';
      quotes.forEach(q => {
        const price = q.regularMarketPrice?.toFixed(2) ?? '—';
        const change = q.regularMarketChange?.toFixed(2) ?? 0;
        const pct = q.regularMarketChangePercent?.toFixed(2) ?? 0;
        const dir = change >= 0 ? 'up' : 'down';
        const arrow = change >= 0 ? '▲' : '▼';
        html += `<div class="stock-row">
          <span class="stock-symbol">${q.symbol}</span>
          <span class="stock-price">$${price}</span>
          <span class="stock-change ${dir}">${arrow} ${Math.abs(change)} (${Math.abs(pct)}%)</span>
        </div>`;
      });
      const now = new Date();
      html += `</div><div class="stocks-refresh" onclick="this.closest('.stocks-widget').dispatchEvent(new CustomEvent('stocks-refresh'))">↻ Updated ${now.getHours()}:${String(now.getMinutes()).padStart(2,'0')}</div></div>`;
      container.innerHTML = html;
    } catch(e) {
      container.innerHTML = `<div class="stocks-widget">
        <div class="text-muted text-sm" style="padding:10px">
          Could not load quotes.<br>
          <span class="text-xs" style="color:var(--text-dim)">Yahoo Finance may require a browser refresh or the market is closed.</span>
        </div>
      </div>`;
    }
  }
});

// ============================================================
// WIDGET: NEWS FEED
// ============================================================
registerWidget({
  id: 'news',
  name: 'News Feed',
  icon: '📰',
  description: 'Headlines from RSS feeds. Add custom sources.',
  defaultSize: 'medium',
  defaultConfig: {
    feeds: 'https://feeds.reuters.com/reuters/topNews',
    maxItems: 8
  },
  getConfigFields(config) {
    return [
      { key: 'feeds', label: 'RSS Feed URL(s) (one per line or comma-separated)', type: 'textarea',
        placeholder: 'https://feeds.reuters.com/reuters/topNews',
        default: 'https://feeds.reuters.com/reuters/topNews' },
      { key: 'maxItems', label: 'Max Headlines', type: 'number', default: 8 }
    ];
  },
  render(container, w, addInterval) {
    container.innerHTML = `<div class="news-widget"><div class="news-loading">Loading news…</div></div>`;
    const load = () => this._fetch(container, w.config);
    load();
    addInterval(setInterval(load, 15 * 60 * 1000));
  },
  async _fetch(container, config) {
    const max = parseInt(config.maxItems) || 8;
    const feedStr = config.feeds || 'https://feeds.reuters.com/reuters/topNews';
    const feedUrls = feedStr.split(/[\n,]+/).map(s=>s.trim()).filter(Boolean);
    let items = [];
    for (const feedUrl of feedUrls.slice(0, 3)) {
      try {
        const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(feedUrl)}`;
        const res = await fetch(proxyUrl);
        const text = await res.text();
        const parser = new DOMParser();
        const doc = parser.parseFromString(text, 'text/xml');
        const feedItems = Array.from(doc.querySelectorAll('item')).slice(0, Math.ceil(max / feedUrls.length));
        const source = doc.querySelector('channel > title')?.textContent || 'News';
        feedItems.forEach(item => {
          const title = item.querySelector('title')?.textContent?.trim() || '';
          const link = item.querySelector('link')?.textContent?.trim() || item.querySelector('guid')?.textContent || '#';
          if (title) items.push({ title, link, source });
        });
      } catch(e) { /* Skip failed feeds */ }
    }
    if (items.length === 0) {
      container.innerHTML = `<div class="news-widget"><div class="news-error">⚠ Could not load news.<br><small>Check your feed URLs in widget settings.</small></div></div>`;
      return;
    }
    items = items.slice(0, max);
    let html = '<div class="news-widget"><div class="news-list">';
    items.forEach(item => {
      html += `<div class="news-item" onclick="window.open('${item.link.replace(/'/g,"\\'")}','_blank')">
        <span class="news-bullet">●</span>
        <div>
          <div class="news-title">${item.title}</div>
          <div class="news-source">${item.source}</div>
        </div>
      </div>`;
    });
    html += '</div></div>';
    container.innerHTML = html;
  }
});

// ============================================================
// WIDGET: BOOKMARKS
// ============================================================
registerWidget({
  id: 'bookmarks',
  name: 'Bookmarks Bar',
  icon: '⭐',
  description: 'Quick access to your Chrome bookmarks',
  defaultSize: 'medium',
  defaultConfig: { folder: '' },
  getConfigFields(config) { return []; },
  render(container, w, addInterval) {
    container.innerHTML = '<div class="bookmarks-widget"><div class="text-muted text-sm" style="padding:8px">Loading bookmarks…</div></div>';
    try {
      chrome.bookmarks.getTree(tree => {
        this._renderTree(container, tree, w.config);
      });
    } catch(e) {
      container.innerHTML = '<div class="bookmarks-widget"><div class="text-muted text-sm" style="padding:8px">Bookmarks unavailable in this context.</div></div>';
    }
  },
  _renderTree(container, tree, config) {
    const bookmarks = [];
    const walk = (nodes, depth) => {
      nodes.forEach(node => {
        if (depth > 0 && node.url) {
          bookmarks.push({ title: node.title, url: node.url });
        } else if (node.children) {
          if (depth > 0 && node.title) {
            bookmarks.push({ title: node.title, isFolder: true });
          }
          walk(node.children, depth + 1);
        }
      });
    };
    walk(tree, 0);
    const maxItems = 20;
    let html = '<div class="bookmarks-widget"><div class="bookmark-list">';
    bookmarks.slice(0, maxItems).forEach(b => {
      if (b.isFolder) {
        html += `<div class="bookmark-folder">${b.title}</div>`;
      } else {
        const domain = (() => { try { return new URL(b.url).hostname; } catch(_) { return ''; } })();
        const favicon = domain ? `https://www.google.com/s2/favicons?domain=${domain}&sz=16` : '';
        html += `<a class="bookmark-item" href="${b.url}" target="_blank" rel="noopener">
          ${favicon ? `<img class="bookmark-favicon" src="${favicon}" alt="" loading="lazy">` : ''}
          <span class="bookmark-title">${b.title || b.url}</span>
        </a>`;
      }
    });
    html += '</div></div>';
    container.innerHTML = html;
  }
});

// ============================================================
// WIDGET: SEARCH BAR
// ============================================================
registerWidget({
  id: 'search',
  name: 'Search Bar',
  icon: '🔍',
  description: 'Google, DuckDuckGo, or Bing search',
  defaultSize: 'full',
  defaultConfig: { engine: 'google' },
  getConfigFields(config) {
    return [
      { key: 'engine', label: 'Default Search Engine', type: 'select', options: [
        { value: 'google', label: 'Google' },
        { value: 'duckduckgo', label: 'DuckDuckGo' },
        { value: 'bing', label: 'Bing' },
        { value: 'brave', label: 'Brave Search' },
        { value: 'perplexity', label: 'Perplexity AI' }
      ]}
    ];
  },
  render(container, w, addInterval) {
    const engineUrls = {
      google: 'https://www.google.com/search?q=',
      duckduckgo: 'https://duckduckgo.com/?q=',
      bing: 'https://www.bing.com/search?q=',
      brave: 'https://search.brave.com/search?q=',
      perplexity: 'https://www.perplexity.ai/search?q='
    };
    const engineNames = { google:'Google', duckduckgo:'DuckDuckGo', bing:'Bing', brave:'Brave', perplexity:'Perplexity' };
    let current = w.config.engine || 'google';
    const renderSearch = () => {
      container.innerHTML = `<div class="search-widget">
        <form id="search-form-${w.instanceId}">
          <div class="search-form">
            <input type="text" class="search-input" id="search-input-${w.instanceId}" placeholder="Search ${engineNames[current]}…" autocomplete="off" autofocus>
            <button type="submit" class="search-btn">Search</button>
          </div>
        </form>
        <div class="search-engine-selector">
          ${Object.keys(engineUrls).map(e => `<button class="engine-btn ${e===current?'active':''}" data-engine="${e}">${engineNames[e]}</button>`).join('')}
        </div>
      </div>`;
      document.getElementById(`search-form-${w.instanceId}`)?.addEventListener('submit', e => {
        e.preventDefault();
        const q = document.getElementById(`search-input-${w.instanceId}`)?.value.trim();
        if (q) window.open(engineUrls[current] + encodeURIComponent(q), '_blank');
      });
      container.querySelectorAll('.engine-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          current = btn.dataset.engine;
          w.config.engine = current;
          saveState();
          renderSearch();
        });
      });
    };
    renderSearch();
  }
});

// ============================================================
// WIDGET: DAILY QUOTE
// ============================================================
registerWidget({
  id: 'quote',
  name: 'Daily Quote',
  icon: '💬',
  description: '200+ embedded historical & inspirational quotes',
  defaultSize: 'medium',
  defaultConfig: { quoteIndex: -1 },
  getConfigFields(config) { return []; },
  render(container, w, addInterval) {
    if (!QUOTES || QUOTES.length === 0) {
      container.innerHTML = '<div class="quote-widget"><p>No quotes loaded.</p></div>';
      return;
    }
    // Pick a daily quote (same quote all day, rotates daily)
    const dayKey = new Date().toDateString();
    let idx = w.config.quoteIndex;
    if (idx === -1) {
      // Deterministic daily quote
      idx = Math.abs(this._hashCode(dayKey)) % QUOTES.length;
      w.config.quoteIndex = idx;
    }
    this._showQuote(container, w, idx);
  },
  _showQuote(container, w, idx) {
    const q = QUOTES[idx];
    container.innerHTML = `<div class="quote-widget">
      <div class="quote-marks">"</div>
      <div class="quote-text">"${q.text}"</div>
      <div class="quote-author">— ${q.author}</div>
      <button class="quote-refresh" title="New quote" id="quote-refresh-${w.instanceId}">↻</button>
    </div>`;
    document.getElementById(`quote-refresh-${w.instanceId}`)?.addEventListener('click', () => {
      const next = Math.floor(Math.random() * QUOTES.length);
      w.config.quoteIndex = next;
      saveState();
      this._showQuote(container, w, next);
    });
  },
  _hashCode(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return hash;
  }
});

// ============================================================
// WIDGET: CALENDAR
// ============================================================
registerWidget({
  id: 'calendar',
  name: 'Calendar',
  icon: '📅',
  description: 'Month view calendar highlighting today',
  defaultSize: 'small',
  defaultConfig: { viewYear: null, viewMonth: null },
  getConfigFields(config) { return []; },
  render(container, w, addInterval) {
    const now = new Date();
    let year = w.config.viewYear ?? now.getFullYear();
    let month = w.config.viewMonth ?? now.getMonth();
    this._renderCalendar(container, w, year, month);
  },
  _renderCalendar(container, w, year, month) {
    const today = new Date();
    const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    const dayNames = ['Su','Mo','Tu','We','Th','Fr','Sa'];
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month+1, 0).getDate();
    const daysInPrev = new Date(year, month, 0).getDate();

    let gridHtml = dayNames.map(d => `<div class="cal-day-name">${d}</div>`).join('');
    // Previous month filler
    for (let i = 0; i < firstDay; i++) {
      gridHtml += `<div class="cal-day other-month">${daysInPrev - firstDay + i + 1}</div>`;
    }
    // Current month
    for (let d = 1; d <= daysInMonth; d++) {
      const isToday = d === today.getDate() && month === today.getMonth() && year === today.getFullYear();
      const dow = (firstDay + d - 1) % 7;
      const isWeekend = dow === 0 || dow === 6;
      gridHtml += `<div class="cal-day ${isToday?'today':''} ${isWeekend&&!isToday?'weekend':''}">${d}</div>`;
    }
    // Next month filler
    const total = firstDay + daysInMonth;
    const remaining = total % 7 === 0 ? 0 : 7 - (total % 7);
    for (let i = 1; i <= remaining; i++) {
      gridHtml += `<div class="cal-day other-month">${i}</div>`;
    }

    container.innerHTML = `<div class="calendar-widget">
      <div class="calendar-header">
        <button class="cal-nav" id="cal-prev-${w.instanceId}">‹</button>
        <div class="cal-month-name">${months[month]} ${year}</div>
        <button class="cal-nav" id="cal-next-${w.instanceId}">›</button>
      </div>
      <div class="cal-grid">${gridHtml}</div>
    </div>`;

    document.getElementById(`cal-prev-${w.instanceId}`)?.addEventListener('click', () => {
      let m = month - 1, y = year;
      if (m < 0) { m = 11; y--; }
      w.config.viewYear = y; w.config.viewMonth = m;
      saveState(); this._renderCalendar(container, w, y, m);
    });
    document.getElementById(`cal-next-${w.instanceId}`)?.addEventListener('click', () => {
      let m = month + 1, y = year;
      if (m > 11) { m = 0; y++; }
      w.config.viewYear = y; w.config.viewMonth = m;
      saveState(); this._renderCalendar(container, w, y, m);
    });
  }
});

// ============================================================
// WIDGET: POMODORO TIMER
// ============================================================
registerWidget({
  id: 'pomodoro',
  name: 'Pomodoro Timer',
  icon: '⏱',
  description: 'Focus timer with work/break cycles',
  defaultSize: 'small',
  defaultConfig: { workMin: 25, shortBreakMin: 5, longBreakMin: 15, sessionsUntilLong: 4 },
  getConfigFields(config) {
    return [
      { key: 'workMin', label: 'Work Duration (minutes)', type: 'number', default: 25 },
      { key: 'shortBreakMin', label: 'Short Break (minutes)', type: 'number', default: 5 },
      { key: 'longBreakMin', label: 'Long Break (minutes)', type: 'number', default: 15 },
      { key: 'sessionsUntilLong', label: 'Sessions until Long Break', type: 'number', default: 4 }
    ];
  },
  render(container, w, addInterval) {
    const c = w.config;
    const workSec = (parseInt(c.workMin) || 25) * 60;
    const shortSec = (parseInt(c.shortBreakMin) || 5) * 60;
    const longSec = (parseInt(c.longBreakMin) || 15) * 60;
    const sessionsUntilLong = parseInt(c.sessionsUntilLong) || 4;

    let state = { mode: 'work', remaining: workSec, total: workSec, sessions: 0, running: false };
    let ticker = null;

    const modes = { work: 'Focus Time', shortBreak: 'Short Break', longBreak: 'Long Break' };

    const render = () => {
      const m = Math.floor(state.remaining / 60);
      const s = state.remaining % 60;
      const pct = ((state.total - state.remaining) / state.total * 100).toFixed(1);
      const dots = Array.from({length: sessionsUntilLong}, (_,i) => i < state.sessions % sessionsUntilLong || (state.sessions > 0 && state.sessions % sessionsUntilLong === 0 && i < sessionsUntilLong) ? '●' : '○').join(' ');

      container.innerHTML = `<div class="pomodoro-widget">
        <div class="pom-mode">${modes[state.mode]}</div>
        <div class="pom-time">${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}</div>
        <div class="pom-controls">
          <button class="pom-btn start" id="pom-start-${w.instanceId}">${state.running ? 'Pause' : 'Start'}</button>
          <button class="pom-btn" id="pom-reset-${w.instanceId}">Reset</button>
          <button class="pom-btn" id="pom-skip-${w.instanceId}">Skip</button>
        </div>
        <div class="pom-progress"><div class="pom-progress-bar" style="width:${pct}%"></div></div>
        <div class="pom-sessions">Sessions: ${state.sessions} ${dots}</div>
      </div>`;

      document.getElementById(`pom-start-${w.instanceId}`)?.addEventListener('click', () => {
        state.running = !state.running;
        if (state.running) {
          ticker = setInterval(() => {
            state.remaining--;
            if (state.remaining <= 0) {
              clearInterval(ticker);
              ticker = null;
              state.running = false;
              if (state.mode === 'work') {
                state.sessions++;
                const doLong = state.sessions % sessionsUntilLong === 0;
                state.mode = doLong ? 'longBreak' : 'shortBreak';
                state.remaining = doLong ? longSec : shortSec;
                state.total = state.remaining;
              } else {
                state.mode = 'work';
                state.remaining = workSec;
                state.total = workSec;
              }
            }
            render();
          }, 1000);
          addInterval(ticker);
        } else {
          clearInterval(ticker);
          ticker = null;
        }
        render();
      });
      document.getElementById(`pom-reset-${w.instanceId}`)?.addEventListener('click', () => {
        clearInterval(ticker); ticker = null;
        state = { mode: 'work', remaining: workSec, total: workSec, sessions: 0, running: false };
        render();
      });
      document.getElementById(`pom-skip-${w.instanceId}`)?.addEventListener('click', () => {
        clearInterval(ticker); ticker = null;
        state.running = false;
        if (state.mode === 'work') {
          state.sessions++;
          const doLong = state.sessions % sessionsUntilLong === 0;
          state.mode = doLong ? 'longBreak' : 'shortBreak';
          state.remaining = doLong ? longSec : shortSec;
          state.total = state.remaining;
        } else {
          state.mode = 'work';
          state.remaining = workSec;
          state.total = workSec;
        }
        render();
      });
    };
    render();
  }
});

// ============================================================
// WIDGET: TOP SITES
// ============================================================
registerWidget({
  id: 'topsites',
  name: 'Top Sites',
  icon: '🏠',
  description: 'Your most visited sites from Chrome',
  defaultSize: 'medium',
  defaultConfig: { maxSites: 12 },
  getConfigFields(config) {
    return [
      { key: 'maxSites', label: 'Max Sites to Show', type: 'number', default: 12 }
    ];
  },
  render(container, w, addInterval) {
    const max = parseInt(w.config.maxSites) || 12;
    try {
      chrome.topSites.get(sites => {
        const shown = sites.slice(0, max);
        let html = '<div class="topsites-widget"><div class="topsites-grid">';
        shown.forEach(site => {
          const domain = (() => { try { return new URL(site.url).hostname; } catch(_) { return ''; } })();
          const favicon = domain ? `https://www.google.com/s2/favicons?domain=${domain}&sz=32` : '';
          const label = site.title || domain;
          html += `<a class="topsite-item" href="${site.url}" target="_blank" rel="noopener" title="${site.title}">
            <img class="topsite-favicon" src="${favicon}" alt="" loading="lazy" onerror="this.style.display='none'">
            <span class="topsite-label">${label}</span>
          </a>`;
        });
        html += '</div></div>';
        container.innerHTML = html;
      });
    } catch(e) {
      container.innerHTML = '<div class="topsites-widget"><div class="text-muted text-sm" style="padding:8px">Top sites unavailable in this context.</div></div>';
    }
  }
});

// ============================================================
// MAIN APP
// ============================================================
const App = {
  async init() {
    // Load state
    const saved = await Storage.load();
    if (saved && saved.version) {
      // Deep merge to preserve new defaults
      state = this._merge(JSON.parse(JSON.stringify(DEFAULT_STATE)), saved);
    }
    // Apply theme
    Theme.apply(state.theme);
    // Update greeting
    updateGreeting();
    setInterval(updateGreeting, 60000);
    // Render pages
    Pages.render();
    // Render grid
    Grid.render();
    // Wire up controls
    this._wireControls();
  },

  _merge(defaults, saved) {
    // Prefer saved values, but ensure new default keys exist
    const result = { ...defaults };
    Object.keys(saved).forEach(k => {
      if (k === 'theme' && saved.theme && defaults.theme) {
        result.theme = { ...defaults.theme, ...saved.theme };
      } else {
        result[k] = saved[k];
      }
    });
    return result;
  },

  _wireControls() {
    document.getElementById('add-widget-btn')?.addEventListener('click', () => WidgetPicker.open());
    document.getElementById('settings-btn')?.addEventListener('click', () => SettingsPanel.open());
    document.getElementById('add-page-btn')?.addEventListener('click', () => Pages.addPage());
    document.getElementById('close-picker-btn')?.addEventListener('click', () => WidgetPicker.close());
    document.getElementById('close-settings-btn')?.addEventListener('click', () => SettingsPanel.close());
    document.getElementById('close-config-btn')?.addEventListener('click', () => WidgetConfig.close());
    document.getElementById('settings-save-btn')?.addEventListener('click', () => SettingsPanel.save());
    document.getElementById('settings-reset-btn')?.addEventListener('click', () => SettingsPanel.reset());
    document.getElementById('widget-config-save-btn')?.addEventListener('click', () => WidgetConfig.save());

    // Settings live preview: opacity
    document.getElementById('setting-opacity')?.addEventListener('input', e => {
      document.getElementById('opacity-val').textContent = Math.round(e.target.value * 100) + '%';
    });

    // Background type toggle
    document.querySelectorAll('input[name="bg-type"]').forEach(r => {
      r.addEventListener('change', () => SettingsPanel.updateBgControls(r.value));
    });

    // Close overlays on backdrop click
    document.getElementById('widget-picker-overlay')?.addEventListener('click', e => {
      if (e.target === e.currentTarget) WidgetPicker.close();
    });
    document.getElementById('settings-overlay')?.addEventListener('click', e => {
      if (e.target === e.currentTarget) SettingsPanel.close();
    });
    document.getElementById('widget-config-overlay')?.addEventListener('click', e => {
      if (e.target === e.currentTarget) WidgetConfig.close();
    });

    // Keyboard: Escape closes modals
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        WidgetPicker.close();
        SettingsPanel.close();
        WidgetConfig.close();
      }
    });
  },

  openWidgetPicker() { WidgetPicker.open(); },
  refreshWidget(widgetId) { Grid.render(); }
};

// Boot
document.addEventListener('DOMContentLoaded', () => App.init());
