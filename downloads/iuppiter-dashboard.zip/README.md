# Iuppiter Dashboard 🏛️

A fully customizable new tab Chrome extension. Replace the default new tab page with a powerful, widget-based productivity dashboard.

---

## Features

### 13 Widgets — All Optional
| Widget | Description |
|--------|-------------|
| 🕐 Clock | Digital or analog clock with date, day of week |
| 🌤 Weather | Current conditions + 3-day forecast (wttr.in, no API key) |
| 🔗 Quick Links | Shortcut grid with favicons — add your own sites |
| 📝 Notes | Sticky notes with colors, fully editable |
| ✅ Todo List | Add/check/delete tasks, persists across sessions |
| 📈 Stock Ticker | Live prices via Yahoo Finance (no API key) |
| 📰 News Feed | RSS headlines — add custom feed URLs |
| ⭐ Bookmarks Bar | Quick access to your Chrome bookmarks |
| 🔍 Search Bar | Google, DuckDuckGo, Bing, Brave, or Perplexity |
| 💬 Daily Quote | 200+ embedded historical & inspirational quotes |
| 📅 Calendar | Month view with current date highlighted |
| ⏱ Pomodoro Timer | Focus timer with work/break cycles |
| 🏠 Top Sites | Your most visited sites |

### Layout System
- **CSS Grid** — responsive 12-column layout
- **Drag & drop** to rearrange — native HTML5, no libraries
- **Resize** any widget: Small / Medium / Large / Full Width
- **Multiple pages** — create and name your own dashboard pages
- **Persistent** — all layout data saved in `chrome.storage.local`

### Full Customization
- Background: gradient (color picker), solid color, or image URL
- Accent color picker
- Widget opacity slider
- 5 font options including Georgia and Palatino (Roman feel)
- Dark / Light mode
- Personal greeting with your name

---

## Installation

### Load as unpacked extension (Developer Mode)

1. Open Chrome → `chrome://extensions/`
2. Enable **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `dashboard-extension/` folder
5. Open a new tab — Iuppiter Dashboard loads automatically

### Icons
Icons are pre-generated. To regenerate:
```bash
pip install Pillow
python generate_icons.py
```

---

## Technical Details

- **Manifest V3** — modern Chrome extension standard
- **No external dependencies** — zero npm, zero CDN, zero frameworks
- **No analytics, no phone-home** — all data stays in `chrome.storage.local`
- **Permissions used:**
  - `storage` — saves your layout and settings
  - `topSites` — Top Sites widget
  - `bookmarks` — Bookmarks widget
  - `host_permissions: https://*/*` — weather, stocks, RSS, favicons

### Data Sources
| Widget | Source | API Key? |
|--------|--------|----------|
| Weather | [wttr.in](https://wttr.in) | ❌ None |
| Stocks | Yahoo Finance v7 | ❌ None |
| News | RSS via allorigins.win proxy | ❌ None |
| Favicons | Google S2 favicon service | ❌ None |
| Quotes | Embedded (200+ quotes) | ❌ None |

---

## File Structure

```
dashboard-extension/
├── manifest.json         # MV3 manifest
├── newtab.html           # Main page (newtab override)
├── style.css             # Full dark theme + widget styles
├── js/
│   ├── app.js            # All widgets + engine (~2500 lines)
│   └── quotes.js         # 200+ embedded quotes
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── generate_icons.py     # Pillow icon generator
└── README.md
```

---

## Usage Tips

- **Add a widget:** Click `⊞ Add Widget` in the top bar
- **Rearrange:** Drag the `⠿⠿` handle on any widget
- **Resize:** Hover a widget → click the `⊞` button → pick size
- **Configure:** Hover a widget → click `⚙` for widget-specific settings
- **Remove:** Hover a widget → click `×`
- **New page:** Click `+` next to the page tabs
- **Settings:** Click `⚙` in the top right

---

## Security

- No personal data collection
- No remote logging or analytics
- All storage is local (`chrome.storage.local`)
- No third-party scripts loaded
- Host permissions limited to data fetching (weather, stocks, RSS, favicons)

---

*Iuppiter — King of the Roman gods. Your dashboard, your command.*
