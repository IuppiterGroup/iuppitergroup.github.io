# Iuppiter Calendar — Chrome Extension

A fully standalone popup calendar with events, reminders, and recurring events.
No Google Calendar API. No external services. Everything stored locally.

## Features

- **Month view** — full calendar grid with event dots
- **Week view** — 7-day view with event chips
- **Agenda view** — upcoming 30 days list
- **Navigate** — prev/next month or week, Today button
- **Add events** — click any date to add an event
- **Event fields** — title, date, time, description, calendar (category), reminder, recurring
- **Colored event dots** — each calendar has its own color
- **Day panel** — click a date to see all events; add/edit from there
- **Recurring events** — daily, weekly, monthly, or yearly with optional end date
- **Reminders** — 5min, 15min, 30min, 1hr, or 1 day before via `chrome.notifications`
- **Multiple calendars** — create/manage color-coded calendars (like Google Calendar)
- **Import/Export** — export all events to `.json`; import from `.json`
- **Search** — search events across all time
- **Fullscreen mode** — opens a full browser tab for better visibility

## Installation

1. Run the icon generator (requires Pillow):
   ```
   pip install Pillow
   python generate_icons.py
   ```
2. Open Chrome and go to `chrome://extensions/`
3. Enable **Developer mode** (top right toggle)
4. Click **Load unpacked**
5. Select this folder (`calendar-extension/`)
6. The 📅 icon appears in your toolbar

> **Notifications:** Chrome will ask for notification permission the first time a reminder fires. Allow it to receive event reminders.

## Color Scheme

| Element | Color |
|---------|-------|
| Gold accent | `#c4a44a` |
| Blue accent | `#2b579a` |
| Dark background | `#1a1a2e` |
| Today highlight | `rgba(196,164,74,0.18)` |

## File Structure

```
calendar-extension/
├── manifest.json        # Manifest V3 (storage, alarms, notifications)
├── popup.html           # Main popup
├── popup.css            # Styles
├── popup.js             # Calendar logic
├── background.js        # Service worker — alarm → notification
├── fullscreen.html      # Full-tab mode
├── generate_icons.py    # Icon generator
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

## Technical Notes

- Manifest V3 compliant
- `chrome.storage.local` for all data
- `chrome.alarms` for reminder scheduling (persists across browser restarts)
- `chrome.notifications` for desktop event reminders
- Zero external dependencies — no Google Calendar, no API keys, no network requests
- Recurring event expansion is computed on-the-fly (not stored as copies)
- Import/export uses a versioned JSON format for forward compatibility
