/**
 * Iuppiter Calendar — background.js (Service Worker)
 * Handles alarm-triggered notifications for event reminders.
 */

'use strict';

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith('event_')) return;

  const eventId = alarm.name.replace('event_', '');

  // Load events from storage
  const data = await chrome.storage.local.get(['events', 'calendars']);
  const events    = data.events    || [];
  const calendars = data.calendars || [];

  const ev = events.find(e => e.id === eventId);
  if (!ev) return;

  const calName = (calendars.find(c => c.id === ev.calendar) || {}).name || '';

  const reminderLabel = ev.reminder?.minutes
    ? (ev.reminder.minutes >= 60
        ? Math.round(ev.reminder.minutes / 60) + ' hour(s)'
        : ev.reminder.minutes + ' minute(s)')
    + ' until'
    : 'Upcoming:';

  chrome.notifications.create('reminder_' + eventId, {
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: '📅 ' + ev.title,
    message: reminderLabel + ' ' + ev.title +
      (ev.time ? ' at ' + ev.time : '') +
      (calName ? ' (' + calName + ')' : ''),
    priority: 2
  });
});

// Handle notification click — open the extension popup
chrome.notifications.onClicked.addListener((notifId) => {
  chrome.action.openPopup();
  chrome.notifications.clear(notifId);
});
