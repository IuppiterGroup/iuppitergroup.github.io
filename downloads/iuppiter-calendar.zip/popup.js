/**
 * Iuppiter Calendar — popup.js
 * Manifest V3 | chrome.storage.local | Alarms | Notifications
 * Fully standalone — no external services
 */

'use strict';

// ============================================================
// STATE
// ============================================================
let state = {
  events: [],
  calendars: [
    { id: 'personal', name: 'Personal', color: '#c4a44a' },
    { id: 'work',     name: 'Work',     color: '#2b579a' }
  ],
  settings: {
    view: 'month',
    currentYear: new Date().getFullYear(),
    currentMonth: new Date().getMonth()
  }
};

let currentView = 'month';
let selectedDate = null;    // 'YYYY-MM-DD'
let editingEventId = null;  // null = new event

const DAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

// ============================================================
// STORAGE
// ============================================================
async function loadState() {
  return new Promise(resolve => {
    chrome.storage.local.get(['events', 'calendars', 'calSettings'], (data) => {
      if (data.events)     state.events    = data.events;
      if (data.calendars)  state.calendars = data.calendars;
      if (data.calSettings) {
        state.settings = { ...state.settings, ...data.calSettings };
        currentView = state.settings.view || 'month';
      }
      resolve();
    });
  });
}

async function saveState() {
  return new Promise(resolve => {
    chrome.storage.local.set({
      events:      state.events,
      calendars:   state.calendars,
      calSettings: state.settings
    }, resolve);
  });
}

// ============================================================
// HELPERS
// ============================================================
function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function todayStr() {
  return fmtDate(new Date());
}

function fmtDate(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function parseDate(str) {
  // 'YYYY-MM-DD' → Date at local midnight
  const [y, m, d] = str.split('-').map(Number);
  return new Date(y, m - 1, d);
}

function fmtDisplayDate(str) {
  const d = parseDate(str);
  return DAYS[d.getDay()].slice(0, 3) + ', ' + MONTHS[d.getMonth()].slice(0, 3) + ' ' + d.getDate();
}

function calendarColor(calId) {
  const cal = state.calendars.find(c => c.id === calId);
  return cal ? cal.color : '#888';
}

function calendarName(calId) {
  const cal = state.calendars.find(c => c.id === calId);
  return cal ? cal.name : calId;
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ============================================================
// EVENT EXPANSION (recurring)
// ============================================================
/**
 * Get all effective event instances within a date range.
 * Returns array of { event, date: 'YYYY-MM-DD' }
 */
function getEventInstances(startStr, endStr) {
  const start = parseDate(startStr);
  const end   = parseDate(endStr);
  const result = [];

  for (const ev of state.events) {
    const base = parseDate(ev.date);

    if (!ev.recurring) {
      if (ev.date >= startStr && ev.date <= endStr) {
        result.push({ event: ev, date: ev.date });
      }
      continue;
    }

    // Expand recurring events
    const recEnd = ev.recurring.endDate ? parseDate(ev.recurring.endDate) : end;
    let cur = new Date(base);

    while (cur <= recEnd && cur <= end) {
      const curStr = fmtDate(cur);
      if (curStr >= startStr && curStr <= endStr) {
        result.push({ event: ev, date: curStr });
      }
      // Advance
      const next = new Date(cur);
      switch (ev.recurring.type) {
        case 'daily':   next.setDate(next.getDate() + 1); break;
        case 'weekly':  next.setDate(next.getDate() + 7); break;
        case 'monthly': next.setMonth(next.getMonth() + 1); break;
        case 'yearly':  next.setFullYear(next.getFullYear() + 1); break;
        default:        cur = new Date(end.getTime() + 1); continue;
      }
      if (next.getTime() === cur.getTime()) break; // safety
      cur = next;
    }
  }

  return result;
}

function getEventsForDate(dateStr) {
  return getEventInstances(dateStr, dateStr);
}

// ============================================================
// NAVIGATION
// ============================================================
function navLabel() {
  const { currentYear: y, currentMonth: m } = state.settings;
  if (currentView === 'month') return MONTHS[m] + ' ' + y;
  if (currentView === 'week') {
    // Show week range
    const start = getWeekStart(y, m, currentWeekOffset);
    const end = new Date(start); end.setDate(end.getDate() + 6);
    const sm = MONTHS[start.getMonth()].slice(0,3);
    const em = MONTHS[end.getMonth()].slice(0,3);
    return `${sm} ${start.getDate()} – ${em} ${end.getDate()}, ${end.getFullYear()}`;
  }
  if (currentView === 'agenda') return 'Next 30 Days';
  return '';
}

let currentWeekOffset = 0; // weeks from "this week"

function getWeekStart(y, m, weekOffset) {
  // Start from the first Sunday of the month or current week
  const today = new Date();
  const base = new Date(today);
  base.setDate(base.getDate() - base.getDay() + weekOffset * 7);
  return base;
}

function navPrev() {
  if (currentView === 'month') {
    state.settings.currentMonth--;
    if (state.settings.currentMonth < 0) {
      state.settings.currentMonth = 11;
      state.settings.currentYear--;
    }
  } else if (currentView === 'week') {
    currentWeekOffset--;
  } else if (currentView === 'agenda') {
    // no-op or scroll back
  }
  renderCurrentView();
  saveState();
}

function navNext() {
  if (currentView === 'month') {
    state.settings.currentMonth++;
    if (state.settings.currentMonth > 11) {
      state.settings.currentMonth = 0;
      state.settings.currentYear++;
    }
  } else if (currentView === 'week') {
    currentWeekOffset++;
  }
  renderCurrentView();
  saveState();
}

function goToday() {
  const now = new Date();
  state.settings.currentYear = now.getFullYear();
  state.settings.currentMonth = now.getMonth();
  currentWeekOffset = 0;
  renderCurrentView();
  saveState();
}

// ============================================================
// MONTH VIEW
// ============================================================
function renderMonthView() {
  const { currentYear: y, currentMonth: m } = state.settings;
  document.getElementById('nav-label').textContent = navLabel();

  const grid = document.getElementById('month-grid');
  const today = todayStr();

  // First day of month (0=Sun)
  const firstDay = new Date(y, m, 1).getDay();
  // Days in month
  const daysInMonth = new Date(y, m + 1, 0).getDate();
  // Days in prev month
  const daysInPrev = new Date(y, m, 0).getDate();

  // Range for event fetching
  const rangeStart = fmtDate(new Date(y, m - 1, daysInPrev - firstDay + 1));
  const rangeEnd   = fmtDate(new Date(y, m + 1, 14));
  const instances  = getEventInstances(rangeStart, rangeEnd);

  // Group by date
  const byDate = {};
  for (const inst of instances) {
    if (!byDate[inst.date]) byDate[inst.date] = [];
    byDate[inst.date].push(inst);
  }

  let html = '';
  let dayCount = 0;
  const totalCells = 42; // 6 rows

  for (let i = 0; i < totalCells; i++) {
    let dateStr, cls = 'cal-day';
    if (i < firstDay) {
      const d = daysInPrev - firstDay + 1 + i;
      dateStr = fmtDate(new Date(y, m - 1, d));
      cls += ' other-month';
    } else if (dayCount < daysInMonth) {
      dayCount++;
      dateStr = fmtDate(new Date(y, m, dayCount));
    } else {
      const d = i - firstDay - daysInMonth + 1;
      dateStr = fmtDate(new Date(y, m + 1, d));
      cls += ' other-month';
    }

    if (dateStr === today) cls += ' today';
    if (dateStr === selectedDate) cls += ' selected';

    const dots = (byDate[dateStr] || []).slice(0, 5).map(inst => {
      const color = calendarColor(inst.event.calendar);
      return `<span class="event-dot" style="background:${color}" title="${escHtml(inst.event.title)}"></span>`;
    }).join('');

    html += `<div class="${cls}" data-date="${dateStr}">
      <div class="day-num">${dateStr.split('-')[2].replace(/^0/,'')}</div>
      <div class="day-dots">${dots}</div>
    </div>`;
  }

  grid.innerHTML = html;

  grid.querySelectorAll('.cal-day').forEach(el => {
    el.addEventListener('click', () => openDayPanel(el.dataset.date));
  });
}

// ============================================================
// WEEK VIEW
// ============================================================
function renderWeekView() {
  document.getElementById('nav-label').textContent = navLabel();
  const weekGrid = document.getElementById('week-grid');
  const today = todayStr();
  const weekStart = getWeekStart(
    state.settings.currentYear,
    state.settings.currentMonth,
    currentWeekOffset
  );

  let html = '';
  for (let i = 0; i < 7; i++) {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + i);
    const dateStr = fmtDate(d);
    const isToday = dateStr === today;
    const instances = getEventsForDate(dateStr);

    const evChips = instances.map(inst => {
      const color = calendarColor(inst.event.calendar);
      const time  = inst.event.time || '';
      return `<span class="week-event-chip" style="background:${color}"
        data-id="${inst.event.id}" data-date="${dateStr}"
        title="${escHtml(inst.event.title)}">
        ${time ? escHtml(time) + ' ' : ''}${escHtml(inst.event.title)}
      </span>`;
    }).join('');

    html += `<div class="week-day-row${isToday ? ' today' : ''}" data-date="${dateStr}">
      <div class="week-day-label">
        <div>${DAYS[d.getDay()].slice(0,3)}</div>
        <div style="font-size:13px;color:${isToday?'var(--gold)':'var(--text)'}">${d.getDate()}</div>
      </div>
      <div class="week-events">${evChips || '<span style="color:var(--text-muted);font-size:11px">Free</span>'}</div>
    </div>`;
  }

  weekGrid.innerHTML = html;

  weekGrid.querySelectorAll('.week-day-row').forEach(row => {
    row.addEventListener('click', (e) => {
      if (!e.target.closest('.week-event-chip')) {
        openDayPanel(row.dataset.date);
      }
    });
  });

  weekGrid.querySelectorAll('.week-event-chip').forEach(chip => {
    chip.addEventListener('click', (e) => {
      e.stopPropagation();
      openEventModal(chip.dataset.id, chip.dataset.date);
    });
  });
}

// ============================================================
// AGENDA VIEW
// ============================================================
function renderAgendaView() {
  document.getElementById('nav-label').textContent = 'Upcoming 30 Days';
  const list = document.getElementById('agenda-list');
  const today = todayStr();
  const endDate = fmtDate(new Date(Date.now() + 30 * 86400000));
  const instances = getEventInstances(today, endDate)
    .sort((a, b) => {
      if (a.date !== b.date) return a.date.localeCompare(b.date);
      return (a.event.time || '').localeCompare(b.event.time || '');
    });

  if (!instances.length) {
    list.innerHTML = '<div class="agenda-empty">No events in the next 30 days</div>';
    return;
  }

  let html = '';
  let lastDate = null;
  for (const inst of instances) {
    if (inst.date !== lastDate) {
      const label = inst.date === today ? 'Today — ' + fmtDisplayDate(inst.date) : fmtDisplayDate(inst.date);
      html += `<div class="agenda-date-header">${label}</div>`;
      lastDate = inst.date;
    }
    const color = calendarColor(inst.event.calendar);
    html += `<div class="agenda-event-item" style="border-left-color:${color}"
      data-id="${inst.event.id}" data-date="${inst.date}">
      <div class="agenda-event-time">${inst.event.time || 'All day'}</div>
      <div class="agenda-event-body">
        <div class="agenda-event-title">${escHtml(inst.event.title)}</div>
        ${inst.event.description ? `<div class="agenda-event-desc">${escHtml(inst.event.description)}</div>` : ''}
      </div>
    </div>`;
  }

  list.innerHTML = html;

  list.querySelectorAll('.agenda-event-item').forEach(el => {
    el.addEventListener('click', () => openEventModal(el.dataset.id, el.dataset.date));
  });
}

// ============================================================
// RENDER DISPATCH
// ============================================================
function renderCurrentView() {
  // Show/hide panels
  document.getElementById('month-view').classList.toggle('hidden', currentView !== 'month');
  document.getElementById('week-view').classList.toggle('hidden', currentView !== 'week');
  document.getElementById('agenda-view').classList.toggle('hidden', currentView !== 'agenda');

  document.querySelectorAll('.view-tab').forEach(t => {
    t.classList.toggle('active', t.dataset.view === currentView);
  });

  if (currentView === 'month') renderMonthView();
  else if (currentView === 'week') renderWeekView();
  else if (currentView === 'agenda') renderAgendaView();
}

// ============================================================
// DAY PANEL
// ============================================================
function openDayPanel(dateStr) {
  selectedDate = dateStr;
  const panel = document.getElementById('day-panel');
  panel.classList.remove('hidden');
  document.getElementById('day-panel-title').textContent = fmtDisplayDate(dateStr);

  renderDayEvents(dateStr);

  // Re-render month to highlight selection
  if (currentView === 'month') renderMonthView();
}

function closeDayPanel() {
  selectedDate = null;
  document.getElementById('day-panel').classList.add('hidden');
  if (currentView === 'month') renderMonthView();
}

function renderDayEvents(dateStr) {
  const instances = getEventsForDate(dateStr)
    .sort((a, b) => (a.event.time || '').localeCompare(b.event.time || ''));

  const list = document.getElementById('day-events-list');
  if (!instances.length) {
    list.innerHTML = '<div class="day-no-events">No events — click + Add Event</div>';
    return;
  }

  list.innerHTML = instances.map(inst => {
    const color = calendarColor(inst.event.calendar);
    return `<div class="day-event-item" style="border-left-color:${color}"
      data-id="${inst.event.id}" data-date="${dateStr}">
      <div class="day-event-time">${inst.event.time || 'All day'}</div>
      <div class="day-event-body">
        <div class="day-event-title">${escHtml(inst.event.title)}</div>
        ${inst.event.description ? `<div class="day-event-desc">${escHtml(inst.event.description)}</div>` : ''}
      </div>
    </div>`;
  }).join('');

  list.querySelectorAll('.day-event-item').forEach(el => {
    el.addEventListener('click', () => openEventModal(el.dataset.id, el.dataset.date));
  });
}

// ============================================================
// EVENT MODAL
// ============================================================
function openEventModal(eventId, dateStr) {
  editingEventId = eventId || null;
  const modal = document.getElementById('event-modal');
  const isNew = !eventId;

  document.getElementById('event-modal-title').textContent = isNew ? 'New Event' : 'Edit Event';
  document.getElementById('btn-event-delete').classList.toggle('hidden', isNew);

  // Populate calendar select
  populateCalendarSelect('ev-calendar');

  if (isNew) {
    document.getElementById('ev-title').value = '';
    document.getElementById('ev-date').value = dateStr || todayStr();
    document.getElementById('ev-time').value = '';
    document.getElementById('ev-desc').value = '';
    document.getElementById('ev-calendar').value = state.calendars[0]?.id || '';
    document.getElementById('ev-reminder').value = '';
    document.getElementById('ev-recurring').value = '';
    document.getElementById('ev-recurring-end').value = '';
    document.getElementById('recurring-end-row').style.display = 'none';
  } else {
    const ev = state.events.find(e => e.id === eventId);
    if (!ev) return;
    document.getElementById('ev-title').value = ev.title;
    document.getElementById('ev-date').value = ev.date;
    document.getElementById('ev-time').value = ev.time || '';
    document.getElementById('ev-desc').value = ev.description || '';
    document.getElementById('ev-calendar').value = ev.calendar || '';
    document.getElementById('ev-reminder').value = ev.reminder?.minutes || '';
    document.getElementById('ev-recurring').value = ev.recurring?.type || '';
    document.getElementById('ev-recurring-end').value = ev.recurring?.endDate || '';
    document.getElementById('recurring-end-row').style.display = ev.recurring ? '' : 'none';
  }

  modal.classList.remove('hidden');
  document.getElementById('ev-title').focus();
}

function closeEventModal() {
  document.getElementById('event-modal').classList.add('hidden');
  editingEventId = null;
}

function populateCalendarSelect(selectId) {
  const sel = document.getElementById(selectId);
  sel.innerHTML = state.calendars.map(c =>
    `<option value="${escHtml(c.id)}">${escHtml(c.name)}</option>`
  ).join('');
}

// ============================================================
// EVENT CRUD
// ============================================================
async function saveEvent() {
  const title = document.getElementById('ev-title').value.trim();
  if (!title) { document.getElementById('ev-title').focus(); return; }

  const date        = document.getElementById('ev-date').value;
  const time        = document.getElementById('ev-time').value;
  const desc        = document.getElementById('ev-desc').value.trim();
  const calendar    = document.getElementById('ev-calendar').value;
  const reminderMin = parseInt(document.getElementById('ev-reminder').value) || null;
  const recurType   = document.getElementById('ev-recurring').value;
  const recurEnd    = document.getElementById('ev-recurring-end').value;

  const recurring = recurType ? { type: recurType, endDate: recurEnd || null } : null;
  const reminder  = reminderMin ? { minutes: reminderMin } : null;

  if (editingEventId) {
    const idx = state.events.findIndex(e => e.id === editingEventId);
    if (idx !== -1) {
      state.events[idx] = { ...state.events[idx], title, date, time, description: desc, calendar, reminder, recurring };
    }
  } else {
    const ev = { id: genId(), title, date, time, description: desc, calendar, reminder, recurring };
    state.events.push(ev);
  }

  await saveState();
  scheduleReminders();
  closeEventModal();

  // Refresh
  renderCurrentView();
  if (selectedDate) renderDayEvents(selectedDate);
}

async function deleteEvent() {
  if (!editingEventId) return;
  if (!confirm('Delete this event?')) return;
  state.events = state.events.filter(e => e.id !== editingEventId);
  await saveState();
  scheduleReminders();
  closeEventModal();
  renderCurrentView();
  if (selectedDate) renderDayEvents(selectedDate);
}

// ============================================================
// REMINDERS (Alarms)
// ============================================================
function scheduleReminders() {
  // Clear all existing reminder alarms
  chrome.alarms.clearAll(() => {
    const now = Date.now();
    for (const ev of state.events) {
      if (!ev.reminder || !ev.date || !ev.time) continue;
      const [h, min] = ev.time.split(':').map(Number);
      const evTime = new Date(ev.date + 'T' + ev.time + ':00').getTime();
      const alarmTime = evTime - ev.reminder.minutes * 60 * 1000;
      if (alarmTime > now) {
        chrome.alarms.create('event_' + ev.id, { when: alarmTime });
      }
    }
  });
}

// ============================================================
// SEARCH
// ============================================================
function performSearch(query) {
  const results = document.getElementById('search-results');
  if (!query.trim()) { results.innerHTML = ''; return; }

  const q = query.toLowerCase();
  const today = todayStr();
  const farFuture = fmtDate(new Date(Date.now() + 365 * 2 * 86400000));
  const instances = getEventInstances(
    fmtDate(new Date(Date.now() - 365 * 86400000)),
    farFuture
  ).filter(inst =>
    inst.event.title.toLowerCase().includes(q) ||
    (inst.event.description || '').toLowerCase().includes(q)
  ).slice(0, 10);

  if (!instances.length) {
    results.innerHTML = '<div style="color:var(--text-muted);font-size:12px;padding:8px">No events found</div>';
    return;
  }

  results.innerHTML = instances.map(inst =>
    `<div class="search-result-item" data-id="${inst.event.id}" data-date="${inst.date}">
      <div class="search-result-title">${escHtml(inst.event.title)}</div>
      <div class="search-result-sub">${fmtDisplayDate(inst.date)} ${inst.event.time ? '@ ' + inst.event.time : ''}</div>
    </div>`
  ).join('');

  results.querySelectorAll('.search-result-item').forEach(el => {
    el.addEventListener('click', () => {
      openEventModal(el.dataset.id, el.dataset.date);
      closeSearch();
    });
  });
}

function closeSearch() {
  document.getElementById('search-bar').classList.add('hidden');
  document.getElementById('search-input').value = '';
  document.getElementById('search-results').innerHTML = '';
}

// ============================================================
// CALENDAR MANAGER
// ============================================================
function renderCalendarsModal() {
  const list = document.getElementById('calendars-list');
  list.innerHTML = state.calendars.map(c =>
    `<div class="cal-item" data-id="${c.id}">
      <span class="cal-color-dot" style="background:${c.color}"></span>
      <span class="cal-item-name">${escHtml(c.name)}</span>
      <button class="cal-item-delete" data-id="${c.id}" title="Delete calendar">🗑</button>
    </div>`
  ).join('');

  list.querySelectorAll('.cal-item-delete').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.currentTarget.dataset.id;
      if (state.calendars.length <= 1) return;
      if (!confirm('Delete this calendar? Events in it will be deleted too.')) return;
      state.calendars = state.calendars.filter(c => c.id !== id);
      state.events = state.events.filter(e => e.calendar !== id);
      await saveState();
      renderCalendarsModal();
      renderCurrentView();
    });
  });
}

// ============================================================
// IMPORT / EXPORT
// ============================================================
function exportEvents() {
  const data = {
    version: 1,
    exported: new Date().toISOString(),
    calendars: state.calendars,
    events: state.events
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'iuppiter-calendar-' + todayStr() + '.json';
  a.click();
  URL.revokeObjectURL(url);
}

function importEvents(file) {
  const reader = new FileReader();
  reader.onload = async (e) => {
    try {
      const data = JSON.parse(e.target.result);
      if (!data.events || !Array.isArray(data.events)) throw new Error('Invalid format');

      // Merge calendars (avoid duplicates by id)
      if (data.calendars) {
        for (const cal of data.calendars) {
          if (!state.calendars.find(c => c.id === cal.id)) {
            state.calendars.push(cal);
          }
        }
      }

      // Merge events (avoid duplicates by id)
      for (const ev of data.events) {
        if (!state.events.find(e => e.id === ev.id)) {
          state.events.push(ev);
        }
      }

      await saveState();
      document.getElementById('import-status').textContent =
        `✓ Imported ${data.events.length} events`;
      renderCurrentView();
    } catch (err) {
      document.getElementById('import-status').textContent = '✕ Error: ' + err.message;
    }
  };
  reader.readAsText(file);
}

// ============================================================
// FULLSCREEN
// ============================================================
function openFullscreen() {
  chrome.tabs.create({ url: chrome.runtime.getURL('fullscreen.html') });
}

// ============================================================
// INIT
// ============================================================
async function init() {
  await loadState();
  currentView = state.settings.view || 'month';

  // Set active view tab
  renderCurrentView();

  // ===== VIEW TAB CLICKS =====
  document.querySelectorAll('.view-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      currentView = tab.dataset.view;
      state.settings.view = currentView;
      document.getElementById('day-panel').classList.add('hidden');
      selectedDate = null;
      renderCurrentView();
      saveState();
    });
  });

  // ===== NAVIGATION =====
  document.getElementById('btn-prev').addEventListener('click', navPrev);
  document.getElementById('btn-next').addEventListener('click', navNext);
  document.getElementById('btn-today').addEventListener('click', goToday);

  // ===== DAY PANEL =====
  document.getElementById('btn-day-close').addEventListener('click', closeDayPanel);
  document.getElementById('btn-add-event').addEventListener('click', () => {
    openEventModal(null, selectedDate || todayStr());
  });

  // ===== EVENT MODAL =====
  document.getElementById('btn-event-save').addEventListener('click', saveEvent);
  document.getElementById('btn-event-cancel').addEventListener('click', closeEventModal);
  document.getElementById('btn-event-delete').addEventListener('click', deleteEvent);

  document.getElementById('ev-title').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') saveEvent();
    if (e.key === 'Escape') closeEventModal();
  });

  document.getElementById('ev-recurring').addEventListener('change', (e) => {
    document.getElementById('recurring-end-row').style.display = e.target.value ? '' : 'none';
  });

  // ===== SEARCH =====
  document.getElementById('btn-search-toggle').addEventListener('click', () => {
    const bar = document.getElementById('search-bar');
    if (bar.classList.contains('hidden')) {
      bar.classList.remove('hidden');
      document.getElementById('search-input').focus();
    } else {
      closeSearch();
    }
  });

  document.getElementById('btn-search-close').addEventListener('click', closeSearch);

  document.getElementById('search-input').addEventListener('input', (e) => {
    performSearch(e.target.value);
  });

  // ===== CALENDAR MANAGER =====
  document.getElementById('btn-manage-calendars').addEventListener('click', () => {
    renderCalendarsModal();
    document.getElementById('calendars-modal').classList.remove('hidden');
  });

  document.getElementById('btn-cal-close').addEventListener('click', () => {
    document.getElementById('calendars-modal').classList.add('hidden');
  });

  document.getElementById('btn-cal-add').addEventListener('click', async () => {
    const name = document.getElementById('new-cal-name').value.trim();
    if (!name) return;
    const color = document.getElementById('new-cal-color').value;
    const id = name.toLowerCase().replace(/\s+/g, '-') + '-' + genId().slice(0, 4);
    state.calendars.push({ id, name, color });
    document.getElementById('new-cal-name').value = '';
    await saveState();
    renderCalendarsModal();
  });

  // ===== IMPORT / EXPORT =====
  document.getElementById('btn-import-export').addEventListener('click', () => {
    document.getElementById('io-modal').classList.remove('hidden');
    document.getElementById('import-status').textContent = '';
  });

  document.getElementById('btn-io-close').addEventListener('click', () => {
    document.getElementById('io-modal').classList.add('hidden');
  });

  document.getElementById('btn-export-json').addEventListener('click', exportEvents);

  document.getElementById('btn-import-json').addEventListener('click', () => {
    document.getElementById('file-import-json').click();
  });

  document.getElementById('file-import-json').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) importEvents(file);
    e.target.value = '';
  });

  // ===== FULLSCREEN =====
  document.getElementById('btn-fullscreen').addEventListener('click', openFullscreen);

  // ===== ESCAPE KEY =====
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (!document.getElementById('event-modal').classList.contains('hidden')) closeEventModal();
      else if (!document.getElementById('calendars-modal').classList.contains('hidden'))
        document.getElementById('calendars-modal').classList.add('hidden');
      else if (!document.getElementById('io-modal').classList.contains('hidden'))
        document.getElementById('io-modal').classList.add('hidden');
      else if (!document.getElementById('search-bar').classList.contains('hidden')) closeSearch();
      else if (!document.getElementById('day-panel').classList.contains('hidden')) closeDayPanel();
    }
  });

  // Close modals on backdrop click
  ['event-modal', 'calendars-modal', 'io-modal'].forEach(id => {
    document.getElementById(id).addEventListener('click', (e) => {
      if (e.target.id === id) {
        document.getElementById(id).classList.add('hidden');
        if (id === 'event-modal') editingEventId = null;
      }
    });
  });

  // Schedule any pending reminders
  scheduleReminders();
}

// ============================================================
// BOOT
// ============================================================
document.addEventListener('DOMContentLoaded', init);
