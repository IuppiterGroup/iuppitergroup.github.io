/**
 * content.js — Iuppiter Clipboard
 * Listens for copy events on pages and forwards captured text to the background worker.
 * NEVER captures from password fields or other sensitive inputs.
 */
(function () {
  'use strict';

  /* ── Sensitive-field detection ─────────────────────────────────────── */

  function isSensitiveField(el) {
    if (!el) return false;

    const tag   = (el.tagName   || '').toLowerCase();
    const type  = (el.type      || '').toLowerCase();
    const name  = (el.name      || '').toLowerCase();
    const id    = (el.id        || '').toLowerCase();
    const ac    = (el.autocomplete || '').toLowerCase();
    const ph    = (el.placeholder  || '').toLowerCase();
    const role  = (el.getAttribute('role') || '').toLowerCase();
    const label = (el.getAttribute('aria-label') || '').toLowerCase();

    // Hard block: password input
    if (tag === 'input' && type === 'password') return true;

    // Autocomplete hints for sensitive data
    const sensitiveAC = [
      'current-password', 'new-password',
      'cc-number', 'cc-csc', 'cc-exp', 'cc-exp-month', 'cc-exp-year',
    ];
    if (sensitiveAC.some(s => ac === s)) return true;

    // Name / id keyword heuristics
    const sensitiveKw = [
      'password', 'passwd', 'pass', 'pwd',
      'secret', 'token', 'cvv', 'cvc', 'ssn',
      'creditcard', 'credit_card', 'cardnumber',
    ];
    if (sensitiveKw.some(k => name.includes(k) || id.includes(k))) return true;

    // Placeholder / aria-label heuristics
    if (sensitiveKw.some(k => ph.includes(k) || label.includes(k))) return true;

    return false;
  }

  /* ── Category detection ─────────────────────────────────────────────── */

  function detectCategory(text) {
    const t = text.trim();

    if (/^https?:\/\/\S+/.test(t) || /^www\.\S+\.\S+/.test(t)) return 'url';

    if (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(t)) return 'email';

    // Phone — strip spaces/dashes then test
    const digits = t.replace(/[\s\-().+]/g, '');
    if (/^\d{7,15}$/.test(digits) && /[\d\s\-().+]{7,}/.test(t)) return 'phone';

    // Code heuristics: multi-line with programming keywords or symbols
    if (
      (text.includes('\n') && /[{}();=><]/.test(text)) ||
      /^\s*(function |const |let |var |class |import |export |def |if \(|for \(|while \(|return |public |private |async )/.test(text) ||
      /^\s*[<][a-zA-Z][\w-]*[\s>]/.test(text) ||
      /^\s*[#$]\s/.test(text) && text.includes('\n')
    ) return 'code';

    return 'text';
  }

  /* ── Copy event listener ────────────────────────────────────────────── */

  document.addEventListener('copy', function (e) {
    try {
      // Bail out if focus is on a sensitive field
      const active = document.activeElement;
      if (isSensitiveField(active)) return;

      // Also bail if the nearest input ancestor is sensitive
      let node = active;
      while (node && node !== document.body) {
        if (isSensitiveField(node)) return;
        node = node.parentElement;
      }

      // Get the copied text
      let text = '';
      const sel = window.getSelection();
      if (sel) text = sel.toString();
      if (!text && e.clipboardData) text = e.clipboardData.getData('text/plain');
      if (!text || text.trim().length === 0) return;

      const category = detectCategory(text);

      let sourceHost = '';
      try { sourceHost = new URL(window.location.href).hostname; } catch (_) {}

      chrome.runtime.sendMessage({
        action: 'addClipboardItem',
        payload: {
          text,
          category,
          source: sourceHost,
          timestamp: Date.now(),
        },
      }).catch(() => { /* service worker may be sleeping — ignore */ });

    } catch (_) {
      // Never break page functionality
    }
  });
})();
