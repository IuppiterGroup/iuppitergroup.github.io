# ⚡ Iuppiter Clipboard

A privacy-first clipboard history manager for Chrome. Dark-themed, fast, and fully local — no servers, no analytics, no data collection.

---

## Features

| Feature | Details |
|---|---|
| **Auto-capture** | Saves every text copy automatically (last 100 items) |
| **Smart categories** | Auto-detects URLs, emails, phone numbers, code snippets |
| **Pinning** | Pin any item to keep it permanently at the top |
| **Search** | Filter history in real time |
| **Expand/collapse** | Long items show 2-line preview; click ▼ More to expand |
| **Character count** | Each item shows character count |
| **Copy back** | Click any item to copy it to clipboard |
| **Delete** | Delete individual items or clear all history |
| **Export** | Export full history as a `.txt` file |
| **Keyboard shortcut** | `Ctrl+Shift+C` (Mac: `Cmd+Shift+C`) to open popup |
| **Settings** | Configurable max size, auto-clear days |

---

## Privacy & Security

- **Password fields**: Text copied from `<input type="password">` is **never captured** — hardcoded, cannot be disabled.
- **Sensitive patterns**: Also skips inputs named/labelled: `password`, `token`, `secret`, `cvv`, `ssn`, `credit card`, etc.
- **Local only**: All data stored in `chrome.storage.local` — never leaves your browser.
- **No network**: Zero outbound requests. No CDN, no server, no analytics.
- **No tracking**: No user IDs, no telemetry, no third-party scripts.

---

## Installation

### From source (Developer Mode)

1. Clone or download this repository
2. Open Chrome → go to `chrome://extensions/`
3. Enable **Developer mode** (toggle, top right)
4. Click **Load unpacked**
5. Select the `clipboard-extension/` folder
6. The ⚡ icon will appear in your toolbar

### Keyboard shortcut

Default: **Ctrl+Shift+C**  
Override at: `chrome://extensions/shortcuts`

---

## File Structure

```
clipboard-extension/
├── manifest.json          # MV3 manifest
├── background.js          # Service worker — storage manager
├── content.js             # Copy event listener (runs on all pages)
├── popup.html             # Main popup UI
├── popup.js               # Popup logic
├── popup.css              # Popup styles (dark theme, gold/blue)
├── settings.html          # Options page
├── settings.js            # Options page logic
├── settings.css           # Options page styles
├── generate_icons.py      # Icon generator (Python + Pillow)
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

---

## Architecture (Manifest V3)

```
Page                Content Script          Background SW       Popup
────────────────────────────────────────────────────────────────────
user copies text ──► copy event listener ──► addClipboardItem
                     (detects sensitive        (dedup, trim,    ◄── getHistory
                      fields, category)         storage)        ──► render list
```

- **Content script** (`content.js`): Listens for `copy` DOM events, detects sensitive fields, categorizes text, sends to background.
- **Background service worker** (`background.js`): Manages `chrome.storage.local`. Handles deduplication, max-size trimming, pinning, deletion.
- **Popup** (`popup.html/js/css`): Reads history from background, renders sorted list (pinned first → recent), handles search/filter/copy/export.

---

## Settings

| Setting | Default | Description |
|---|---|---|
| Max items | 100 | Maximum clipboard entries (10–1000) |
| Auto-clear | Never | Delete items older than N days |

---

## Regenerating Icons

Requires Python 3 + Pillow:

```bash
pip install Pillow
python generate_icons.py
```

---

## License

MIT — use freely, modify freely.
