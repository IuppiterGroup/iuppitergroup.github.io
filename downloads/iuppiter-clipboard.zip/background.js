/**
 * background.js — Iuppiter Clipboard
 * Service worker: manages clipboard history storage and handles messages
 * from the content script and popup.
 */
'use strict';

const KEY_HISTORY  = 'iuppiter_history';
const KEY_PINNED   = 'iuppiter_pinned';
const KEY_SETTINGS = 'iuppiter_settings';

const DEFAULT_SETTINGS = {
  maxItems:       100,
  autoClearDays:  0,    // 0 = disabled
};

/* ── Storage helpers ────────────────────────────────────────────────── */

async function getSettings() {
  const d = await chrome.storage.local.get(KEY_SETTINGS);
  return { ...DEFAULT_SETTINGS, ...(d[KEY_SETTINGS] || {}) };
}

async function getHistory() {
  const d = await chrome.storage.local.get(KEY_HISTORY);
  return d[KEY_HISTORY] || [];
}

async function getPinned() {
  const d = await chrome.storage.local.get(KEY_PINNED);
  return d[KEY_PINNED] || [];
}

async function saveHistory(history) {
  await chrome.storage.local.set({ [KEY_HISTORY]: history });
}

async function savePinned(pinned) {
  await chrome.storage.local.set({ [KEY_PINNED]: pinned });
}

/* ── Business logic ─────────────────────────────────────────────────── */

async function addClipboardItem(item) {
  const settings = await getSettings();
  let history    = await getHistory();

  // Auto-clear stale items
  if (settings.autoClearDays > 0) {
    const cutoff = Date.now() - settings.autoClearDays * 86_400_000;
    history = history.filter(h => h.timestamp > cutoff);
  }

  // Deduplicate: if same text already exists, bump its timestamp to top
  const existingIdx = history.findIndex(h => h.text === item.text);
  if (existingIdx !== -1) {
    const existing = history.splice(existingIdx, 1)[0];
    existing.timestamp = item.timestamp;
    history.unshift(existing);
    await saveHistory(history);
    return;
  }

  // Build new entry
  const entry = {
    id:        `clip_${item.timestamp}_${Math.random().toString(36).slice(2, 9)}`,
    text:      item.text,
    category:  item.category || 'text',
    source:    item.source   || '',
    timestamp: item.timestamp,
  };

  history.unshift(entry);

  // Enforce max size (pinned items are immune to trimming)
  const pinned = await getPinned();
  const maxItems = settings.maxItems || 100;
  if (history.length > maxItems) {
    // Remove from the end, skipping pinned
    let removed = 0;
    const needed = history.length - maxItems;
    history = history.filter(h => {
      if (pinned.includes(h.id)) return true;   // always keep pinned
      if (removed < needed) { removed++; return false; }
      return true;
    });
  }

  await saveHistory(history);
}

async function deleteItem(id) {
  let history = await getHistory();
  let pinned  = await getPinned();

  history = history.filter(h => h.id !== id);
  pinned  = pinned.filter(p => p !== id);

  await saveHistory(history);
  await savePinned(pinned);
}

async function clearHistory(keepPinned = true) {
  if (keepPinned) {
    const pinned  = await getPinned();
    let history   = await getHistory();
    history = history.filter(h => pinned.includes(h.id));
    await saveHistory(history);
  } else {
    await saveHistory([]);
    await savePinned([]);
  }
}

async function togglePin(id) {
  let pinned = await getPinned();
  if (pinned.includes(id)) {
    pinned = pinned.filter(p => p !== id);
  } else {
    pinned.unshift(id);
  }
  await savePinned(pinned);
  return pinned.includes(id);
}

/* ── Message router ─────────────────────────────────────────────────── */

chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  const { action, payload } = msg;

  (async () => {
    try {
      switch (action) {

        case 'addClipboardItem':
          await addClipboardItem(payload);
          respond({ ok: true });
          break;

        case 'getHistory': {
          const history = await getHistory();
          const pinned  = await getPinned();
          respond({ ok: true, history, pinned });
          break;
        }

        case 'deleteItem':
          await deleteItem(payload.id);
          respond({ ok: true });
          break;

        case 'clearHistory':
          await clearHistory(payload?.keepPinned !== false);
          respond({ ok: true });
          break;

        case 'togglePin': {
          const isPinned = await togglePin(payload.id);
          respond({ ok: true, isPinned });
          break;
        }

        case 'getSettings': {
          const settings = await getSettings();
          respond({ ok: true, settings });
          break;
        }

        case 'saveSettings':
          await chrome.storage.local.set({ [KEY_SETTINGS]: payload });
          respond({ ok: true });
          break;

        case 'exportHistory': {
          const history = await getHistory();
          const pinned  = await getPinned();
          respond({ ok: true, history, pinned });
          break;
        }

        default:
          respond({ ok: false, error: `Unknown action: ${action}` });
      }
    } catch (err) {
      respond({ ok: false, error: err.message });
    }
  })();

  return true; // Keep the channel open for async response
});

/* ── Startup cleanup ────────────────────────────────────────────────── */

chrome.runtime.onStartup.addListener(async () => {
  const settings = await getSettings();
  if (settings.autoClearDays > 0) {
    const cutoff  = Date.now() - settings.autoClearDays * 86_400_000;
    let history   = await getHistory();
    history = history.filter(h => h.timestamp > cutoff);
    await saveHistory(history);
  }
});
