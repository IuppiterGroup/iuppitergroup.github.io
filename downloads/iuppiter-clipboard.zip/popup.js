/**
 * popup.js — Iuppiter Clipboard
 * Manages the popup UI: render, search, filter, pin, delete, copy, export.
 */
'use strict';

/* ── State ───────────────────────────────────────────────────────────── */
let allHistory   = [];
let pinnedIds    = new Set();
let activeFilter = 'all';
let searchQuery  = '';
let expandedIds  = new Set();

/* ── DOM refs ────────────────────────────────────────────────────────── */
const listContainer = document.getElementById('listContainer');
const emptyState    = document.getElementById('emptyState');
const searchInput   = document.getElementById('searchInput');
const searchClear   = document.getElementById('searchClear');
const filterTabs    = document.getElementById('filterTabs');
const footerCount   = document.getElementById('footerCount');
const histCount     = document.getElementById('histCount');
const exportBtn     = document.getElementById('exportBtn');
const clearBtn      = document.getElementById('clearBtn');
const settingsBtn   = document.getElementById('settingsBtn');
const toast         = document.getElementById('toast');

/* ── Helpers ─────────────────────────────────────────────────────────── */

function relativeTime(ts) {
  const diff = Date.now() - ts;
  if (diff < 60_000)             return 'just now';
  if (diff < 3_600_000)          return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000)         return `${Math.floor(diff / 3_600_000)}h ago`;
  if (diff < 7 * 86_400_000)     return `${Math.floor(diff / 86_400_000)}d ago`;
  return new Date(ts).toLocaleDateString();
}

function categoryLabel(cat) {
  return { url: 'URL', email: 'Email', phone: 'Phone', code: 'Code', text: 'Text' }[cat] || 'Text';
}

let toastTimer = null;
function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 1800);
}

function send(action, payload) {
  return new Promise(resolve =>
    chrome.runtime.sendMessage({ action, payload }, resolve)
  );
}

/* ── Render ──────────────────────────────────────────────────────────── */

function getFilteredItems() {
  let items = allHistory;

  // Filter by category
  if (activeFilter !== 'all') {
    items = items.filter(h => h.category === activeFilter);
  }

  // Filter by search query
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    items = items.filter(h =>
      h.text.toLowerCase().includes(q) ||
      (h.source || '').toLowerCase().includes(q)
    );
  }

  return items;
}

function buildItem(item, isPinned) {
  const div = document.createElement('div');
  div.className = 'clip-item' + (isPinned ? ' pinned' : '');
  div.dataset.id = item.id;

  const isExpanded = expandedIds.has(item.id);

  // Highlight search matches in preview text
  let previewText = item.text;
  if (searchQuery) {
    const re = new RegExp(searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    previewText = item.text.replace(re, m => `<mark style="background:rgba(196,164,74,0.3);color:inherit">${m}</mark>`);
  } else {
    previewText = escapeHtml(item.text);
  }

  div.innerHTML = `
    <div class="clip-meta">
      <span class="cat-badge cat-${item.category}">${categoryLabel(item.category)}</span>
      <span class="clip-source" title="${escapeHtml(item.source || '')}">${escapeHtml(item.source || 'unknown')}</span>
      <span class="clip-time">${relativeTime(item.timestamp)}</span>
    </div>
    <div class="clip-preview${isExpanded ? ' expanded' : ''}">${previewText}</div>
    <div class="clip-footer">
      <span class="clip-chars">${item.text.length.toLocaleString()} chars</span>
      <div class="clip-actions">
        ${item.text.split('\n').length > 2 || item.text.length > 120
          ? `<button class="action-btn expand-btn" data-id="${item.id}" title="${isExpanded ? 'Collapse' : 'Expand'}">${isExpanded ? '▲ Less' : '▼ More'}</button>`
          : ''}
        <button class="action-btn pin-btn${isPinned ? ' active' : ''}" data-id="${item.id}" title="${isPinned ? 'Unpin' : 'Pin to top'}">
          ${isPinned ? '📌' : '📍'}
        </button>
        <button class="action-btn del-btn" data-id="${item.id}" title="Delete">🗑</button>
      </div>
    </div>
  `;

  // Click item body → copy to clipboard
  div.addEventListener('click', async e => {
    if (e.target.closest('.action-btn')) return; // let buttons handle themselves
    await navigator.clipboard.writeText(item.text);
    div.classList.add('flash');
    setTimeout(() => div.classList.remove('flash'), 400);
    showToast('✓ Copied!');
  });

  // Expand/collapse
  const expandBtn = div.querySelector('.expand-btn');
  if (expandBtn) {
    expandBtn.addEventListener('click', e => {
      e.stopPropagation();
      const id = expandBtn.dataset.id;
      if (expandedIds.has(id)) {
        expandedIds.delete(id);
      } else {
        expandedIds.add(id);
      }
      render();
    });
  }

  // Pin / unpin
  div.querySelector('.pin-btn').addEventListener('click', async e => {
    e.stopPropagation();
    const id = e.currentTarget.dataset.id;
    await send('togglePin', { id });
    await loadData();
  });

  // Delete
  div.querySelector('.del-btn').addEventListener('click', async e => {
    e.stopPropagation();
    const id = e.currentTarget.dataset.id;
    await send('deleteItem', { id });
    await loadData();
    showToast('Deleted');
  });

  return div;
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function render() {
  const filtered = getFilteredItems();

  // Sort: pinned first, then by timestamp desc
  const pinned    = filtered.filter(h => pinnedIds.has(h.id));
  const unpinned  = filtered.filter(h => !pinnedIds.has(h.id));

  listContainer.querySelectorAll('.clip-item, .section-label').forEach(el => el.remove());
  emptyState.style.display = 'none';

  if (filtered.length === 0) {
    emptyState.style.display = '';
    if (searchQuery) {
      emptyState.querySelector('.empty-title').textContent = 'No results found';
      emptyState.lastChild.textContent = `Nothing matched "${searchQuery}"`;
    } else {
      emptyState.querySelector('.empty-title').textContent = 'No clipboard history yet';
    }
    footerCount.textContent = '';
    histCount.textContent = '';
    return;
  }

  const frag = document.createDocumentFragment();

  if (pinned.length > 0) {
    const lbl = document.createElement('div');
    lbl.className = 'section-label';
    lbl.textContent = `📌 Pinned (${pinned.length})`;
    frag.appendChild(lbl);
    pinned.forEach(item => frag.appendChild(buildItem(item, true)));
  }

  if (unpinned.length > 0) {
    if (pinned.length > 0) {
      const lbl = document.createElement('div');
      lbl.className = 'section-label';
      lbl.textContent = `🕐 History (${unpinned.length})`;
      frag.appendChild(lbl);
    }
    unpinned.forEach(item => frag.appendChild(buildItem(item, false)));
  }

  listContainer.insertBefore(frag, emptyState);

  const total = allHistory.length;
  footerCount.textContent = filtered.length !== total
    ? `${filtered.length} of ${total} items`
    : `${total} item${total !== 1 ? 's' : ''}`;
  histCount.textContent = total > 0 ? ` · ${total}` : '';
}

/* ── Data loading ────────────────────────────────────────────────────── */

async function loadData() {
  const resp = await send('getHistory', null);
  if (resp && resp.ok) {
    allHistory = resp.history || [];
    pinnedIds  = new Set(resp.pinned || []);
  }
  render();
}

/* ── Event listeners ─────────────────────────────────────────────────── */

// Search
searchInput.addEventListener('input', () => {
  searchQuery = searchInput.value.trim();
  searchClear.classList.toggle('visible', searchQuery.length > 0);
  render();
});

searchClear.addEventListener('click', () => {
  searchInput.value = '';
  searchQuery = '';
  searchClear.classList.remove('visible');
  searchInput.focus();
  render();
});

// Filter tabs
filterTabs.addEventListener('click', e => {
  const tab = e.target.closest('.tab');
  if (!tab) return;
  filterTabs.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  tab.classList.add('active');
  activeFilter = tab.dataset.cat;
  render();
});

// Settings
settingsBtn.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

// Export
exportBtn.addEventListener('click', async () => {
  const resp = await send('exportHistory', null);
  if (!resp || !resp.ok) return;

  const { history, pinned } = resp;
  const pinnedSet = new Set(pinned);

  const lines = [];
  lines.push('# Iuppiter Clipboard Export');
  lines.push(`# Exported: ${new Date().toLocaleString()}`);
  lines.push(`# Total items: ${history.length}`);
  lines.push('');

  // Pinned first
  const pinnedItems   = history.filter(h => pinnedSet.has(h.id));
  const regularItems  = history.filter(h => !pinnedSet.has(h.id));

  if (pinnedItems.length > 0) {
    lines.push('## PINNED ITEMS');
    pinnedItems.forEach((h, i) => {
      lines.push(`\n[${i + 1}] ${categoryLabel(h.category).toUpperCase()} | ${new Date(h.timestamp).toLocaleString()} | ${h.source || 'unknown'}`);
      lines.push(h.text);
      lines.push('---');
    });
  }

  if (regularItems.length > 0) {
    lines.push('\n## HISTORY');
    regularItems.forEach((h, i) => {
      lines.push(`\n[${i + 1}] ${categoryLabel(h.category).toUpperCase()} | ${new Date(h.timestamp).toLocaleString()} | ${h.source || 'unknown'}`);
      lines.push(h.text);
      lines.push('---');
    });
  }

  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `iuppiter-clipboard-${new Date().toISOString().slice(0, 10)}.txt`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('✓ Exported!');
});

// Clear all
clearBtn.addEventListener('click', async () => {
  if (!confirm('Clear all clipboard history?\n\nPinned items will be kept.')) return;
  await send('clearHistory', { keepPinned: true });
  await loadData();
  showToast('History cleared');
});

/* ── Init ────────────────────────────────────────────────────────────── */
loadData();
