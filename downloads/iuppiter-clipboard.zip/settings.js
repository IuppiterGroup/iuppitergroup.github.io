/**
 * settings.js — Iuppiter Clipboard
 * Handles the settings/options page logic.
 */
'use strict';

function send(action, payload) {
  return new Promise(resolve =>
    chrome.runtime.sendMessage({ action, payload }, resolve)
  );
}

function categoryLabel(cat) {
  return { url: 'URL', email: 'Email', phone: 'Phone', code: 'Code', text: 'Text' }[cat] || 'Text';
}

/* ── Load stats ──────────────────────────────────────────────────────── */
async function loadStats() {
  const resp = await send('getHistory', null);
  if (!resp || !resp.ok) return;

  const { history, pinned } = resp;
  const totalChars = history.reduce((sum, h) => sum + h.text.length, 0);

  document.getElementById('statTotal').textContent  = history.length;
  document.getElementById('statPinned').textContent = (pinned || []).length;
  document.getElementById('statChars').textContent  =
    totalChars >= 1_000_000
      ? `${(totalChars / 1_000_000).toFixed(1)}M`
      : totalChars >= 1_000
        ? `${(totalChars / 1_000).toFixed(1)}K`
        : totalChars;
}

/* ── Load settings ───────────────────────────────────────────────────── */
async function loadSettings() {
  const resp = await send('getSettings', null);
  if (!resp || !resp.ok) return;

  const s = resp.settings;
  document.getElementById('maxItems').value     = s.maxItems      || 100;
  document.getElementById('autoClearDays').value = String(s.autoClearDays || 0);
}

/* ── Save settings ───────────────────────────────────────────────────── */
async function saveSettings() {
  const maxItems     = Math.min(1000, Math.max(10, parseInt(document.getElementById('maxItems').value, 10) || 100));
  const autoClearDays = parseInt(document.getElementById('autoClearDays').value, 10) || 0;

  const settings = { maxItems, autoClearDays };
  await send('saveSettings', settings);

  const status = document.getElementById('saveStatus');
  status.classList.add('show');
  setTimeout(() => status.classList.remove('show'), 2500);
}

/* ── Export ──────────────────────────────────────────────────────────── */
async function exportHistory() {
  const resp = await send('exportHistory', null);
  if (!resp || !resp.ok) return;

  const { history, pinned } = resp;
  const pinnedSet = new Set(pinned || []);

  const lines = [];
  lines.push('# Iuppiter Clipboard Export');
  lines.push(`# Exported: ${new Date().toLocaleString()}`);
  lines.push(`# Total items: ${history.length}`);
  lines.push('');

  const pinnedItems  = history.filter(h => pinnedSet.has(h.id));
  const regularItems = history.filter(h => !pinnedSet.has(h.id));

  if (pinnedItems.length > 0) {
    lines.push('## PINNED ITEMS');
    pinnedItems.forEach((h, i) => {
      lines.push(`\n[${i + 1}] ${categoryLabel(h.category).toUpperCase()} | ${new Date(h.timestamp).toLocaleString()} | ${h.source || 'unknown'}`);
      lines.push(h.text);
      lines.push('---');
    });
    lines.push('');
  }

  if (regularItems.length > 0) {
    lines.push('## HISTORY');
    regularItems.forEach((h, i) => {
      lines.push(`\n[${i + 1}] ${categoryLabel(h.category).toUpperCase()} | ${new Date(h.timestamp).toLocaleString()} | ${h.source || 'unknown'}`);
      lines.push(h.text);
      lines.push('---');
    });
  }

  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `iuppiter-clipboard-${new Date().toISOString().slice(0, 10)}.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ── Event listeners ─────────────────────────────────────────────────── */

document.getElementById('saveBtn').addEventListener('click', saveSettings);

document.getElementById('exportBtn').addEventListener('click', exportHistory);

document.getElementById('clearAllBtn').addEventListener('click', async () => {
  if (!confirm('Clear all clipboard history?\n\nPinned items will be kept.')) return;
  await send('clearHistory', { keepPinned: true });
  await loadStats();
  alert('History cleared. Pinned items preserved.');
});

document.getElementById('clearIncPinnedBtn').addEventListener('click', async () => {
  if (!confirm('Delete ALL clipboard history including pinned items?\n\nThis cannot be undone.')) return;
  await send('clearHistory', { keepPinned: false });
  await loadStats();
  alert('All history deleted.');
});

/* ── Init ────────────────────────────────────────────────────────────── */
loadSettings();
loadStats();
