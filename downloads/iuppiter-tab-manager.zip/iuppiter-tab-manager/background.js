/**
 * Iuppiter Tab Manager — Background Service Worker
 * Tracks tab memory over time, manages badge alerts, handles alarms.
 */

const DEFAULT_SETTINGS = {
  alertThresholdMB: 2000,      // Badge alert when total memory exceeds this
  autoSuspendThresholdMB: 500, // Auto-suspend tabs over this (if enabled)
  autoSuspendEnabled: false,
  refreshIntervalSec: 10,
  closeBulkThresholdMB: 300
};

// In-memory store: tabId -> { memoryMB, title, url, updatedAt }
let tabMemoryStore = {};
let totalMemoryMB = 0;
let settings = { ...DEFAULT_SETTINGS };

// ── Init ──────────────────────────────────────────────────────────────────────

async function init() {
  const stored = await chrome.storage.local.get(['settings', 'tabMemoryStore']);
  if (stored.settings) {
    settings = { ...DEFAULT_SETTINGS, ...stored.settings };
  }
  if (stored.tabMemoryStore) {
    tabMemoryStore = stored.tabMemoryStore;
  }
  scheduleRefresh();
}

// ── Memory Polling ────────────────────────────────────────────────────────────

function scheduleRefresh() {
  chrome.alarms.clearAll(() => {
    chrome.alarms.create('memoryRefresh', {
      periodInMinutes: Math.max(settings.refreshIntervalSec, 10) / 60
    });
  });
}

async function refreshMemory() {
  try {
    const tabs = await chrome.tabs.query({});

    // Try chrome.processes API (most accurate)
    if (chrome.processes && chrome.processes.getProcessInfo) {
      await refreshViaProcessesAPI(tabs);
    } else {
      // Fallback: estimate based on tab state
      await refreshViaEstimation(tabs);
    }

    // Remove stale entries (closed tabs)
    const activeTabIds = new Set(tabs.map(t => t.id));
    for (const id of Object.keys(tabMemoryStore)) {
      if (!activeTabIds.has(parseInt(id))) {
        delete tabMemoryStore[id];
      }
    }

    // Recalculate total
    totalMemoryMB = Object.values(tabMemoryStore)
      .reduce((sum, t) => sum + (t.memoryMB || 0), 0);

    // Auto-suspend if enabled
    if (settings.autoSuspendEnabled) {
      await autoSuspendHighMemoryTabs();
    }

    // Update badge
    updateBadge();

    // Persist to storage
    await chrome.storage.local.set({ tabMemoryStore, totalMemoryMB });

  } catch (err) {
    console.error('[Iuppiter] refreshMemory error:', err);
  }
}

async function refreshViaProcessesAPI(tabs) {
  return new Promise((resolve) => {
    chrome.processes.getProcessInfo([], true, (processes) => {
      if (chrome.runtime.lastError) {
        resolve();
        return;
      }

      // Build tab -> process map
      const tabToProcess = {};
      for (const [pid, proc] of Object.entries(processes)) {
        if (proc.tabs) {
          for (const tabId of proc.tabs) {
            tabToProcess[tabId] = proc;
          }
        }
      }

      const now = Date.now();
      for (const tab of tabs) {
        const proc = tabToProcess[tab.id];
        let memMB = 0;
        if (proc && proc.privateMemory) {
          // Distribute memory across tabs sharing same process
          const tabsInProc = (proc.tabs || []).length || 1;
          memMB = Math.round(proc.privateMemory / tabsInProc / (1024 * 1024) * 10) / 10;
        } else if (tab.discarded) {
          memMB = 0;
        } else {
          // Minimum estimate for active tabs without process data
          memMB = 30;
        }

        tabMemoryStore[tab.id] = {
          memoryMB: memMB,
          title: tab.title || 'Untitled',
          url: tab.url || '',
          favIconUrl: tab.favIconUrl || '',
          active: tab.active,
          discarded: tab.discarded || false,
          windowId: tab.windowId,
          updatedAt: now
        };
      }
      resolve();
    });
  });
}

async function refreshViaEstimation(tabs) {
  const now = Date.now();
  for (const tab of tabs) {
    let memMB;
    if (tab.discarded) {
      memMB = 0;
    } else if (tab.active) {
      // Active tabs use more memory; preserve existing if recent
      const existing = tabMemoryStore[tab.id];
      if (existing && (now - existing.updatedAt) < 30000) {
        memMB = existing.memoryMB;
      } else {
        // Randomized estimate for demo: 50-400MB for active tabs
        memMB = existing ? existing.memoryMB : Math.round(50 + Math.random() * 150);
      }
    } else {
      const existing = tabMemoryStore[tab.id];
      if (existing && (now - existing.updatedAt) < 30000) {
        memMB = existing.memoryMB;
      } else {
        memMB = existing ? existing.memoryMB : Math.round(20 + Math.random() * 100);
      }
    }

    tabMemoryStore[tab.id] = {
      memoryMB: memMB,
      title: tab.title || 'Untitled',
      url: tab.url || '',
      favIconUrl: tab.favIconUrl || '',
      active: tab.active,
      discarded: tab.discarded || false,
      windowId: tab.windowId,
      updatedAt: now
    };
  }
}

// ── Auto-Suspend ──────────────────────────────────────────────────────────────

async function autoSuspendHighMemoryTabs() {
  const threshold = settings.autoSuspendThresholdMB;
  for (const [idStr, data] of Object.entries(tabMemoryStore)) {
    if (data.memoryMB > threshold && !data.active && !data.discarded) {
      try {
        await chrome.tabs.discard(parseInt(idStr));
        tabMemoryStore[idStr].discarded = true;
        tabMemoryStore[idStr].memoryMB = 0;
      } catch (e) {
        // Tab may not be discardable (pinned, active, etc.)
      }
    }
  }
}

// ── Badge ─────────────────────────────────────────────────────────────────────

function updateBadge() {
  const over = totalMemoryMB > settings.alertThresholdMB;
  if (over) {
    const label = totalMemoryMB >= 10000 ? '>10G' :
                  totalMemoryMB >= 1000 ? `${Math.round(totalMemoryMB / 1000)}G` :
                  `${Math.round(totalMemoryMB)}M`;
    chrome.action.setBadgeText({ text: label });
    chrome.action.setBadgeBackgroundColor({ color: '#c0392b' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// ── Message Handler ───────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {
    case 'GET_TAB_DATA':
      sendResponse({ tabMemoryStore, totalMemoryMB, settings });
      return true;

    case 'CLOSE_TAB':
      chrome.tabs.remove(msg.tabId, () => {
        delete tabMemoryStore[msg.tabId];
        sendResponse({ ok: true });
      });
      return true;

    case 'SUSPEND_TAB':
      chrome.tabs.discard(msg.tabId, () => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          if (tabMemoryStore[msg.tabId]) {
            tabMemoryStore[msg.tabId].discarded = true;
            tabMemoryStore[msg.tabId].memoryMB = 0;
          }
          sendResponse({ ok: true });
        }
      });
      return true;

    case 'CLOSE_BULK':
      (async () => {
        const threshold = msg.thresholdMB;
        const toClose = Object.entries(tabMemoryStore)
          .filter(([, d]) => d.memoryMB > threshold && !d.active)
          .map(([id]) => parseInt(id));
        if (toClose.length > 0) {
          await chrome.tabs.remove(toClose);
          for (const id of toClose) delete tabMemoryStore[id];
        }
        sendResponse({ ok: true, closed: toClose.length });
      })();
      return true;

    case 'UPDATE_SETTINGS':
      settings = { ...settings, ...msg.settings };
      chrome.storage.local.set({ settings });
      scheduleRefresh();
      sendResponse({ ok: true });
      return true;

    case 'REFRESH_NOW':
      refreshMemory().then(() => sendResponse({ ok: true }));
      return true;
  }
});

// ── Alarm Handler ─────────────────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'memoryRefresh') {
    refreshMemory();
  }
});

// ── Tab Event Listeners ───────────────────────────────────────────────────────

chrome.tabs.onRemoved.addListener((tabId) => {
  delete tabMemoryStore[tabId];
  chrome.storage.local.set({ tabMemoryStore });
});

chrome.tabs.onCreated.addListener(() => {
  // Trigger a refresh to pick up the new tab
  setTimeout(refreshMemory, 1000);
});

// ── Start ─────────────────────────────────────────────────────────────────────

init().then(() => refreshMemory());
