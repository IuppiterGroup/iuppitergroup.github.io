/**
 * Iuppiter Tab Manager - Background Service Worker
 * Measures each tab's JavaScript heap, manages badge alerts, handles alarms.
 *
 * What is measured: performance.memory.usedJSHeapSize, reported by the content
 * script running in each tab's top frame. This is the page's JavaScript heap
 * (Chrome only), not the tab's total process memory. Tabs where it cannot be
 * read (chrome:// pages, the Web Store, tabs opened before the extension was
 * installed or that have not finished loading) are reported as "n/a", and
 * discarded tabs as "suspended". No value is ever estimated or invented.
 */

const DEFAULT_SETTINGS = {
  alertThresholdMB: 1000,      // Badge alert when the JS heap total across tabs exceeds this
  autoSuspendThresholdMB: 300, // Auto-suspend background tabs whose JS heap exceeds this (if enabled)
  autoSuspendEnabled: false,
  refreshIntervalSec: 10,
  closeBulkThresholdMB: 150
};

const MEASURE_TIMEOUT_MS = 1500;
const ALARM_MIN_SEC = 30; // Chrome does not fire alarms more often than every 30s

// In-memory store: tabId -> { jsHeapMB, status, title, url, ... }
//   status: 'ok' (measured), 'na' (not measurable), 'suspended' (discarded)
let tabStore = {};
let totalJsHeapMB = 0;
let measuredCount = 0;
let lastRefreshAt = 0;
let settings = { ...DEFAULT_SETTINGS };

// ── Init ──────────────────────────────────────────────────────────────────────

async function init() {
  const stored = await chrome.storage.local.get(['settings', 'tabStore']);
  if (stored.settings) {
    settings = { ...DEFAULT_SETTINGS, ...stored.settings };
  }
  if (stored.tabStore) {
    tabStore = stored.tabStore;
  }
  scheduleRefresh();
}

const ready = init();

chrome.runtime.onInstalled.addListener(async (details) => {
  // v1.0 stored randomized estimates and RAM-based thresholds. Drop the fake
  // numbers and move the thresholds to JS heap defaults.
  await chrome.storage.local.remove(['tabMemoryStore', 'totalMemoryMB']);
  if (details.reason === 'update' && /^1\.0\./.test(details.previousVersion || '')) {
    await ready;
    settings = {
      ...settings,
      alertThresholdMB: DEFAULT_SETTINGS.alertThresholdMB,
      autoSuspendThresholdMB: DEFAULT_SETTINGS.autoSuspendThresholdMB,
      closeBulkThresholdMB: DEFAULT_SETTINGS.closeBulkThresholdMB
    };
    await chrome.storage.local.set({ settings });
  }
});

// ── Measurement ───────────────────────────────────────────────────────────────

function scheduleRefresh() {
  chrome.alarms.clearAll(() => {
    chrome.alarms.create('memoryRefresh', {
      periodInMinutes: Math.max(settings.refreshIntervalSec, ALARM_MIN_SEC) / 60
    });
  });
}

function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms))
  ]);
}

function isScriptablePage(url) {
  return /^(https?|file):/i.test(url || '');
}

// Ask the tab's content script for performance.memory. Returns { status, jsHeapMB }.
async function measureTab(tab) {
  if (tab.discarded) return { status: 'suspended', jsHeapMB: null };
  if (!isScriptablePage(tab.url)) return { status: 'na', jsHeapMB: null };
  try {
    const resp = await withTimeout(
      chrome.tabs.sendMessage(tab.id, { type: 'MEASURE_MEMORY' }, { frameId: 0 }),
      MEASURE_TIMEOUT_MS
    );
    if (resp && resp.ok && typeof resp.usedJSHeapSize === 'number' && resp.usedJSHeapSize > 0) {
      return {
        status: 'ok',
        jsHeapMB: Math.round(resp.usedJSHeapSize / (1024 * 1024) * 10) / 10,
        jsHeapLimitMB: typeof resp.jsHeapSizeLimit === 'number'
          ? Math.round(resp.jsHeapSizeLimit / (1024 * 1024))
          : null
      };
    }
  } catch (e) {
    // No content script in this tab (opened before install, restricted page,
    // still loading, frozen) -> not measurable.
  }
  return { status: 'na', jsHeapMB: null };
}

let refreshInFlight = null;

function refreshMemory() {
  if (!refreshInFlight) {
    refreshInFlight = doRefresh().finally(() => { refreshInFlight = null; });
  }
  return refreshInFlight;
}

async function doRefresh() {
  try {
    await ready;
    const tabs = await chrome.tabs.query({});
    const measurements = await Promise.all(tabs.map(measureTab));
    const now = Date.now();

    const next = {};
    tabs.forEach((tab, i) => {
      const m = measurements[i];
      next[tab.id] = {
        jsHeapMB: m.jsHeapMB,
        jsHeapLimitMB: m.jsHeapLimitMB || null,
        status: m.status,
        title: tab.title || 'Untitled',
        url: tab.url || '',
        favIconUrl: tab.favIconUrl || '',
        active: tab.active,
        discarded: tab.discarded || false,
        windowId: tab.windowId,
        updatedAt: now
      };
    });
    tabStore = next;

    if (settings.autoSuspendEnabled) {
      await autoSuspendHeavyTabs();
    }

    recalcTotals();
    lastRefreshAt = now;
    updateBadge();

    await chrome.storage.local.set({ tabStore, totalJsHeapMB, measuredCount });
  } catch (err) {
    console.error('[Iuppiter] refreshMemory error:', err);
  }
}

function recalcTotals() {
  const measured = Object.values(tabStore).filter(t => t.status === 'ok' && typeof t.jsHeapMB === 'number');
  measuredCount = measured.length;
  totalJsHeapMB = Math.round(measured.reduce((sum, t) => sum + t.jsHeapMB, 0) * 10) / 10;
}

function markSuspended(id) {
  if (tabStore[id]) {
    tabStore[id].discarded = true;
    tabStore[id].status = 'suspended';
    tabStore[id].jsHeapMB = null;
  }
}

// ── Auto-Suspend ──────────────────────────────────────────────────────────────

async function autoSuspendHeavyTabs() {
  const threshold = settings.autoSuspendThresholdMB;
  for (const [idStr, data] of Object.entries(tabStore)) {
    if (data.status === 'ok' && data.jsHeapMB > threshold && !data.active && !data.discarded) {
      try {
        await chrome.tabs.discard(parseInt(idStr));
        markSuspended(idStr);
      } catch (e) {
        // Tab may not be discardable (active, etc.)
      }
    }
  }
}

// ── Badge ─────────────────────────────────────────────────────────────────────

function updateBadge() {
  const over = measuredCount > 0 && totalJsHeapMB > settings.alertThresholdMB;
  if (over) {
    const label = totalJsHeapMB >= 10240 ? '>10G' :
                  totalJsHeapMB >= 1024 ? `${(totalJsHeapMB / 1024).toFixed(1)}G` :
                  `${Math.round(totalJsHeapMB)}M`;
    chrome.action.setBadgeText({ text: label });
    chrome.action.setBadgeBackgroundColor({ color: '#c0392b' });
    chrome.action.setTitle({ title: `Iuppiter Tab Manager: JS heap total ${label} is over your alert threshold` });
  } else {
    chrome.action.setBadgeText({ text: '' });
    chrome.action.setTitle({ title: 'Iuppiter Tab Manager' });
  }
}

// ── Message Handler ───────────────────────────────────────────────────────────

function snapshot() {
  return { tabStore, totalJsHeapMB, measuredCount, lastRefreshAt, settings };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {
    case 'GET_TAB_DATA':
      ready.then(async () => {
        if (!lastRefreshAt) await refreshMemory();
        sendResponse(snapshot());
      });
      return true;

    case 'REFRESH_NOW':
      refreshMemory().then(() => sendResponse({ ok: true, ...snapshot() }));
      return true;

    case 'CLOSE_TAB':
      chrome.tabs.remove(msg.tabId, () => {
        delete tabStore[msg.tabId];
        recalcTotals();
        updateBadge();
        sendResponse({ ok: true });
      });
      return true;

    case 'SUSPEND_TAB':
      chrome.tabs.discard(msg.tabId, () => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        } else {
          markSuspended(msg.tabId);
          recalcTotals();
          updateBadge();
          sendResponse({ ok: true });
        }
      });
      return true;

    case 'CLOSE_BULK':
      (async () => {
        const threshold = msg.thresholdMB;
        const toClose = Object.entries(tabStore)
          .filter(([, d]) => d.status === 'ok' && d.jsHeapMB > threshold && !d.active)
          .map(([id]) => parseInt(id));
        if (toClose.length > 0) {
          await chrome.tabs.remove(toClose);
          for (const id of toClose) delete tabStore[id];
          recalcTotals();
          updateBadge();
        }
        sendResponse({ ok: true, closed: toClose.length });
      })();
      return true;

    case 'UPDATE_SETTINGS':
      settings = { ...settings, ...msg.settings };
      chrome.storage.local.set({ settings });
      scheduleRefresh();
      updateBadge();
      sendResponse({ ok: true });
      return true;
  }
});

// ── Alarm Handler ─────────────────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'memoryRefresh') {
    refreshMemory();
  }
});

// ── Tab Event Listeners ───────────────────────────────────────────────────────

chrome.tabs.onRemoved.addListener((tabId) => {
  delete tabStore[tabId];
  recalcTotals();
  chrome.storage.local.set({ tabStore, totalJsHeapMB, measuredCount });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  // Pick up new pages once they finish loading (content script is ready then)
  if (changeInfo.status === 'complete' || changeInfo.discarded !== undefined) {
    setTimeout(refreshMemory, 500);
  }
});

// ── Start ─────────────────────────────────────────────────────────────────────

ready.then(() => refreshMemory());
