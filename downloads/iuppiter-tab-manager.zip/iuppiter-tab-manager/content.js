/**
 * Iuppiter Tab Manager — Content Script
 * Minimal footprint. Used for future memory measurement via
 * performance.measureUserAgentSpecificMemory() in supported contexts.
 */

(async () => {
  // Only attempt in top-level frames
  if (window !== window.top) return;

  // Listen for memory probe requests from the background
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'MEASURE_MEMORY') {
      if (typeof performance !== 'undefined' &&
          typeof performance.measureUserAgentSpecificMemory === 'function') {
        performance.measureUserAgentSpecificMemory()
          .then(result => sendResponse({ ok: true, bytes: result.bytes }))
          .catch(err => sendResponse({ ok: false, error: err.message }));
        return true; // async
      } else {
        sendResponse({ ok: false, error: 'API not available' });
      }
    }
  });
})();
