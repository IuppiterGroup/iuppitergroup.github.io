/**
 * Iuppiter Tab Manager - Content Script
 * Reports this page's JavaScript heap (performance.memory, Chrome only) to the
 * background when asked. This is the page's JS heap, not total tab memory.
 */

(() => {
  // Only the top-level frame answers for the tab
  if (window !== window.top) return;
  if (window.__iuppiterTabManager) return;
  window.__iuppiterTabManager = true;

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.type !== 'MEASURE_MEMORY') return;
    const mem = typeof performance !== 'undefined' ? performance.memory : null;
    if (mem && typeof mem.usedJSHeapSize === 'number') {
      sendResponse({
        ok: true,
        usedJSHeapSize: mem.usedJSHeapSize,
        totalJSHeapSize: mem.totalJSHeapSize,
        jsHeapSizeLimit: mem.jsHeapSizeLimit
      });
    } else {
      sendResponse({ ok: false, error: 'performance.memory not available' });
    }
  });
})();
