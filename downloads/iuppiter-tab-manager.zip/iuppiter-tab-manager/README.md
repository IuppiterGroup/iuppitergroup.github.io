# 🏛️ Iuppiter Tab Manager

A Chrome extension that shows each tab's JavaScript heap and helps you clean up heavy tabs. Built with Manifest V3.

---

## Features

- **JS heap monitoring**: lists all open tabs with the page's JavaScript heap (`performance.memory.usedJSHeapSize`), or n/a where it can't be read
- **Sort by JS heap**: heaviest pages shown first
- **Color coding** (JS heap): 🟢 Green (under 50MB), 🟡 Yellow (50 to 200MB), 🔴 Red (200MB+)
- **Header**: tab count, JS heap total, count of tabs at 200MB+, bar showing the total against your alert threshold
- **One-click close**: close any tab instantly
- **Suspend tab**: discard tab content (`chrome.tabs.discard`) to free memory while preserving the URL
- **Bulk close**: "Close tabs with JS heap over X MB" with configurable threshold
- **Domain grouping**: toggle between flat list and grouped-by-domain view
- **Search/filter**: find tabs by title or domain
- **Auto-refresh**: the popup re-measures every 10 seconds (configurable)
- **Settings panel**: JS heap alert threshold, refresh interval, auto-suspend threshold and toggle
- **Badge alert**: extension badge turns red and shows the JS heap total when it exceeds the threshold

---

## Install

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked**
4. Select this folder (`tab-manager-extension/`)
5. The Iuppiter icon will appear in your toolbar

> **Note:** Click the puzzle piece icon → pin Iuppiter Tab Manager for easy access.

---

## What the numbers mean

Stable Chrome gives extensions no per-tab process memory API (`chrome.processes` only exists on the Dev channel), so this extension does not show total tab RAM. Instead, the content script reads `performance.memory.usedJSHeapSize` in each tab and reports it as **JS heap**:

- It is the page's JavaScript heap only, not images, DOM, GPU or the rest of the renderer process.
- It is Chrome-only. With site isolation (the desktop default) the value is precise; where a renderer process is not locked to one site, Chrome rounds it and refreshes it at most every 20 minutes.
- The heap belongs to the tab's renderer process, so same-site tabs that share a process report the same shared heap.
- Tabs where it can't be read show **n/a**: `chrome://` and other browser pages, the Chrome Web Store, pages that are still loading, and tabs that were already open when the extension was installed (reload them to measure).
- Discarded tabs show **suspended**.
- Nothing is estimated: if a value can't be measured, none is shown.

---

## File Structure

```
tab-manager-extension/
├── manifest.json          # MV3 manifest
├── background.js          # Service worker: memory polling, badge, alarms
├── popup.html             # Popup UI structure
├── popup.css              # Dark theme styles (Iuppiter branding)
├── popup.js               # Popup logic: render, actions, settings
├── content.js             # Content script: reports performance.memory (JS heap)
├── suspended.html         # Placeholder page for manually suspended tabs
├── generate_icons.py      # Python+Pillow icon generator
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

---

## Branding

- **Background:** `#1a1a2e` (deep navy)
- **Accent Gold:** `#c4a44a`
- **Accent Blue:** `#2b579a`
- **Text:** `#f0e6cc`

---

## Regenerating Icons

```bash
pip install Pillow
python generate_icons.py
```

---

*Built by Legate for the Iuppiter project.*
