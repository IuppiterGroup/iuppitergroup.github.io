# 🏛️ Iuppiter Tab Manager

A Chrome extension that monitors browser tab memory usage and helps you clean up memory hogs. Built with Manifest V3.

---

## Features

- **Live memory monitoring** — Lists all open tabs with their memory usage (via `chrome.processes` API, with fallback estimation)
- **Sort by memory** — Highest memory consumers shown first
- **Color coding** — 🟢 Green (<100MB), 🟡 Yellow (100–500MB), 🔴 Red (>500MB)
- **Total memory header** — Tab count, total RAM used, high-memory tab count, memory bar
- **One-click close** — Close any tab instantly
- **Suspend tab** — Discard tab content (`chrome.tabs.discard`) to free memory while preserving the URL
- **Bulk close** — "Close all tabs over X MB" with configurable threshold
- **Domain grouping** — Toggle between flat list and grouped-by-domain view
- **Search/filter** — Find tabs by title or domain
- **Auto-refresh** — Memory stats refresh every 10 seconds (configurable)
- **Settings panel** — Alert threshold, refresh interval, auto-suspend toggle
- **Badge alert** — Extension badge turns red and shows total memory when threshold exceeded

---

## Install

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked**
4. Select this folder (`tab-manager-extension/`)
5. The Iuppiter icon will appear in your toolbar

> **Note:** Click the puzzle piece icon → pin Iuppiter Tab Manager for easy access.

---

## Memory API Notes

Chrome extensions can access real per-tab memory data via the **`chrome.processes`** API (requires the `"processes"` permission in manifest). This API is Chrome-only (not Chromium forks or Edge).

If `chrome.processes` is unavailable (e.g., in some enterprise deployments), the extension falls back to tab-state estimation — active tabs are estimated at 50–200MB, background tabs at 20–100MB.

To see real memory data, ensure:
- You're using Google Chrome (not Brave, Edge, or other Chromium forks)
- No enterprise policy blocks the processes API

---

## File Structure

```
tab-manager-extension/
├── manifest.json          # MV3 manifest
├── background.js          # Service worker: memory polling, badge, alarms
├── popup.html             # Popup UI structure
├── popup.css              # Dark theme styles (Iuppiter branding)
├── popup.js               # Popup logic: render, actions, settings
├── content.js             # Content script (performance.measureUserAgentSpecificMemory)
├── suspended.html         # Placeholder page for manually suspended tabs
├── generate_icons.py      # Python+Pillow icon generator
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

---

## Branding

- **Background:** `#1a1a2e` (deep navy)
- **Accent Gold:** `#c4a44a`
- **Accent Blue:** `#2b579a`
- **Text:** `#f0e6cc`

---

## Regenerating Icons

```bash
pip install Pillow
python generate_icons.py
```

---

*Built by Legate for the Iuppiter project.*
