/**
 * Iuppiter Tab Manager - Popup Script
 */

// ── State ──────────────────────────────────────────────────────────────────────

let tabData = {};          // tabId -> tab info + JS heap (jsHeapMB, status)
let measuredCount = 0;
let settings = {};
let currentView = 'list';  // 'list' | 'domain'
let searchQuery = '';
let lastRefreshedTime = null;
let refreshTimer = null;
let collapsedDomains = new Set();

// ── Memory helpers ─────────────────────────────────────────────────────────────

// Thresholds are for a page's JavaScript heap (performance.memory.usedJSHeapSize)
const HEAP_YELLOW_MB = 50;
const HEAP_RED_MB = 200;

function heapOf(d) {
  return d && d.status === 'ok' && typeof d.jsHeapMB === 'number' ? d.jsHeapMB : null;
}

function formatMB(mb) {
  if (mb === null || mb === undefined) return 'n/a';
  if (mb >= 1024) return `${(mb / 1024).toFixed(1)} GB`;
  if (mb < 10) return `${mb.toFixed(1)} MB`;
  return `${Math.round(mb)} MB`;
}

function memColor(mb) {
  if (mb === null || mb === undefined) return 'gray';
  if (mb < HEAP_YELLOW_MB) return 'green';
  if (mb < HEAP_RED_MB) return 'yellow';
  return 'red';
}

function sumHeap(list) {
  const vals = list.map(heapOf).filter(v => v !== null);
  return vals.length ? vals.reduce((s, v) => s + v, 0) : null;
}

function getDomain(url) {
  if (!url || url.startsWith('chrome://') || url.startsWith('chrome-extension://')) {
    return url ? url.split('/')[2] || url : '(internal)';
  }
  try {
    return new URL(url).hostname.replace(/^www\./, '') || '(unknown)';
  } catch {
    return '(unknown)';
  }
}

function getFaviconUrl(tab) {
  if (tab.favIconUrl && tab.favIconUrl.startsWith('http')) return tab.favIconUrl;
  if (tab.url) {
    try {
      const u = new URL(tab.url);
      if (u.protocol === 'https:' || u.protocol === 'http:') {
        return `${u.origin}/favicon.ico`;
      }
    } catch {}
  }
  return null;
}

// ── Fetch from background ──────────────────────────────────────────────────────

function fetchTabData() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'GET_TAB_DATA' }, (resp) => {
      if (chrome.runtime.lastError || !resp) {
        resolve(null);
        return;
      }
      resolve(resp);
    });
  });
}

// ── Render ─────────────────────────────────────────────────────────────────────

function renderAll() {
  const entries = Object.entries(tabData);

  // Apply search filter
  const filtered = entries.filter(([, d]) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (d.title || '').toLowerCase().includes(q) ||
           getDomain(d.url).toLowerCase().includes(q);
  });

  // Sort by JS heap descending; unmeasured (n/a, suspended) tabs last
  filtered.sort((a, b) => (heapOf(b[1]) ?? -1) - (heapOf(a[1]) ?? -1));

  const container = document.getElementById('tabListContent');
  container.innerHTML = '';

  if (filtered.length === 0) {
    container.innerHTML = '<div class="empty-state">No tabs found.</div>';
  } else if (currentView === 'list') {
    for (const [id, data] of filtered) {
      container.appendChild(buildTabCard(parseInt(id), data));
    }
  } else {
    renderDomainView(filtered, container);
  }

  updateHeader(entries);
}

function updateHeader(entries) {
  const datas = entries.map(([, d]) => d);
  const totalMB = sumHeap(datas);
  const measured = datas.filter(d => heapOf(d) !== null).length;
  const redCount = datas.filter(d => (heapOf(d) ?? 0) >= HEAP_RED_MB).length;

  document.getElementById('statTabCount').textContent = entries.length;
  document.getElementById('statTotalMem').textContent = formatMB(totalMB);
  document.getElementById('statRedCount').textContent = measured ? redCount : 'n/a';
  document.getElementById('heapNote').textContent =
    `JS heap measured in ${measured} of ${entries.length} tab${entries.length !== 1 ? 's' : ''}. ` +
    'Page JavaScript memory only, not total tab memory.';

  // Bar: JS heap total as a share of the alert threshold
  const alertThreshold = settings.alertThresholdMB || 1000;
  const pct = totalMB === null ? 0 : Math.min((totalMB / alertThreshold) * 100, 100);
  const fill = document.getElementById('memBarFill');
  fill.style.width = `${pct}%`;
  fill.className = `memory-bar-fill ${pct > 70 ? 'warn' : ''}`;
  document.getElementById('memBarLabel').textContent = totalMB === null ? 'n/a' : `${Math.round(pct)}%`;

  // Alert
  const banner = document.getElementById('alertBanner');
  banner.classList.toggle('visible', totalMB !== null && totalMB > alertThreshold);

  // Last refreshed
  if (lastRefreshedTime) {
    const secs = Math.round((Date.now() - lastRefreshedTime) / 1000);
    document.getElementById('lastRefreshed').textContent =
      secs < 5 ? 'Just now' : `${secs}s ago`;
  }
}

function buildTabCard(tabId, data) {
  const card = document.createElement('div');
  card.className = `tab-card${data.active ? ' active-tab' : ''}${data.discarded ? ' discarded' : ''}`;
  card.dataset.tabId = tabId;

  const domain = getDomain(data.url);
  const heap = heapOf(data);
  const color = memColor(heap);
  const memText = data.status === 'suspended' || data.discarded ? 'suspended' : formatMB(heap);
  const memTitle = heap !== null
    ? 'JS heap (performance.memory.usedJSHeapSize)'
    : (data.status === 'suspended' || data.discarded
      ? 'Tab is suspended'
      : 'JS heap not available for this tab (browser page, or page loaded before the extension)');
  const faviconUrl = getFaviconUrl(data);

  // Mini bar width: scale to 500MB of JS heap
  const barPct = heap === null ? 0 : Math.min((heap / 500) * 100, 100);

  card.innerHTML = `
    ${faviconUrl
      ? `<img class="tab-favicon" src="${faviconUrl}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex'" alt="">`
      : ''}
    <div class="tab-favicon-placeholder" style="${faviconUrl ? 'display:none' : ''}">📄</div>
    <div class="tab-info">
      <div class="tab-title">
        ${escHtml(data.title || 'Untitled')}
        ${data.active ? '<span class="tag-active">ACTIVE</span>' : ''}
        ${data.discarded ? '<span class="tag-suspended">SUSPENDED</span>' : ''}
      </div>
      <div class="tab-domain">${escHtml(domain)}</div>
    </div>
    <div class="tab-memory-col">
      <div class="tab-memory-text ${color}" title="${memTitle}">${memText}</div>
      <div class="tab-memory-mini-bar">
        <div class="tab-memory-mini-fill ${color}" style="width:${barPct}%"></div>
      </div>
    </div>
    <div class="tab-actions">
      ${!data.discarded ? `<button class="btn-tab-action suspend-btn" data-id="${tabId}" title="Suspend tab">⏸</button>` : ''}
      <button class="btn-tab-action close-btn" data-id="${tabId}" title="Close tab">✕</button>
    </div>
  `;

  // Click card → focus tab
  card.addEventListener('click', (e) => {
    if (e.target.closest('.tab-actions')) return;
    chrome.tabs.update(tabId, { active: true }, () => {
      if (data.windowId) chrome.windows.update(data.windowId, { focused: true });
    });
  });

  return card;
}

function renderDomainView(filtered, container) {
  // Group by domain
  const groups = {};
  for (const [id, data] of filtered) {
    const domain = getDomain(data.url);
    if (!groups[domain]) groups[domain] = [];
    groups[domain].push([parseInt(id), data]);
  }

  // Sort groups by total JS heap
  const sortedDomains = Object.entries(groups)
    .sort((a, b) => {
      const sumA = sumHeap(a[1].map(([, d]) => d)) ?? -1;
      const sumB = sumHeap(b[1].map(([, d]) => d)) ?? -1;
      return sumB - sumA;
    });

  for (const [domain, tabs] of sortedDomains) {
    const group = document.createElement('div');
    const isCollapsed = collapsedDomains.has(domain);
    group.className = `domain-group${isCollapsed ? ' collapsed' : ''}`;

    const totalMem = sumHeap(tabs.map(([, d]) => d));
    const sampleFavicon = getFaviconUrl(tabs[0][1]);

    const header = document.createElement('div');
    header.className = 'domain-header';
    header.innerHTML = `
      ${sampleFavicon
        ? `<img class="domain-favicon" src="${sampleFavicon}" onerror="this.style.display='none'" alt="">`
        : '<span style="font-size:12px">🌐</span>'}
      <div class="domain-name">${escHtml(domain)}</div>
      <div class="domain-meta">${tabs.length} tab${tabs.length !== 1 ? 's' : ''} · ${formatMB(totalMem)} JS heap</div>
      <div class="domain-chevron">▾</div>
    `;

    header.addEventListener('click', () => {
      if (collapsedDomains.has(domain)) {
        collapsedDomains.delete(domain);
        group.classList.remove('collapsed');
      } else {
        collapsedDomains.add(domain);
        group.classList.add('collapsed');
      }
    });

    const tabsContainer = document.createElement('div');
    tabsContainer.className = 'domain-tabs';
    for (const [id, data] of tabs) {
      tabsContainer.appendChild(buildTabCard(id, data));
    }

    group.appendChild(header);
    group.appendChild(tabsContainer);
    container.appendChild(group);
  }
}

// ── Event delegation for tab action buttons ────────────────────────────────────

document.getElementById('tabListContent').addEventListener('click', async (e) => {
  const suspendBtn = e.target.closest('.suspend-btn');
  const closeBtn = e.target.closest('.close-btn');

  if (suspendBtn) {
    const tabId = parseInt(suspendBtn.dataset.id);
    await suspendTab(tabId);
  } else if (closeBtn) {
    const tabId = parseInt(closeBtn.dataset.id);
    await closeTab(tabId);
  }
});

// ── Tab Actions ────────────────────────────────────────────────────────────────

async function closeTab(tabId) {
  chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId }, () => {
    delete tabData[tabId];
    renderAll();
  });
}

async function suspendTab(tabId) {
  chrome.runtime.sendMessage({ type: 'SUSPEND_TAB', tabId }, (resp) => {
    if (resp && resp.ok) {
      if (tabData[tabId]) {
        tabData[tabId].discarded = true;
        tabData[tabId].status = 'suspended';
        tabData[tabId].jsHeapMB = null;
      }
      renderAll();
    } else {
      console.warn('Suspend failed:', resp?.error);
    }
  });
}

// ── Bulk Close ────────────────────────────────────────────────────────────────

document.getElementById('btnBulkClose').addEventListener('click', () => {
  const threshold = parseInt(document.getElementById('bulkThreshold').value) || 150;
  chrome.runtime.sendMessage({ type: 'CLOSE_BULK', thresholdMB: threshold }, (resp) => {
    if (resp && resp.ok) {
      const result = document.getElementById('bulkResult');
      result.textContent = `Closed ${resp.closed} tab${resp.closed !== 1 ? 's' : ''}`;
      result.classList.add('show');
      setTimeout(() => result.classList.remove('show'), 3000);
      refreshNow();
    }
  });
});

// ── Search ─────────────────────────────────────────────────────────────────────

document.getElementById('searchInput').addEventListener('input', (e) => {
  searchQuery = e.target.value.trim();
  renderAll();
});

// ── View Toggle ───────────────────────────────────────────────────────────────

document.getElementById('viewList').addEventListener('click', () => {
  currentView = 'list';
  document.getElementById('viewList').classList.add('active');
  document.getElementById('viewDomain').classList.remove('active');
  renderAll();
});

document.getElementById('viewDomain').addEventListener('click', () => {
  currentView = 'domain';
  document.getElementById('viewDomain').classList.add('active');
  document.getElementById('viewList').classList.remove('active');
  renderAll();
});

// ── Settings Panel ────────────────────────────────────────────────────────────

document.getElementById('btnSettings').addEventListener('click', () => {
  document.getElementById('settingsPanel').classList.toggle('visible');
});

document.getElementById('btnSaveSettings').addEventListener('click', () => {
  const newSettings = {
    alertThresholdMB: parseInt(document.getElementById('setAlertThreshold').value) || 1000,
    refreshIntervalSec: parseInt(document.getElementById('setRefreshInterval').value) || 10,
    autoSuspendThresholdMB: parseInt(document.getElementById('setAutoSuspendMB').value) || 300,
    autoSuspendEnabled: document.getElementById('setAutoSuspend').checked,
    closeBulkThresholdMB: parseInt(document.getElementById('bulkThreshold').value) || 150
  };
  settings = { ...settings, ...newSettings };
  chrome.runtime.sendMessage({ type: 'UPDATE_SETTINGS', settings: newSettings }, () => {
    document.getElementById('settingsPanel').classList.remove('visible');
    scheduleAutoRefresh();
  });
});

function loadSettingsIntoUI() {
  document.getElementById('setAlertThreshold').value = settings.alertThresholdMB || 1000;
  document.getElementById('setRefreshInterval').value = settings.refreshIntervalSec || 10;
  document.getElementById('setAutoSuspendMB').value = settings.autoSuspendThresholdMB || 300;
  document.getElementById('setAutoSuspend').checked = settings.autoSuspendEnabled || false;
  document.getElementById('bulkThreshold').value = settings.closeBulkThresholdMB || 150;
}

// ── Refresh ───────────────────────────────────────────────────────────────────

document.getElementById('btnRefresh').addEventListener('click', refreshNow);

async function refreshNow() {
  // Ask the background to re-measure every tab, then render
  await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'REFRESH_NOW' }, () => {
      void chrome.runtime.lastError;
      resolve();
    });
  });
  await loadData();
}

async function loadData() {
  const resp = await fetchTabData();
  if (!resp) {
    document.getElementById('loadingState').style.display = 'flex';
    document.getElementById('tabListContent').style.display = 'none';
    return;
  }

  tabData = resp.tabStore || {};
  measuredCount = resp.measuredCount || 0;
  settings = resp.settings || {};
  lastRefreshedTime = Date.now();

  loadSettingsIntoUI();

  document.getElementById('loadingState').style.display = 'none';
  document.getElementById('tabListContent').style.display = 'block';

  renderAll();
}

function scheduleAutoRefresh() {
  if (refreshTimer) clearInterval(refreshTimer);
  const interval = (settings.refreshIntervalSec || 10) * 1000;
  refreshTimer = setInterval(refreshNow, interval);
}

// ── Tick (update time display every second) ────────────────────────────────────

setInterval(() => {
  if (lastRefreshedTime) {
    const secs = Math.round((Date.now() - lastRefreshedTime) / 1000);
    document.getElementById('lastRefreshed').textContent =
      secs < 5 ? 'Just now' :
      secs < 60 ? `${secs}s ago` :
      `${Math.floor(secs / 60)}m ago`;
  }
}, 1000);

// ── Utility ───────────────────────────────────────────────────────────────────

function escHtml(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

// ── Boot ──────────────────────────────────────────────────────────────────────

(async () => {
  await refreshNow();
  scheduleAutoRefresh();
})();
