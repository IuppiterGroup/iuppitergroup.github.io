/**
 * Iuppiter Tab Manager — Popup Script
 */

// ── State ──────────────────────────────────────────────────────────────────────

let tabData = {};          // tabId -> tab info + memory
let totalMemoryMB = 0;
let settings = {};
let currentView = 'list';  // 'list' | 'domain'
let searchQuery = '';
let lastRefreshedTime = null;
let refreshTimer = null;
let collapsedDomains = new Set();

// ── Memory helpers ─────────────────────────────────────────────────────────────

function formatMB(mb) {
  if (mb === 0) return '0 MB';
  if (mb >= 1024) return `${(mb / 1024).toFixed(1)} GB`;
  return `${Math.round(mb)} MB`;
}

function memColor(mb) {
  if (mb === 0) return 'gray';
  if (mb < 100) return 'green';
  if (mb < 500) return 'yellow';
  return 'red';
}

function getDomain(url) {
  if (!url || url.startsWith('chrome://') || url.startsWith('chrome-extension://')) {
    return url ? url.split('/')[2] || url : '(internal)';
  }
  try {
    return new URL(url).hostname.replace(/^www\./, '') || '(unknown)';
  } catch {
    return '(unknown)';
  }
}

function getFaviconUrl(tab) {
  if (tab.favIconUrl && tab.favIconUrl.startsWith('http')) return tab.favIconUrl;
  if (tab.url) {
    try {
      const u = new URL(tab.url);
      if (u.protocol === 'https:' || u.protocol === 'http:') {
        return `${u.origin}/favicon.ico`;
      }
    } catch {}
  }
  return null;
}

// ── Fetch from background ──────────────────────────────────────────────────────

function fetchTabData() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'GET_TAB_DATA' }, (resp) => {
      if (chrome.runtime.lastError || !resp) {
        resolve(null);
        return;
      }
      resolve(resp);
    });
  });
}

// ── Render ─────────────────────────────────────────────────────────────────────

function renderAll() {
  const entries = Object.entries(tabData);

  // Apply search filter
  const filtered = entries.filter(([, d]) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (d.title || '').toLowerCase().includes(q) ||
           getDomain(d.url).toLowerCase().includes(q);
  });

  // Sort by memory descending
  filtered.sort((a, b) => b[1].memoryMB - a[1].memoryMB);

  const container = document.getElementById('tabListContent');
  container.innerHTML = '';

  if (filtered.length === 0) {
    container.innerHTML = '<div class="empty-state">No tabs found.</div>';
  } else if (currentView === 'list') {
    for (const [id, data] of filtered) {
      container.appendChild(buildTabCard(parseInt(id), data));
    }
  } else {
    renderDomainView(filtered, container);
  }

  updateHeader(entries);
}

function updateHeader(entries) {
  const totalMB = entries.reduce((s, [, d]) => s + (d.memoryMB || 0), 0);
  const redCount = entries.filter(([, d]) => d.memoryMB >= 500).length;

  document.getElementById('statTabCount').textContent = entries.length;
  document.getElementById('statTotalMem').textContent = formatMB(totalMB);
  document.getElementById('statRedCount').textContent = redCount;

  // Memory bar — scale to 8GB max
  const pct = Math.min((totalMB / 8192) * 100, 100);
  const fill = document.getElementById('memBarFill');
  fill.style.width = `${pct}%`;
  fill.className = `memory-bar-fill ${pct > 70 ? 'warn' : ''}`;
  document.getElementById('memBarLabel').textContent = `${Math.round(pct)}%`;

  // Alert
  const alertThreshold = settings.alertThresholdMB || 2000;
  const banner = document.getElementById('alertBanner');
  banner.classList.toggle('visible', totalMB > alertThreshold);

  // Last refreshed
  if (lastRefreshedTime) {
    const secs = Math.round((Date.now() - lastRefreshedTime) / 1000);
    document.getElementById('lastRefreshed').textContent =
      secs < 5 ? 'Just now' : `${secs}s ago`;
  }
}

function buildTabCard(tabId, data) {
  const card = document.createElement('div');
  card.className = `tab-card${data.active ? ' active-tab' : ''}${data.discarded ? ' discarded' : ''}`;
  card.dataset.tabId = tabId;

  const domain = getDomain(data.url);
  const color = memColor(data.memoryMB);
  const memText = data.discarded ? 'Suspended' : formatMB(data.memoryMB);
  const faviconUrl = getFaviconUrl(data);

  // Mini bar width: scale to 1GB max
  const barPct = Math.min((data.memoryMB / 1024) * 100, 100);

  card.innerHTML = `
    ${faviconUrl
      ? `<img class="tab-favicon" src="${faviconUrl}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex'" alt="">`
      : ''}
    <div class="tab-favicon-placeholder" style="${faviconUrl ? 'display:none' : ''}">📄</div>
    <div class="tab-info">
      <div class="tab-title">
        ${escHtml(data.title || 'Untitled')}
        ${data.active ? '<span class="tag-active">ACTIVE</span>' : ''}
        ${data.discarded ? '<span class="tag-suspended">SUSPENDED</span>' : ''}
      </div>
      <div class="tab-domain">${escHtml(domain)}</div>
    </div>
    <div class="tab-memory-col">
      <div class="tab-memory-text ${color}">${memText}</div>
      <div class="tab-memory-mini-bar">
        <div class="tab-memory-mini-fill ${color}" style="width:${barPct}%"></div>
      </div>
    </div>
    <div class="tab-actions">
      ${!data.discarded ? `<button class="btn-tab-action suspend-btn" data-id="${tabId}" title="Suspend tab">⏸</button>` : ''}
      <button class="btn-tab-action close-btn" data-id="${tabId}" title="Close tab">✕</button>
    </div>
  `;

  // Click card → focus tab
  card.addEventListener('click', (e) => {
    if (e.target.closest('.tab-actions')) return;
    chrome.tabs.update(tabId, { active: true }, () => {
      if (data.windowId) chrome.windows.update(data.windowId, { focused: true });
    });
  });

  return card;
}

function renderDomainView(filtered, container) {
  // Group by domain
  const groups = {};
  for (const [id, data] of filtered) {
    const domain = getDomain(data.url);
    if (!groups[domain]) groups[domain] = [];
    groups[domain].push([parseInt(id), data]);
  }

  // Sort groups by total memory
  const sortedDomains = Object.entries(groups)
    .sort((a, b) => {
      const sumA = a[1].reduce((s, [, d]) => s + d.memoryMB, 0);
      const sumB = b[1].reduce((s, [, d]) => s + d.memoryMB, 0);
      return sumB - sumA;
    });

  for (const [domain, tabs] of sortedDomains) {
    const group = document.createElement('div');
    const isCollapsed = collapsedDomains.has(domain);
    group.className = `domain-group${isCollapsed ? ' collapsed' : ''}`;

    const totalMem = tabs.reduce((s, [, d]) => s + d.memoryMB, 0);
    const sampleFavicon = getFaviconUrl(tabs[0][1]);

    const header = document.createElement('div');
    header.className = 'domain-header';
    header.innerHTML = `
      ${sampleFavicon
        ? `<img class="domain-favicon" src="${sampleFavicon}" onerror="this.style.display='none'" alt="">`
        : '<span style="font-size:12px">🌐</span>'}
      <div class="domain-name">${escHtml(domain)}</div>
      <div class="domain-meta">${tabs.length} tab${tabs.length !== 1 ? 's' : ''} · ${formatMB(totalMem)}</div>
      <div class="domain-chevron">▾</div>
    `;

    header.addEventListener('click', () => {
      if (collapsedDomains.has(domain)) {
        collapsedDomains.delete(domain);
        group.classList.remove('collapsed');
      } else {
        collapsedDomains.add(domain);
        group.classList.add('collapsed');
      }
    });

    const tabsContainer = document.createElement('div');
    tabsContainer.className = 'domain-tabs';
    for (const [id, data] of tabs) {
      tabsContainer.appendChild(buildTabCard(id, data));
    }

    group.appendChild(header);
    group.appendChild(tabsContainer);
    container.appendChild(group);
  }
}

// ── Event delegation for tab action buttons ────────────────────────────────────

document.getElementById('tabListContent').addEventListener('click', async (e) => {
  const suspendBtn = e.target.closest('.suspend-btn');
  const closeBtn = e.target.closest('.close-btn');

  if (suspendBtn) {
    const tabId = parseInt(suspendBtn.dataset.id);
    await suspendTab(tabId);
  } else if (closeBtn) {
    const tabId = parseInt(closeBtn.dataset.id);
    await closeTab(tabId);
  }
});

// ── Tab Actions ────────────────────────────────────────────────────────────────

async function closeTab(tabId) {
  chrome.runtime.sendMessage({ type: 'CLOSE_TAB', tabId }, () => {
    delete tabData[tabId];
    renderAll();
  });
}

async function suspendTab(tabId) {
  chrome.runtime.sendMessage({ type: 'SUSPEND_TAB', tabId }, (resp) => {
    if (resp && resp.ok) {
      if (tabData[tabId]) {
        tabData[tabId].discarded = true;
        tabData[tabId].memoryMB = 0;
      }
      renderAll();
    } else {
      console.warn('Suspend failed:', resp?.error);
    }
  });
}

// ── Bulk Close ────────────────────────────────────────────────────────────────

document.getElementById('btnBulkClose').addEventListener('click', () => {
  const threshold = parseInt(document.getElementById('bulkThreshold').value) || 300;
  chrome.runtime.sendMessage({ type: 'CLOSE_BULK', thresholdMB: threshold }, (resp) => {
    if (resp && resp.ok) {
      const result = document.getElementById('bulkResult');
      result.textContent = `Closed ${resp.closed} tab${resp.closed !== 1 ? 's' : ''}`;
      result.classList.add('show');
      setTimeout(() => result.classList.remove('show'), 3000);
      refreshNow();
    }
  });
});

// ── Search ─────────────────────────────────────────────────────────────────────

document.getElementById('searchInput').addEventListener('input', (e) => {
  searchQuery = e.target.value.trim();
  renderAll();
});

// ── View Toggle ───────────────────────────────────────────────────────────────

document.getElementById('viewList').addEventListener('click', () => {
  currentView = 'list';
  document.getElementById('viewList').classList.add('active');
  document.getElementById('viewDomain').classList.remove('active');
  renderAll();
});

document.getElementById('viewDomain').addEventListener('click', () => {
  currentView = 'domain';
  document.getElementById('viewDomain').classList.add('active');
  document.getElementById('viewList').classList.remove('active');
  renderAll();
});

// ── Settings Panel ────────────────────────────────────────────────────────────

document.getElementById('btnSettings').addEventListener('click', () => {
  document.getElementById('settingsPanel').classList.toggle('visible');
});

document.getElementById('btnSaveSettings').addEventListener('click', () => {
  const newSettings = {
    alertThresholdMB: parseInt(document.getElementById('setAlertThreshold').value) || 2000,
    refreshIntervalSec: parseInt(document.getElementById('setRefreshInterval').value) || 10,
    autoSuspendThresholdMB: parseInt(document.getElementById('setAutoSuspendMB').value) || 500,
    autoSuspendEnabled: document.getElementById('setAutoSuspend').checked,
    closeBulkThresholdMB: parseInt(document.getElementById('bulkThreshold').value) || 300
  };
  settings = { ...settings, ...newSettings };
  chrome.runtime.sendMessage({ type: 'UPDATE_SETTINGS', settings: newSettings }, () => {
    document.getElementById('settingsPanel').classList.remove('visible');
    scheduleAutoRefresh();
  });
});

function loadSettingsIntoUI() {
  document.getElementById('setAlertThreshold').value = settings.alertThresholdMB || 2000;
  document.getElementById('setRefreshInterval').value = settings.refreshIntervalSec || 10;
  document.getElementById('setAutoSuspendMB').value = settings.autoSuspendThresholdMB || 500;
  document.getElementById('setAutoSuspend').checked = settings.autoSuspendEnabled || false;
  document.getElementById('bulkThreshold').value = settings.closeBulkThresholdMB || 300;
}

// ── Refresh ───────────────────────────────────────────────────────────────────

document.getElementById('btnRefresh').addEventListener('click', refreshNow);

async function refreshNow() {
  // Trigger background refresh
  await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'REFRESH_NOW' }, resolve);
  });
  await loadData();
}

async function loadData() {
  const resp = await fetchTabData();
  if (!resp) {
    document.getElementById('loadingState').style.display = 'flex';
    document.getElementById('tabListContent').style.display = 'none';
    return;
  }

  tabData = resp.tabMemoryStore || {};
  totalMemoryMB = resp.totalMemoryMB || 0;
  settings = resp.settings || {};
  lastRefreshedTime = Date.now();

  loadSettingsIntoUI();

  document.getElementById('loadingState').style.display = 'none';
  document.getElementById('tabListContent').style.display = 'block';

  renderAll();
}

function scheduleAutoRefresh() {
  if (refreshTimer) clearInterval(refreshTimer);
  const interval = (settings.refreshIntervalSec || 10) * 1000;
  refreshTimer = setInterval(loadData, interval);
}

// ── Tick (update time display every second) ────────────────────────────────────

setInterval(() => {
  if (lastRefreshedTime) {
    const secs = Math.round((Date.now() - lastRefreshedTime) / 1000);
    document.getElementById('lastRefreshed').textContent =
      secs < 5 ? 'Just now' :
      secs < 60 ? `${secs}s ago` :
      `${Math.floor(secs / 60)}m ago`;
  }
}, 1000);

// ── Utility ───────────────────────────────────────────────────────────────────

function escHtml(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

// ── Boot ──────────────────────────────────────────────────────────────────────

(async () => {
  await loadData();
  scheduleAutoRefresh();
})();
