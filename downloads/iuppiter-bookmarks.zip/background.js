/**
 * Iuppiter Bookmarks — Background Service Worker
 * Handles dead link checking, favicon fetching, chrome.bookmarks sync.
 */

const DEAD_LINK_ALARM = 'iuppiter-deadlink';
const DEAD_LINK_INTERVAL_HOURS = 24;

// ─── Storage Schema ───────────────────────────────────────────────────────────
//
// chrome.storage.local:
//   metadata: { [bookmarkId]: { tags, notes, description, status, checkedAt, favicon, collections } }
//   collections: { [collectionId]: { name, color, bookmarkIds[] } }
//   settings: { newTabEnabled, deadLinkCheck, sortOrder, viewMode }
//   lastDeadLinkCheck: timestamp

// ─── Metadata Helpers ─────────────────────────────────────────────────────────

async function getMeta() {
  const d = await chrome.storage.local.get('metadata');
  return d.metadata || {};
}

async function saveMeta(meta) {
  await chrome.storage.local.set({ metadata: meta });
}

async function getCollections() {
  const d = await chrome.storage.local.get('collections');
  return d.collections || {};
}

async function saveCollections(cols) {
  await chrome.storage.local.set({ collections: cols });
}

// ─── Bookmark Helpers ─────────────────────────────────────────────────────────

async function getAllBookmarks() {
  return new Promise(resolve => {
    chrome.bookmarks.getTree(tree => resolve(flattenTree(tree)));
  });
}

function flattenTree(nodes) {
  const result = [];
  function walk(node) {
    if (node.url) result.push(node);
    if (node.children) node.children.forEach(walk);
  }
  nodes.forEach(walk);
  return result;
}

// ─── Auto-Categorize ──────────────────────────────────────────────────────────

const CATEGORY_MAP = [
  { cat: 'news',      patterns: ['news', 'reuters', 'bbc', 'cnn', 'nytimes', 'theguardian', 'wsj', 'bloomberg', 'apnews', 'foxnews'] },
  { cat: 'social',    patterns: ['twitter', 'x.com', 'facebook', 'instagram', 'linkedin', 'reddit', 'discord', 'threads', 'mastodon', 'tiktok', 'snapchat'] },
  { cat: 'dev',       patterns: ['github', 'gitlab', 'stackoverflow', 'developer', 'docs', 'npm', 'pypi', 'mdn', 'devdocs', 'codepen', 'jsfiddle', 'replit'] },
  { cat: 'video',     patterns: ['youtube', 'vimeo', 'twitch', 'dailymotion', 'rumble'] },
  { cat: 'shopping',  patterns: ['amazon', 'ebay', 'etsy', 'shopify', 'walmart', 'bestbuy', 'target', 'aliexpress', 'shop'] },
  { cat: 'finance',   patterns: ['finance', 'invest', 'stock', 'crypto', 'coinbase', 'binance', 'tradingview', 'schwab', 'fidelity', 'vanguard', 'robinhood'] },
  { cat: 'ai',        patterns: ['openai', 'claude', 'anthropic', 'gemini', 'copilot', 'huggingface', 'replicate', 'midjourney', 'perplexity'] },
  { cat: 'reference', patterns: ['wikipedia', 'wikia', 'dictionary', 'encyclopedia', 'archive', 'britannica'] },
  { cat: 'tools',     patterns: ['notion', 'airtable', 'trello', 'asana', 'jira', 'slack', 'zoom', 'figma', 'canva', 'loom'] },
  { cat: 'email',     patterns: ['gmail', 'outlook', 'proton', 'mail', 'yahoo'] }
];

function suggestCategory(url, title) {
  const combined = (url + ' ' + title).toLowerCase();
  for (const { cat, patterns } of CATEGORY_MAP) {
    if (patterns.some(p => combined.includes(p))) return cat;
  }
  return 'other';
}

function suggestTags(url, title) {
  const tags = [];
  const cat = suggestCategory(url, title);
  if (cat !== 'other') tags.push(cat);

  const domain = extractDomain(url);
  if (domain) tags.push(domain);

  return tags.slice(0, 3);
}

function extractDomain(url) {
  try {
    const u = new URL(url);
    return u.hostname.replace('www.', '').split('.')[0];
  } catch { return ''; }
}

// ─── Dead Link Checker ────────────────────────────────────────────────────────

async function checkDeadLinks() {
  const settings = await getSettings();
  if (!settings.deadLinkCheck) return;

  const bookmarks = await getAllBookmarks();
  const meta = await getMeta();
  let updated = false;

  for (const bm of bookmarks) {
    if (!bm.url || bm.url.startsWith('javascript:') || bm.url.startsWith('chrome:')) continue;

    const m = meta[bm.id] || {};
    const lastChecked = m.checkedAt || 0;
    const RECHECK_INTERVAL = 7 * 24 * 60 * 60 * 1000; // 7 days

    if (Date.now() - lastChecked < RECHECK_INTERVAL) continue;

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 8000);
      const resp = await fetch(bm.url, {
        method: 'HEAD',
        signal: controller.signal,
        cache: 'no-store'
      });
      clearTimeout(timeout);

      const prevStatus = m.status;
      const newStatus = resp.ok ? 'ok' : `dead_${resp.status}`;
      meta[bm.id] = { ...m, status: newStatus, checkedAt: Date.now() };

      if (!resp.ok && prevStatus !== newStatus) {
        chrome.notifications.create(`iuppiter-dead-${bm.id}`, {
          type: 'basic',
          iconUrl: 'icons/icon48.png',
          title: '🔗 Iuppiter: Dead Link Detected',
          message: `"${(bm.title || bm.url).slice(0, 60)}" returned ${resp.status}`
        });
      }
      updated = true;
    } catch (e) {
      if (e.name === 'AbortError') {
        meta[bm.id] = { ...m, status: 'timeout', checkedAt: Date.now() };
      } else {
        meta[bm.id] = { ...m, status: 'error', checkedAt: Date.now() };
      }
      updated = true;
    }
  }

  if (updated) {
    await saveMeta(meta);
    await chrome.storage.local.set({ lastDeadLinkCheck: Date.now() });
  }
}

// ─── Settings ─────────────────────────────────────────────────────────────────

async function getSettings() {
  const d = await chrome.storage.local.get('settings');
  return d.settings || {
    newTabEnabled: true,
    deadLinkCheck: true,
    sortOrder: 'date_desc',
    viewMode: 'grid'
  };
}

// ─── Alarms ───────────────────────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === DEAD_LINK_ALARM) checkDeadLinks();
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(DEAD_LINK_ALARM, {
    periodInMinutes: DEAD_LINK_INTERVAL_HOURS * 60
  });
});

// ─── Bookmark Events → Sync Metadata ─────────────────────────────────────────

chrome.bookmarks.onCreated.addListener(async (id, bookmark) => {
  if (!bookmark.url) return;
  const meta = await getMeta();
  if (!meta[id]) {
    const tags = suggestTags(bookmark.url, bookmark.title || '');
    const category = suggestCategory(bookmark.url, bookmark.title || '');
    meta[id] = {
      tags,
      category,
      notes: '',
      description: '',
      status: 'unchecked',
      checkedAt: 0,
      favicon: `https://www.google.com/s2/favicons?domain=${extractDomain(bookmark.url)}&sz=32`,
      collections: [],
      addedAt: Date.now()
    };
    await saveMeta(meta);
  }
});

chrome.bookmarks.onRemoved.addListener(async (id) => {
  const meta = await getMeta();
  delete meta[id];
  await saveMeta(meta);
});

// ─── Message Passing ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'GET_ALL_BOOKMARKS') {
    Promise.all([getAllBookmarks(), getMeta(), getCollections()]).then(([bms, meta, cols]) => {
      sendResponse({ bookmarks: bms, metadata: meta, collections: cols });
    });
    return true;
  }

  if (msg.type === 'SAVE_BOOKMARK') {
    chrome.bookmarks.create({
      title: msg.title,
      url: msg.url,
      parentId: msg.parentId
    }, async (bm) => {
      const meta = await getMeta();
      const tags = msg.tags || suggestTags(msg.url, msg.title);
      const category = suggestCategory(msg.url, msg.title);
      meta[bm.id] = {
        tags,
        category,
        notes: msg.notes || '',
        description: msg.description || '',
        status: 'unchecked',
        checkedAt: 0,
        favicon: `https://www.google.com/s2/favicons?domain=${extractDomain(msg.url)}&sz=32`,
        collections: [],
        addedAt: Date.now()
      };
      await saveMeta(meta);
      sendResponse({ ok: true, id: bm.id });
    });
    return true;
  }

  if (msg.type === 'UPDATE_META') {
    getMeta().then(async meta => {
      meta[msg.id] = { ...(meta[msg.id] || {}), ...msg.updates };
      await saveMeta(meta);
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === 'DELETE_BOOKMARK') {
    chrome.bookmarks.remove(msg.id, () => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'CHECK_DUPLICATE') {
    getAllBookmarks().then(bms => {
      const existing = bms.find(b => b.url === msg.url);
      sendResponse({ isDuplicate: !!existing, existing: existing || null });
    });
    return true;
  }

  if (msg.type === 'SAVE_COLLECTION') {
    getCollections().then(async cols => {
      cols[msg.id] = msg.collection;
      await saveCollections(cols);
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === 'DELETE_COLLECTION') {
    getCollections().then(async cols => {
      delete cols[msg.id];
      await saveCollections(cols);
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === 'GET_SETTINGS') {
    getSettings().then(sendResponse);
    return true;
  }

  if (msg.type === 'SAVE_SETTINGS') {
    chrome.storage.local.set({ settings: msg.settings }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'SUGGEST_TAGS') {
    sendResponse({
      tags: suggestTags(msg.url, msg.title),
      category: suggestCategory(msg.url, msg.title)
    });
    return true;
  }

  if (msg.type === 'RUN_DEADLINK_CHECK') {
    checkDeadLinks().then(() => sendResponse({ ok: true }));
    return true;
  }
});
