/**
 * Iuppiter Bookmarks — Content Script
 * Provides page metadata (title, description, OG image) to the extension.
 */

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'GET_PAGE_META') {
    const title = document.title || '';
    const description =
      getMetaContent('description') ||
      getMetaContent('og:description') ||
      getMetaContent('twitter:description') ||
      '';
    const ogImage =
      getMetaProperty('og:image') ||
      getMetaProperty('twitter:image') ||
      '';
    const url = window.location.href;

    sendResponse({ title, description, ogImage, url });
    return true;
  }
});

function getMetaContent(name) {
  const el = document.querySelector(`meta[name="${name}"]`);
  return el ? el.content : '';
}

function getMetaProperty(prop) {
  const el = document.querySelector(`meta[property="${prop}"]`);
  return el ? el.content : '';
}
