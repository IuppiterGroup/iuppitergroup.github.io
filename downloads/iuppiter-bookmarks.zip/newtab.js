/**
 * Iuppiter Bookmarks — New Tab Page Script
 * Full bookmark manager: grid/list view, tags, search, collections, import/export.
 */

// ─── State ────────────────────────────────────────────────────────────────────

let state = {
  bookmarks: [],
  metadata: {},
  collections: {},
  settings: {},
  filter: 'all',       // 'all' | 'recent' | 'deadlinks' | category | 'col:id'
  search: '',
  sort: 'date_desc',
  viewMode: 'grid',
  editingId: null
};

// ─── Utilities ────────────────────────────────────────────────────────────────

const $ = id => document.getElementById(id);
let toastTimer = null;

function showToast(msg, type = '') {
  const el = $('toast');
  el.textContent = msg;
  el.className = `toast${type ? ' toast-' + type : ''}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 2500);
}

function escHtml(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function extractDomain(url) {
  try { return new URL(url).hostname.replace('www.', ''); }
  catch { return url; }
}

function fmtDate(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function generateId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

// ─── Data Loading ─────────────────────────────────────────────────────────────

function loadData() {
  chrome.runtime.sendMessage({ type: 'GET_ALL_BOOKMARKS' }, (resp) => {
    if (!resp) return;
    state.bookmarks = resp.bookmarks || [];
    state.metadata = resp.metadata || {};
    state.collections = resp.collections || {};
    renderAll();
  });

  chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, (s) => {
    if (!s) return;
    state.settings = s;
    state.sort = s.sortOrder || 'date_desc';
    state.viewMode = s.viewMode || 'grid';
    applyViewMode();
    applySortUI();
  });
}

// ─── Filtering ────────────────────────────────────────────────────────────────

function getFilteredBookmarks() {
  let bms = [...state.bookmarks];
  const q = state.search.trim().toLowerCase();
  const meta = state.metadata;

  // Filter by view
  if (state.filter === 'recent') {
    const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
    bms = bms.filter(b => {
      const m = meta[b.id];
      const addedAt = m?.addedAt || (b.dateAdded || 0);
      return addedAt >= cutoff;
    });
  } else if (state.filter === 'deadlinks') {
    bms = bms.filter(b => {
      const status = meta[b.id]?.status || 'unchecked';
      return status.startsWith('dead_') || status === 'error' || status === 'timeout';
    });
  } else if (state.filter.startsWith('col:')) {
    const colId = state.filter.slice(4);
    const col = state.collections[colId];
    if (col) {
      const ids = new Set(col.bookmarkIds || []);
      bms = bms.filter(b => ids.has(b.id));
    }
  } else if (state.filter !== 'all') {
    // Category filter
    bms = bms.filter(b => {
      const m = meta[b.id];
      return (m?.category || 'other') === state.filter;
    });
  }

  // Full-text search
  if (q) {
    bms = bms.filter(b => {
      const m = meta[b.id] || {};
      const tags = (m.tags || []).join(' ');
      const combined = `${b.title} ${b.url} ${tags} ${m.notes || ''} ${m.description || ''}`.toLowerCase();
      return combined.includes(q);
    });
  }

  // Sort
  bms = sortBookmarks(bms);

  return bms;
}

function sortBookmarks(bms) {
  const meta = state.metadata;
  const s = state.sort;
  return [...bms].sort((a, b) => {
    if (s === 'date_desc') {
      const ta = meta[a.id]?.addedAt || a.dateAdded || 0;
      const tb = meta[b.id]?.addedAt || b.dateAdded || 0;
      return tb - ta;
    }
    if (s === 'date_asc') {
      const ta = meta[a.id]?.addedAt || a.dateAdded || 0;
      const tb = meta[b.id]?.addedAt || b.dateAdded || 0;
      return ta - tb;
    }
    if (s === 'alpha') {
      return (a.title || '').localeCompare(b.title || '');
    }
    if (s === 'domain') {
      return extractDomain(a.url || '').localeCompare(extractDomain(b.url || ''));
    }
    return 0;
  });
}

// ─── Rendering ────────────────────────────────────────────────────────────────

function renderAll() {
  renderSidebar();
  renderBookmarks();
}

function renderBookmarks() {
  const bms = getFilteredBookmarks();
  const grid = $('bookmark-grid');
  const empty = $('empty-state');

  // Update count
  $('section-count').textContent = bms.length;

  // Clear previous cards
  Array.from(grid.querySelectorAll('.bm-card, .bm-row')).forEach(el => el.remove());

  if (bms.length === 0) {
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');

  const fragment = document.createDocumentFragment();

  for (const bm of bms) {
    const m = state.metadata[bm.id] || {};
    const el = state.viewMode === 'grid'
      ? makeGridCard(bm, m)
      : makeListRow(bm, m);
    fragment.appendChild(el);
  }

  grid.appendChild(fragment);
}

function makeGridCard(bm, m) {
  const card = document.createElement('div');
  card.className = 'bm-card';
  card.dataset.id = bm.id;

  const status = m.status || 'unchecked';
  const isDead = status.startsWith('dead_') || status === 'error' || status === 'timeout';
  const statusBadge = isDead
    ? `<span class="bm-status-badge status-${status.startsWith('dead') ? 'dead' : 'timeout'}">${status.replace('dead_', '')}</span>`
    : '';

  const domain = extractDomain(bm.url || '');
  const favicon = m.favicon || `https://www.google.com/s2/favicons?domain=${domain}&sz=32`;
  const ogImage = m.ogImage || '';

  const thumbContent = ogImage
    ? `<img src="${escHtml(ogImage)}" alt="" loading="lazy" onerror="this.parentNode.innerHTML=fallbackThumb('${escHtml(domain)}', '${escHtml(favicon)}')">`
    : `<div class="bm-thumb-fallback">
        <img class="fav-icon" src="${escHtml(favicon)}" alt="" onerror="this.style.display='none'">
        <div class="bm-thumb-domain">${escHtml(domain)}</div>
       </div>`;

  const tags = (m.tags || []).slice(0, 3).map(t =>
    `<span class="bm-tag" title="${escHtml(t)}">${escHtml(t)}</span>`
  ).join('');

  card.innerHTML = `
    <div class="bm-card-actions">
      <button class="bm-action-btn" data-action="edit" title="Edit">✎</button>
      <button class="bm-action-btn" data-action="delete" title="Delete">🗑</button>
    </div>
    <div class="bm-thumb">
      ${thumbContent}
      ${statusBadge}
    </div>
    <div class="bm-body">
      <div class="bm-title" title="${escHtml(bm.title || '')}">${escHtml(bm.title || domain)}</div>
      <div class="bm-url">${escHtml(domain)}</div>
      ${tags ? `<div class="bm-tags">${tags}</div>` : ''}
    </div>
  `;

  card.addEventListener('click', (e) => {
    const action = e.target.closest('[data-action]')?.dataset.action;
    if (action === 'edit') { e.stopPropagation(); openEditModal(bm.id); return; }
    if (action === 'delete') { e.stopPropagation(); deleteBookmark(bm.id, bm.title); return; }
    chrome.tabs.create({ url: bm.url });
  });

  return card;
}

function makeListRow(bm, m) {
  const row = document.createElement('div');
  row.className = 'bm-row';
  row.dataset.id = bm.id;

  const domain = extractDomain(bm.url || '');
  const favicon = m.favicon || `https://www.google.com/s2/favicons?domain=${domain}&sz=32`;
  const tags = (m.tags || []).slice(0, 3).map(t =>
    `<span class="bm-tag">${escHtml(t)}</span>`
  ).join('');

  row.innerHTML = `
    <img class="bm-row-fav" src="${escHtml(favicon)}" alt="" onerror="this.style.display='none'">
    <div class="bm-row-info">
      <div class="bm-row-title">${escHtml(bm.title || domain)}</div>
      <div class="bm-row-url">${escHtml(bm.url || '')}</div>
    </div>
    ${tags ? `<div class="bm-row-tags">${tags}</div>` : ''}
    <div class="bm-row-actions">
      <button class="bm-action-btn" data-action="edit" title="Edit">✎</button>
      <button class="bm-action-btn" data-action="delete" title="Delete">🗑</button>
    </div>
  `;

  row.addEventListener('click', (e) => {
    const action = e.target.closest('[data-action]')?.dataset.action;
    if (action === 'edit') { e.stopPropagation(); openEditModal(bm.id); return; }
    if (action === 'delete') { e.stopPropagation(); deleteBookmark(bm.id, bm.title); return; }
    chrome.tabs.create({ url: bm.url });
  });

  return row;
}

// ─── Sidebar Rendering ────────────────────────────────────────────────────────

function renderSidebar() {
  // Category nav
  const cats = {};
  for (const bm of state.bookmarks) {
    const cat = state.metadata[bm.id]?.category || 'other';
    cats[cat] = (cats[cat] || 0) + 1;
  }

  const catNav = $('cat-nav');
  catNav.innerHTML = '';
  const catIcons = {
    news: '📰', social: '💬', dev: '💻', video: '▶️',
    shopping: '🛍', finance: '📈', ai: '🤖', reference: '📖',
    tools: '🔧', email: '✉️', other: '📌'
  };
  for (const [cat, count] of Object.entries(cats)) {
    const btn = document.createElement('button');
    btn.className = `nav-item${state.filter === cat ? ' active' : ''}`;
    btn.dataset.filter = cat;
    btn.innerHTML = `<span class="nav-icon">${catIcons[cat] || '📌'}</span>${cap(cat)}<span class="nav-count">${count}</span>`;
    btn.addEventListener('click', () => setFilter(cat, cap(cat)));
    catNav.appendChild(btn);
  }

  // Collections nav
  const colNav = $('col-nav');
  colNav.innerHTML = '';
  for (const [id, col] of Object.entries(state.collections)) {
    const btn = document.createElement('button');
    btn.className = `nav-item${state.filter === `col:${id}` ? ' active' : ''}`;
    btn.dataset.filter = `col:${id}`;
    const count = (col.bookmarkIds || []).length;
    btn.innerHTML = `<span class="nav-icon" style="color:${col.color}">●</span>${escHtml(col.name)}<span class="nav-count">${count}</span>`;
    btn.addEventListener('click', () => setFilter(`col:${id}`, col.name));
    colNav.appendChild(btn);
  }
}

function cap(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function setFilter(filter, title) {
  state.filter = filter;
  state.search = '';
  $('search-input').value = '';
  $('btn-clear-search').classList.add('hidden');
  $('section-title').textContent = title;
  // Update active nav items
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.filter === filter);
  });
  renderBookmarks();
}

// ─── View Mode ────────────────────────────────────────────────────────────────

function applyViewMode() {
  const grid = $('bookmark-grid');
  grid.className = state.viewMode === 'grid' ? 'grid-view' : 'list-view';
  $('btn-grid').classList.toggle('active', state.viewMode === 'grid');
  $('btn-list').classList.toggle('active', state.viewMode === 'list');
}

function applySortUI() {
  $('sort-select').value = state.sort;
}

// ─── Edit Modal ───────────────────────────────────────────────────────────────

function openEditModal(id) {
  state.editingId = id;
  const bm = state.bookmarks.find(b => b.id === id);
  if (!bm) return;
  const m = state.metadata[id] || {};

  $('modal-title').textContent = 'Edit Bookmark';
  $('edit-title').value = bm.title || '';
  $('edit-url').value = bm.url || '';
  $('edit-tags').value = (m.tags || []).join(', ');
  $('edit-notes').value = m.notes || '';
  $('edit-desc').value = m.description || '';

  // Populate collection dropdown
  const sel = $('edit-collection');
  sel.innerHTML = '<option value="">— None —</option>';
  for (const [cid, col] of Object.entries(state.collections)) {
    const opt = document.createElement('option');
    opt.value = cid;
    opt.textContent = col.name;
    opt.selected = (m.collections || []).includes(cid);
    sel.appendChild(opt);
  }

  $('modal-edit').classList.remove('hidden');
  $('edit-title').focus();
}

function closeModal(id) {
  $(id).classList.add('hidden');
}

async function saveEdit() {
  const id = state.editingId;
  if (!id) return;

  const title = $('edit-title').value.trim();
  const url = $('edit-url').value.trim();
  const tags = $('edit-tags').value.split(',').map(t => t.trim()).filter(Boolean);
  const notes = $('edit-notes').value.trim();
  const description = $('edit-desc').value.trim();
  const collectionId = $('edit-collection').value;

  // Update Chrome bookmark title
  chrome.bookmarks.update(id, { title });

  // Update metadata
  const updates = { tags, notes, description };
  if (collectionId) {
    // Add to collection
    const col = state.collections[collectionId];
    if (col) {
      if (!col.bookmarkIds) col.bookmarkIds = [];
      if (!col.bookmarkIds.includes(id)) col.bookmarkIds.push(id);
      updates.collections = [...(state.metadata[id]?.collections || []), collectionId].filter((v,i,a) => a.indexOf(v) === i);
      await new Promise(res => chrome.runtime.sendMessage({ type: 'SAVE_COLLECTION', id: collectionId, collection: col }, res));
    }
  }

  await new Promise(res => chrome.runtime.sendMessage({ type: 'UPDATE_META', id, updates }, res));

  closeModal('modal-edit');
  loadData();
  showToast('Bookmark saved', 'success');
}

function deleteBookmark(id, title) {
  if (!confirm(`Delete "${(title || 'this bookmark').slice(0, 60)}"?`)) return;
  chrome.runtime.sendMessage({ type: 'DELETE_BOOKMARK', id }, () => {
    loadData();
    showToast('Bookmark deleted');
  });
}

// ─── Collections ─────────────────────────────────────────────────────────────

let selectedColor = '#c4a44a';

function openNewCollectionModal() {
  $('col-name').value = '';
  selectedColor = '#c4a44a';
  document.querySelectorAll('.color-swatch').forEach(sw => {
    sw.classList.toggle('active', sw.dataset.color === selectedColor);
  });
  $('modal-collection').classList.remove('hidden');
  $('col-name').focus();
}

function saveCollection() {
  const name = $('col-name').value.trim();
  if (!name) return;
  const id = generateId();
  chrome.runtime.sendMessage({
    type: 'SAVE_COLLECTION',
    id,
    collection: { name, color: selectedColor, bookmarkIds: [] }
  }, () => {
    closeModal('modal-collection');
    loadData();
    showToast(`Collection "${name}" created`, 'success');
  });
}

// ─── Import ───────────────────────────────────────────────────────────────────

let importData = null;

function parseBookmarkHTML(html) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  const links = doc.querySelectorAll('a[href]');
  const results = [];
  for (const link of links) {
    const url = link.href;
    if (!url || url.startsWith('javascript:')) continue;
    results.push({ title: link.textContent.trim() || url, url });
  }
  return results;
}

async function runImport() {
  if (!importData || importData.length === 0) return;
  let added = 0;
  for (const { title, url } of importData) {
    await new Promise(res => {
      chrome.runtime.sendMessage({ type: 'SAVE_BOOKMARK', title, url }, res);
    });
    added++;
  }
  closeModal('modal-import');
  loadData();
  showToast(`Imported ${added} bookmarks`, 'success');
}

// ─── Export ───────────────────────────────────────────────────────────────────

function exportJSON() {
  const out = state.bookmarks.map(bm => ({
    title: bm.title,
    url: bm.url,
    dateAdded: bm.dateAdded,
    ...(state.metadata[bm.id] || {})
  }));
  const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `iuppiter-bookmarks-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

function exportHTML() {
  const lines = ['<!DOCTYPE NETSCAPE-Bookmark-file-1>', '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">', '<TITLE>Bookmarks</TITLE>', '<H1>Bookmarks</H1>', '<DL><p>'];
  for (const bm of state.bookmarks) {
    const ts = Math.floor((bm.dateAdded || Date.now()) / 1000);
    lines.push(`  <DT><A HREF="${escHtml(bm.url)}" ADD_DATE="${ts}">${escHtml(bm.title || bm.url)}</A>`);
  }
  lines.push('</DL><p>');
  const blob = new Blob([lines.join('\n')], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `iuppiter-bookmarks-${Date.now()}.html`;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Settings ─────────────────────────────────────────────────────────────────

function openSettings() {
  const s = state.settings;
  $('setting-newtab').checked = s.newTabEnabled !== false;
  $('setting-deadlink').checked = s.deadLinkCheck !== false;
  $('setting-sort').value = s.sortOrder || 'date_desc';
  $('setting-view').value = s.viewMode || 'grid';
  $('modal-settings').classList.remove('hidden');
}

function saveSettings() {
  const settings = {
    newTabEnabled: $('setting-newtab').checked,
    deadLinkCheck: $('setting-deadlink').checked,
    sortOrder: $('setting-sort').value,
    viewMode: $('setting-view').value
  };
  state.settings = settings;
  state.sort = settings.sortOrder;
  state.viewMode = settings.viewMode;
  chrome.runtime.sendMessage({ type: 'SAVE_SETTINGS', settings }, () => {
    closeModal('modal-settings');
    applyViewMode();
    applySortUI();
    renderBookmarks();
    showToast('Settings saved', 'success');
  });
}

// ─── Event Wiring ─────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  loadData();

  // Search
  $('search-input').addEventListener('input', (e) => {
    state.search = e.target.value;
    $('btn-clear-search').classList.toggle('hidden', !e.target.value);
    renderBookmarks();
  });
  $('btn-clear-search').addEventListener('click', () => {
    state.search = '';
    $('search-input').value = '';
    $('btn-clear-search').classList.add('hidden');
    renderBookmarks();
  });

  // Sort
  $('sort-select').addEventListener('change', (e) => {
    state.sort = e.target.value;
    renderBookmarks();
  });

  // View toggle
  $('btn-grid').addEventListener('click', () => {
    state.viewMode = 'grid';
    applyViewMode();
    renderBookmarks();
  });
  $('btn-list').addEventListener('click', () => {
    state.viewMode = 'list';
    applyViewMode();
    renderBookmarks();
  });

  // Sidebar nav
  document.querySelectorAll('[data-view]').forEach(btn => {
    btn.addEventListener('click', () => {
      const view = btn.dataset.view;
      const titles = { all: 'All Bookmarks', recent: 'Recently Added', deadlinks: 'Dead Links' };
      setFilter(view, titles[view] || view);
    });
  });

  // New collection
  $('btn-new-collection').addEventListener('click', openNewCollectionModal);

  // Import / Export
  $('btn-import').addEventListener('click', () => {
    $('modal-import').classList.remove('hidden');
  });
  $('btn-export').addEventListener('click', () => {
    exportJSON();
  });

  // Settings
  $('btn-settings-open').addEventListener('click', openSettings);

  // Modal close buttons
  document.querySelectorAll('.modal-close, [data-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.modal || btn.closest('.modal-overlay')?.id;
      if (id) closeModal(id);
    });
  });
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });

  // Edit modal save/delete
  $('btn-save-edit').addEventListener('click', saveEdit);
  $('btn-delete-bm').addEventListener('click', () => {
    const id = state.editingId;
    const bm = state.bookmarks.find(b => b.id === id);
    closeModal('modal-edit');
    if (bm) deleteBookmark(id, bm.title);
  });

  // Collection save
  $('btn-save-collection').addEventListener('click', saveCollection);
  document.querySelectorAll('.color-swatch').forEach(sw => {
    sw.addEventListener('click', () => {
      selectedColor = sw.dataset.color;
      document.querySelectorAll('.color-swatch').forEach(s => s.classList.toggle('active', s.dataset.color === selectedColor));
    });
  });

  // Import file
  $('import-file').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const text = await file.text();
    if (file.name.endsWith('.json')) {
      try {
        const parsed = JSON.parse(text);
        importData = Array.isArray(parsed) ? parsed : [];
      } catch { importData = []; }
    } else {
      importData = parseBookmarkHTML(text);
    }
    const preview = $('import-preview');
    preview.classList.remove('hidden');
    preview.textContent = `Found ${importData.length} bookmark(s) to import.`;
    $('btn-run-import').disabled = importData.length === 0;
  });
  $('btn-run-import').addEventListener('click', runImport);

  // Settings modal
  $('btn-save-settings').addEventListener('click', saveSettings);
  $('btn-run-deadlink').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'RUN_DEADLINK_CHECK' }, () => {
      showToast('Dead link check started…');
    });
  });

  // Export HTML from settings
  // (accessible via export button in sidebar — future: add HTML option there)
});
