# Iuppiter Bookmarks

A better Chrome bookmark manager. Visual grid view, tags, full-text search, dead link detection, collections, notes, import/export — all stored locally.

---

## What Makes It Better Than Chrome's Default

| Feature | Chrome Default | Iuppiter Bookmarks |
|---------|---------------|---------------------|
| Visual grid | ❌ Text list only | ✅ Grid with thumbnails |
| Tags | ❌ Folders only | ✅ Multiple tags per bookmark |
| Full-text search | ❌ Title/URL only | ✅ Title + URL + tags + notes |
| Auto-categorize | ❌ | ✅ (news, dev, social, finance, etc.) |
| Dead link detection | ❌ | ✅ Weekly checks, notifications |
| Notes | ❌ | ✅ Per-bookmark personal notes |
| Collections | ❌ | ✅ Theme-based groups like Pinterest |
| Duplicate detection | ❌ | ✅ Warns before saving duplicates |
| Import/Export | Limited | ✅ HTML + JSON |
| Dark theme | ❌ | ✅ |

---

## Install

1. Generate icons (one-time):
   ```
   pip install Pillow
   python generate_icons.py
   ```

2. Open Chrome → `chrome://extensions/`
3. Enable **Developer mode** (top-right toggle)
4. Click **Load unpacked** → select this folder

---

## Usage

### Saving a Bookmark
- Click the Iuppiter toolbar button to open the quick-save popup
- Title, URL, and suggested tags are pre-filled from the current page
- Add notes, edit tags, then click **Save**
- Duplicate URLs are detected automatically

### The Bookmark Manager (New Tab)
- Open a new tab → you're in the full Iuppiter Bookmarks manager
- **Left sidebar:** navigate by category, collection, or view (All / Recent / Dead Links)
- **Search bar:** searches titles, URLs, tags, AND notes
- **Grid/List toggle:** switch views from the toolbar
- **Sort:** newest, oldest, A–Z, or by domain

### Tags & Categories
- Tags are auto-suggested when saving (based on domain and title)
- Edit tags anytime by clicking ✎ on any card
- Categories are automatically detected (news, social, dev, video, shopping, finance, etc.)

### Collections
- Click **+ New Collection** in the sidebar to create a themed group
- Add bookmarks to collections via the Edit modal (✎)
- Each collection gets a color dot in the sidebar

### Dead Link Detection
- Runs every 24 hours in the background
- Dead links (404, timeout, error) are flagged with a red badge
- You'll get a desktop notification for each new dead link
- View all dead links in the **Dead Links** sidebar section

### Import
- **From Chrome:** Export your Chrome bookmarks first (Bookmarks Manager → ⋮ → Export) then import the HTML file
- **From Iuppiter:** Import a previously exported JSON file

### Export
- Click **↓ Export** in the sidebar → downloads `iuppiter-bookmarks-*.json`
- Includes all your metadata (tags, notes, descriptions)

---

## Privacy

- 100% local — no servers, no accounts, no data collection
- All data in `chrome.storage.local`
- Chrome bookmarks API read/write only — your bookmarks stay in Chrome

---

## Architecture

```
newtab.html / newtab.js    — Full bookmark manager (replaces new tab)
popup.html / popup.js      — Quick save + search toolbar popup
sidepanel.html             — Lightweight side panel list view
background.js              — Dead link checker, bookmark sync, message routing
content.js                 — Reads page metadata (OG tags, description)
```

---

## Branding

Gold `#c4a44a` | Blue `#2b579a` | Dark background `#1a1a1e`
