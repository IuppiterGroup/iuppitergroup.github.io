/**
 * Iuppiter Bookmarks — Popup Script
 * Quick save and search.
 */

const $ = id => document.getElementById(id);

let allBookmarks = [];
let allMeta = {};
let currentTabUrl = '';
let currentTabTitle = '';
let existingBookmarkId = null;

function escHtml(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function extractDomain(url) {
  try { return new URL(url).hostname.replace('www.', ''); }
  catch { return url; }
}

// ─── Load Current Tab ─────────────────────────────────────────────────────────

function loadCurrentTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab) return;
    currentTabUrl = tab.url || '';
    currentTabTitle = tab.title || '';

    $('save-url').value = currentTabUrl;
    $('save-title').value = currentTabTitle;

    // Get suggested tags
    chrome.runtime.sendMessage(
      { type: 'SUGGEST_TAGS', url: currentTabUrl, title: currentTabTitle },
      (resp) => {
        if (resp?.tags) $('save-tags').value = resp.tags.join(', ');
      }
    );

    // Check for duplicate
    chrome.runtime.sendMessage({ type: 'CHECK_DUPLICATE', url: currentTabUrl }, (resp) => {
      if (resp?.isDuplicate && resp.existing) {
        existingBookmarkId = resp.existing.id;
        $('dup-warning').classList.remove('hidden');
        $('save-title').value = resp.existing.title || currentTabTitle;
        const m = allMeta[resp.existing.id];
        if (m?.tags) $('save-tags').value = (m.tags || []).join(', ');
        if (m?.notes) $('save-notes').value = m.notes;
        $('btn-save').textContent = '✏️ Update Bookmark';
      }
    });

    // Try to get richer meta from content script
    chrome.tabs.sendMessage(tab.id, { type: 'GET_PAGE_META' }, (resp) => {
      if (chrome.runtime.lastError) return;
      if (resp?.description && !$('save-notes').value) {
        $('save-notes').value = resp.description;
      }
    });
  });
}

// ─── Load All Bookmarks ───────────────────────────────────────────────────────

function loadBookmarks() {
  chrome.runtime.sendMessage({ type: 'GET_ALL_BOOKMARKS' }, (resp) => {
    if (!resp) return;
    allBookmarks = resp.bookmarks || [];
    allMeta = resp.metadata || {};
    loadCurrentTab();
  });
}

// ─── Save ─────────────────────────────────────────────────────────────────────

function saveBookmark() {
  const title = $('save-title').value.trim();
  const url = $('save-url').value.trim();
  const tags = $('save-tags').value.split(',').map(t => t.trim()).filter(Boolean);
  const notes = $('save-notes').value.trim();

  if (!url) return;

  if (existingBookmarkId) {
    // Update existing
    chrome.bookmarks.update(existingBookmarkId, { title });
    chrome.runtime.sendMessage({
      type: 'UPDATE_META',
      id: existingBookmarkId,
      updates: { tags, notes }
    }, () => {
      showSaved('Updated!');
    });
  } else {
    chrome.runtime.sendMessage({ type: 'SAVE_BOOKMARK', title, url, tags, notes }, (resp) => {
      if (resp?.ok) {
        existingBookmarkId = resp.id;
        showSaved('Saved!');
      }
    });
  }
}

function showSaved(msg) {
  $('btn-save').textContent = `✅ ${msg}`;
  $('btn-save').disabled = true;
  setTimeout(() => {
    $('btn-save').textContent = '📌 Save Bookmark';
    $('btn-save').disabled = false;
  }, 2000);
}

// ─── Quick Search ─────────────────────────────────────────────────────────────

let searchDebounce = null;

function doSearch(q) {
  const results = $('search-results');
  if (!q.trim()) {
    results.innerHTML = '';
    return;
  }

  const query = q.toLowerCase();
  const matches = allBookmarks.filter(bm => {
    const m = allMeta[bm.id] || {};
    const tags = (m.tags || []).join(' ');
    const combined = `${bm.title} ${bm.url} ${tags} ${m.notes || ''}`.toLowerCase();
    return combined.includes(query);
  }).slice(0, 8);

  if (matches.length === 0) {
    results.innerHTML = `<div class="sr-empty">No results for "${escHtml(q)}"</div>`;
    return;
  }

  results.innerHTML = matches.map(bm => {
    const domain = extractDomain(bm.url || '');
    const favicon = allMeta[bm.id]?.favicon ||
      `https://www.google.com/s2/favicons?domain=${domain}&sz=16`;
    return `<div class="sr-item" data-url="${escHtml(bm.url)}">
      <img class="sr-fav" src="${escHtml(favicon)}" alt="" onerror="this.style.display='none'">
      <div class="sr-info">
        <div class="sr-title">${escHtml(bm.title || domain)}</div>
        <div class="sr-url">${escHtml(domain)}</div>
      </div>
    </div>`;
  }).join('');

  results.querySelectorAll('.sr-item').forEach(item => {
    item.addEventListener('click', () => {
      chrome.tabs.create({ url: item.dataset.url });
      window.close();
    });
  });
}

// ─── Init ─────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  loadBookmarks();

  $('btn-save').addEventListener('click', saveBookmark);

  $('btn-open-manager').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('newtab.html') });
    window.close();
  });

  $('quick-search').addEventListener('input', (e) => {
    clearTimeout(searchDebounce);
    searchDebounce = setTimeout(() => doSearch(e.target.value), 150);
  });

  // Enter to open first result
  $('quick-search').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const first = $('search-results').querySelector('.sr-item');
      if (first) first.click();
    }
  });
});
