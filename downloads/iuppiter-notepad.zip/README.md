# Iuppiter Notepad — Chrome Extension

A fast, clean notepad always one click away in your Chrome toolbar.
No external services. No analytics. Your notes stay on your device.

## Features

- **Multiple notes** — create, rename, pin, and delete notes
- **Auto-save** — saves as you type (600ms debounce)
- **Rich text** — bold, italic, underline, bullet lists, headings via contentEditable toolbar
- **Markdown mode** — toggle to write in Markdown with live preview
- **Search** — search across all notes (title + content)
- **Pin notes** — pin important notes to the top of the list
- **Categories/folders** — tag notes with categories, filter by category
- **Word & character count** — live stats in the footer
- **Export** — save any note as `.txt` or `.md`
- **Import** — import `.txt` or `.md` files as notes
- **Keyboard shortcuts** — Ctrl+B bold, Ctrl+I italic, Ctrl+U underline, Ctrl+N new note, Ctrl+F search
- **Fullscreen mode** — opens a full browser tab for distraction-free writing
- **Dark / light theme toggle** — dark by default
- **Font size adjustment** — 12–20px in the toolbar
- **Timestamps** — created and last-modified shown per note

## Installation

1. Run the icon generator (requires Pillow):
   ```
   pip install Pillow
   python generate_icons.py
   ```
2. Open Chrome and go to `chrome://extensions/`
3. Enable **Developer mode** (top right toggle)
4. Click **Load unpacked**
5. Select this folder (`notepad-extension/`)
6. The ✒ icon appears in your toolbar

## Color Scheme

| Element | Color |
|---------|-------|
| Gold accent | `#c4a44a` |
| Blue accent | `#2b579a` |
| Dark background | `#1a1a2e` |

## File Structure

```
notepad-extension/
├── manifest.json        # Manifest V3
├── popup.html           # Main popup
├── popup.css            # Styles
├── popup.js             # All logic
├── fullscreen.html      # Full-tab mode
├── generate_icons.py    # Icon generator
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

## Technical Notes

- Manifest V3 compliant
- Uses `chrome.storage.local` (no sync, no cloud)
- Zero external dependencies
- No network requests of any kind
- Markdown rendered with a built-in lightweight parser
- Rich text via `document.execCommand` (contentEditable)
