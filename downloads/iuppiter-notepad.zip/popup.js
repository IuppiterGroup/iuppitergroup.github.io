/**
 * Iuppiter Notepad — popup.js
 * Manifest V3 | chrome.storage.local | No external dependencies
 */

'use strict';

// ============================================================
// STATE
// ============================================================
let state = {
  notes: [],
  categories: [],
  settings: { theme: 'dark', fontSize: 14, lastNoteId: null }
};

let currentNoteId = null;
let autoSaveTimer = null;
let mdPreviewMode = false;
let isMarkdownMode = false;
let searchActive = false;

// ============================================================
// STORAGE
// ============================================================
async function loadState() {
  return new Promise(resolve => {
    chrome.storage.local.get(['notes', 'categories', 'settings'], (data) => {
      if (data.notes) state.notes = data.notes;
      if (data.categories) state.categories = data.categories;
      if (data.settings) state.settings = { ...state.settings, ...data.settings };
      resolve();
    });
  });
}

async function saveState() {
  return new Promise(resolve => {
    chrome.storage.local.set({
      notes: state.notes,
      categories: state.categories,
      settings: state.settings
    }, resolve);
  });
}

// ============================================================
// MARKDOWN PARSER (lightweight, no deps)
// ============================================================
function renderMarkdown(text) {
  if (!text) return '';
  let html = text
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    // Code blocks
    .replace(/```([\s\S]*?)```/gm, (_, c) => `<pre><code>${c.trim()}</code></pre>`)
    // Inline code
    .replace(/`([^`\n]+)`/g, '<code>$1</code>')
    // Headers
    .replace(/^###### (.+)$/gm, '<h6>$1</h6>')
    .replace(/^##### (.+)$/gm, '<h5>$1</h5>')
    .replace(/^#### (.+)$/gm, '<h4>$1</h4>')
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^# (.+)$/gm, '<h1>$1</h1>')
    // Bold + italic
    .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
    // Bold
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/__(.+?)__/g, '<strong>$1</strong>')
    // Italic
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/_(.+?)_/g, '<em>$1</em>')
    // Strikethrough
    .replace(/~~(.+?)~~/g, '<del>$1</del>')
    // Blockquote
    .replace(/^&gt; (.+)$/gm, '<blockquote>$1</blockquote>')
    // Horizontal rule
    .replace(/^---+$/gm, '<hr>')
    // Unordered list
    .replace(/^[*\-] (.+)$/gm, '<li>$1</li>')
    // Ordered list
    .replace(/^\d+\. (.+)$/gm, '<li>$1</li>')
    // Links
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank">$1</a>')
    // Line breaks → paragraphs (double newline)
    .split(/\n\n+/).map(block => {
      block = block.trim();
      if (!block) return '';
      if (block.match(/^<(h[1-6]|pre|blockquote|hr|ul|ol|li)/)) return block;
      // Wrap list items
      if (block.includes('<li>')) {
        return '<ul>' + block + '</ul>';
      }
      // Single newlines → <br>
      return '<p>' + block.replace(/\n/g, '<br>') + '</p>';
    }).join('\n');
  return html;
}

// ============================================================
// HELPERS
// ============================================================
function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function fmtDate(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
    + ' ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}

function fmtDateShort(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

function getPlainText(html) {
  const tmp = document.createElement('div');
  tmp.innerHTML = html;
  return tmp.textContent || tmp.innerText || '';
}

function countWords(text) {
  return text.trim() ? text.trim().split(/\s+/).length : 0;
}

function getCategoryColor(cat) {
  if (!cat) return 'transparent';
  const COLORS = ['#c4a44a','#2b579a','#55aa77','#e05555','#9955cc','#e07744','#44aacc'];
  let h = 0;
  for (let i = 0; i < cat.length; i++) h = ((h << 5) - h) + cat.charCodeAt(i);
  return COLORS[Math.abs(h) % COLORS.length];
}

function currentNote() {
  return state.notes.find(n => n.id === currentNoteId) || null;
}

function sortedNotes(notes) {
  return [...notes].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return (b.modified || 0) - (a.modified || 0);
  });
}

// ============================================================
// NOTE CRUD
// ============================================================
function createNote(partial = {}) {
  const now = Date.now();
  const note = {
    id: genId(),
    title: partial.title || 'Untitled',
    content: partial.content || '',
    contentMd: partial.contentMd || '',
    category: partial.category || '',
    pinned: false,
    created: now,
    modified: now,
    isMarkdown: false,
    ...partial
  };
  state.notes.unshift(note);
  return note;
}

function updateNote(id, changes) {
  const idx = state.notes.findIndex(n => n.id === id);
  if (idx === -1) return;
  state.notes[idx] = { ...state.notes[idx], ...changes, modified: Date.now() };
  state.settings.lastNoteId = id;
}

function deleteNote(id) {
  state.notes = state.notes.filter(n => n.id !== id);
  if (state.settings.lastNoteId === id) state.settings.lastNoteId = null;
}

// ============================================================
// RENDER NOTE LIST
// ============================================================
function renderNoteList(filterCat = '', searchQuery = '') {
  const list = document.getElementById('note-list');
  let notes = sortedNotes(state.notes);

  if (filterCat) notes = notes.filter(n => n.category === filterCat);
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    notes = notes.filter(n =>
      n.title.toLowerCase().includes(q) ||
      getPlainText(n.content).toLowerCase().includes(q) ||
      n.contentMd.toLowerCase().includes(q)
    );
  }

  if (!notes.length) {
    list.innerHTML = `<div class="note-item-empty">${searchQuery ? 'No results' : 'No notes yet'}</div>`;
    return;
  }

  list.innerHTML = notes.map(n => {
    const isActive = n.id === currentNoteId ? ' active' : '';
    const catColor = getCategoryColor(n.category);
    const catDot = n.category ? `<span class="cat-dot" style="background:${catColor}"></span>` : '';
    const pin = n.pinned ? '<span class="pin-icon">📌</span>' : '';
    const preview = n.isMarkdown
      ? n.contentMd.slice(0, 40).replace(/[#*_`\n]/g, ' ')
      : getPlainText(n.content).slice(0, 40);
    return `<div class="note-item${isActive}" data-id="${n.id}">
      ${pin}
      <div class="note-item-title">${escHtml(n.title)}</div>
      <div class="note-item-meta">${catDot}${escHtml(preview)}</div>
    </div>`;
  }).join('');

  list.querySelectorAll('.note-item').forEach(el => {
    el.addEventListener('click', () => selectNote(el.dataset.id));
  });
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ============================================================
// SELECT / OPEN NOTE
// ============================================================
function selectNote(id) {
  const note = state.notes.find(n => n.id === id);
  if (!note) return;

  currentNoteId = id;
  isMarkdownMode = note.isMarkdown;
  mdPreviewMode = false;

  // Update title
  document.getElementById('note-title').value = note.title;

  // Update category badge
  const badge = document.getElementById('note-category-badge');
  badge.textContent = note.category || '';
  badge.style.display = note.category ? 'inline-block' : 'none';

  // Update pin button
  document.getElementById('btn-pin').style.opacity = note.pinned ? '1' : '0.5';
  document.getElementById('btn-pin').title = note.pinned ? 'Unpin note' : 'Pin note';

  // Set editor mode
  if (isMarkdownMode) {
    switchToMdMode(note);
  } else {
    switchToRichMode(note);
  }

  updateStats();
  updateTimestamps(note);
  renderNoteList(document.getElementById('category-filter').value, '');
}

function switchToRichMode(note) {
  const rich = document.getElementById('rich-editor');
  const mdEd = document.getElementById('md-editor');
  const mdPrev = document.getElementById('md-preview');
  const toolbar = document.getElementById('toolbar');
  const mdToolbar = document.getElementById('md-toolbar');

  rich.classList.remove('hidden');
  toolbar.classList.remove('hidden');
  mdEd.classList.add('hidden');
  mdPrev.classList.add('hidden');
  mdToolbar.classList.add('hidden');

  rich.innerHTML = note.content || '';
  document.getElementById('btn-md-mode').style.color = '';
  document.getElementById('font-size').value = state.settings.fontSize || 14;
  rich.style.fontSize = (state.settings.fontSize || 14) + 'px';
}

function switchToMdMode(note) {
  const rich = document.getElementById('rich-editor');
  const mdEd = document.getElementById('md-editor');
  const mdPrev = document.getElementById('md-preview');
  const toolbar = document.getElementById('toolbar');
  const mdToolbar = document.getElementById('md-toolbar');

  rich.classList.add('hidden');
  toolbar.classList.add('hidden');
  mdToolbar.classList.remove('hidden');

  if (mdPreviewMode) {
    mdEd.classList.add('hidden');
    mdPrev.classList.remove('hidden');
    mdPrev.innerHTML = renderMarkdown(note.contentMd || '');
    document.getElementById('btn-md-preview').textContent = '✏ Edit';
  } else {
    mdEd.classList.remove('hidden');
    mdPrev.classList.add('hidden');
    mdEd.value = note.contentMd || '';
    document.getElementById('btn-md-preview').textContent = '👁 Preview';
  }

  document.getElementById('btn-md-mode').style.color = '#c4a44a';
}

// ============================================================
// STATS & TIMESTAMPS
// ============================================================
function updateStats() {
  const note = currentNote();
  if (!note) {
    document.getElementById('word-count').textContent = '0 words';
    document.getElementById('char-count').textContent = '0 chars';
    return;
  }
  let text;
  if (note.isMarkdown) {
    text = note.contentMd || '';
  } else {
    text = getPlainText(note.content || '');
  }
  document.getElementById('word-count').textContent = countWords(text) + ' words';
  document.getElementById('char-count').textContent = text.length + ' chars';
}

function updateTimestamps(note) {
  if (!note) {
    document.getElementById('ts-created').textContent = '';
    document.getElementById('ts-modified').textContent = '';
    return;
  }
  document.getElementById('ts-created').textContent = 'Created ' + fmtDate(note.created);
  document.getElementById('ts-modified').textContent = 'Modified ' + fmtDate(note.modified);
}

// ============================================================
// AUTO-SAVE
// ============================================================
function scheduleAutoSave() {
  clearTimeout(autoSaveTimer);
  autoSaveTimer = setTimeout(async () => {
    const note = currentNote();
    if (!note) return;

    const title = document.getElementById('note-title').value.trim() || 'Untitled';
    let content = '';
    let contentMd = '';

    if (note.isMarkdown) {
      contentMd = document.getElementById('md-editor').value;
    } else {
      content = document.getElementById('rich-editor').innerHTML;
    }

    updateNote(currentNoteId, { title, content, contentMd });
    await saveState();
    updateStats();
    renderNoteList(document.getElementById('category-filter').value, '');
  }, 600);
}

// ============================================================
// CATEGORY MANAGEMENT
// ============================================================
function renderCategoryFilter() {
  const sel = document.getElementById('category-filter');
  const current = sel.value;
  const cats = [...new Set(state.notes.map(n => n.category).filter(Boolean))];
  sel.innerHTML = '<option value="">All</option>' +
    cats.map(c => `<option value="${escHtml(c)}"${c === current ? ' selected' : ''}>${escHtml(c)}</option>`).join('');
}

// ============================================================
// SEARCH
// ============================================================
function performSearch(query) {
  if (!query.trim()) {
    renderNoteList(document.getElementById('category-filter').value, '');
    return;
  }
  const q = query.toLowerCase();
  const results = state.notes.filter(n =>
    n.title.toLowerCase().includes(q) ||
    getPlainText(n.content).toLowerCase().includes(q) ||
    (n.contentMd || '').toLowerCase().includes(q)
  );

  const list = document.getElementById('note-list');
  if (!results.length) {
    list.innerHTML = '<div class="note-item-empty">No results</div>';
    return;
  }

  list.innerHTML = results.map(n => {
    const plain = n.isMarkdown ? n.contentMd : getPlainText(n.content);
    const idx = plain.toLowerCase().indexOf(q);
    let snippet = '';
    if (idx >= 0) {
      const start = Math.max(0, idx - 20);
      const raw = plain.slice(start, idx + 40);
      snippet = escHtml(raw).replace(
        new RegExp(escHtml(query), 'gi'),
        m => `<mark>${m}</mark>`
      );
    }
    return `<div class="note-item${n.id === currentNoteId ? ' active' : ''}" data-id="${n.id}">
      <div class="note-item-title">${escHtml(n.title)}</div>
      <div class="note-item-meta search-result-snippet">${snippet || ''}</div>
    </div>`;
  }).join('');

  list.querySelectorAll('.note-item').forEach(el => {
    el.addEventListener('click', () => {
      selectNote(el.dataset.id);
      closeSearch();
    });
  });
}

function closeSearch() {
  document.getElementById('search-bar').classList.add('hidden');
  document.getElementById('search-input').value = '';
  searchActive = false;
  renderNoteList(document.getElementById('category-filter').value, '');
}

// ============================================================
// EXPORT / IMPORT
// ============================================================
function exportNote(note, format) {
  let content, mime, ext;
  if (format === 'md') {
    content = note.isMarkdown ? note.contentMd : '# ' + note.title + '\n\n' + getPlainText(note.content);
    mime = 'text/markdown';
    ext = 'md';
  } else {
    content = note.title + '\n\n' + (note.isMarkdown ? note.contentMd : getPlainText(note.content));
    mime = 'text/plain';
    ext = 'txt';
  }

  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = (note.title || 'note').replace(/[^a-zA-Z0-9_\- ]/g, '_') + '.' + ext;
  a.click();
  URL.revokeObjectURL(url);
}

function importFile(file) {
  const reader = new FileReader();
  reader.onload = async (e) => {
    const text = e.target.result;
    const ismd = file.name.endsWith('.md');
    const lines = text.split('\n');
    const title = lines[0].replace(/^#+ /, '').trim() || file.name.replace(/\.(txt|md)$/, '');
    const body = lines.slice(1).join('\n').trim();
    const note = createNote({
      title,
      content: ismd ? '' : body,
      contentMd: ismd ? text : '',
      isMarkdown: ismd
    });
    await saveState();
    renderNoteList('', '');
    renderCategoryFilter();
    selectNote(note.id);
  };
  reader.readAsText(file);
}

// ============================================================
// CATEGORY MODAL
// ============================================================
function openCategoryModal() {
  const modal = document.getElementById('category-modal');
  modal.classList.remove('hidden');
  const input = document.getElementById('category-input');
  const note = currentNote();
  input.value = note ? note.category || '' : '';

  // Show existing category suggestions
  const cats = [...new Set(state.notes.map(n => n.category).filter(Boolean))];
  const sugg = document.getElementById('category-suggestions');
  sugg.innerHTML = cats.map(c =>
    `<span class="cat-chip" data-cat="${escHtml(c)}">${escHtml(c)}</span>`
  ).join('');
  sugg.querySelectorAll('.cat-chip').forEach(el => {
    el.addEventListener('click', () => {
      input.value = el.dataset.cat;
    });
  });

  input.focus();
}

function closeCategoryModal() {
  document.getElementById('category-modal').classList.add('hidden');
}

// ============================================================
// THEME
// ============================================================
function applyTheme(theme) {
  document.body.className = 'theme-' + theme;
  document.getElementById('btn-theme').textContent = theme === 'dark' ? '☀' : '🌙';
}

// ============================================================
// TOOLBAR FORMATTING
// ============================================================
function execFormat(cmd, val) {
  document.getElementById('rich-editor').focus();
  document.execCommand(cmd, false, val || null);
  scheduleAutoSave();
}

// ============================================================
// FULLSCREEN
// ============================================================
function openFullscreen() {
  const note = currentNote();
  if (!note) {
    chrome.tabs.create({ url: chrome.runtime.getURL('fullscreen.html') });
    return;
  }
  chrome.tabs.create({ url: chrome.runtime.getURL('fullscreen.html') + '?noteId=' + note.id });
}

// ============================================================
// INIT
// ============================================================
async function init() {
  await loadState();

  // Apply theme
  applyTheme(state.settings.theme);

  // Render note list
  renderNoteList();
  renderCategoryFilter();

  // Select last note or first
  const toSelect = state.settings.lastNoteId || (state.notes.length ? state.notes[0].id : null);
  if (toSelect && state.notes.find(n => n.id === toSelect)) {
    selectNote(toSelect);
  } else if (state.notes.length === 0) {
    // Create a default welcome note
    const welcome = createNote({
      title: 'Welcome to Iuppiter Notepad',
      content: '<h2>Welcome</h2><p>Your notes are saved automatically as you type.</p><ul><li>Create notes with <b>+ New</b></li><li>Format with the toolbar</li><li>Toggle <b>Md</b> for Markdown mode</li><li>Pin important notes</li><li>Export as .txt or .md</li></ul>',
      category: 'General'
    });
    await saveState();
    renderNoteList();
    renderCategoryFilter();
    selectNote(welcome.id);
  }

  // ===== EVENT LISTENERS =====

  // New note
  document.getElementById('btn-new-note').addEventListener('click', async () => {
    const note = createNote();
    await saveState();
    renderNoteList('', '');
    renderCategoryFilter();
    selectNote(note.id);
    setTimeout(() => document.getElementById('note-title').select(), 50);
  });

  // Title input
  document.getElementById('note-title').addEventListener('input', () => scheduleAutoSave());

  // Rich editor input
  document.getElementById('rich-editor').addEventListener('input', () => {
    updateStats();
    scheduleAutoSave();
  });

  // Markdown editor input
  document.getElementById('md-editor').addEventListener('input', () => {
    updateStats();
    scheduleAutoSave();
    if (mdPreviewMode) {
      const note = currentNote();
      if (note) {
        document.getElementById('md-preview').innerHTML = renderMarkdown(document.getElementById('md-editor').value);
      }
    }
  });

  // Keyboard shortcuts in rich editor
  document.getElementById('rich-editor').addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey) {
      switch (e.key.toLowerCase()) {
        case 'b': e.preventDefault(); execFormat('bold'); break;
        case 'i': e.preventDefault(); execFormat('italic'); break;
        case 'u': e.preventDefault(); execFormat('underline'); break;
        case 'n': e.preventDefault(); document.getElementById('btn-new-note').click(); break;
        case 'f': e.preventDefault(); document.getElementById('btn-search-toggle').click(); break;
      }
    }
  });

  // Keyboard shortcuts in MD editor
  document.getElementById('md-editor').addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') {
      e.preventDefault();
      document.getElementById('btn-new-note').click();
    }
  });

  // Global Ctrl+N
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n' && document.activeElement.id !== 'rich-editor') {
      e.preventDefault();
      document.getElementById('btn-new-note').click();
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') {
      e.preventDefault();
      document.getElementById('btn-search-toggle').click();
    }
    if (e.key === 'Escape') {
      if (!document.getElementById('note-menu').classList.contains('hidden'))
        document.getElementById('note-menu').classList.add('hidden');
      if (!document.getElementById('category-modal').classList.contains('hidden'))
        closeCategoryModal();
      if (searchActive) closeSearch();
    }
  });

  // Format toolbar buttons
  document.querySelectorAll('.fmt-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const cmd = btn.dataset.cmd;
      const val = btn.dataset.val || null;
      execFormat(cmd, val);
    });
  });

  // Font size
  document.getElementById('font-size').addEventListener('change', (e) => {
    const size = parseInt(e.target.value);
    state.settings.fontSize = size;
    document.getElementById('rich-editor').style.fontSize = size + 'px';
    saveState();
  });

  // Theme toggle
  document.getElementById('btn-theme').addEventListener('click', () => {
    state.settings.theme = state.settings.theme === 'dark' ? 'light' : 'dark';
    applyTheme(state.settings.theme);
    saveState();
  });

  // Fullscreen
  document.getElementById('btn-fullscreen').addEventListener('click', openFullscreen);

  // Search toggle
  document.getElementById('btn-search-toggle').addEventListener('click', () => {
    const bar = document.getElementById('search-bar');
    if (bar.classList.contains('hidden')) {
      bar.classList.remove('hidden');
      document.getElementById('search-input').focus();
      searchActive = true;
    } else {
      closeSearch();
    }
  });

  document.getElementById('btn-search-close').addEventListener('click', closeSearch);

  document.getElementById('search-input').addEventListener('input', (e) => {
    performSearch(e.target.value);
  });

  // Category filter
  document.getElementById('category-filter').addEventListener('change', (e) => {
    renderNoteList(e.target.value, '');
  });

  // Pin toggle
  document.getElementById('btn-pin').addEventListener('click', async () => {
    const note = currentNote();
    if (!note) return;
    updateNote(currentNoteId, { pinned: !note.pinned });
    await saveState();
    document.getElementById('btn-pin').style.opacity = !note.pinned ? '1' : '0.5';
    renderNoteList(document.getElementById('category-filter').value, '');
  });

  // Markdown mode toggle
  document.getElementById('btn-md-mode').addEventListener('click', async () => {
    const note = currentNote();
    if (!note) return;

    isMarkdownMode = !note.isMarkdown;
    mdPreviewMode = false;

    if (isMarkdownMode) {
      // Convert HTML to rough text for MD editor
      const plainText = getPlainText(note.content || '');
      updateNote(currentNoteId, { isMarkdown: true, contentMd: plainText });
    } else {
      // Convert MD to HTML
      const html = renderMarkdown(note.contentMd || '');
      updateNote(currentNoteId, { isMarkdown: false, content: html });
    }

    await saveState();
    selectNote(currentNoteId);
  });

  // MD preview toggle
  document.getElementById('btn-md-preview').addEventListener('click', () => {
    const note = currentNote();
    if (!note) return;
    mdPreviewMode = !mdPreviewMode;
    const md = document.getElementById('md-editor').value;
    updateNote(currentNoteId, { contentMd: md });
    selectNote(currentNoteId);
  });

  // Note menu toggle
  document.getElementById('btn-note-menu').addEventListener('click', (e) => {
    const menu = document.getElementById('note-menu');
    menu.classList.toggle('hidden');
    e.stopPropagation();
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('#note-menu') && !e.target.closest('#btn-note-menu')) {
      document.getElementById('note-menu').classList.add('hidden');
    }
  });

  // Menu items
  document.getElementById('menu-category').addEventListener('click', () => {
    document.getElementById('note-menu').classList.add('hidden');
    openCategoryModal();
  });

  document.getElementById('menu-export-txt').addEventListener('click', () => {
    document.getElementById('note-menu').classList.add('hidden');
    const note = currentNote();
    if (note) exportNote(note, 'txt');
  });

  document.getElementById('menu-export-md').addEventListener('click', () => {
    document.getElementById('note-menu').classList.add('hidden');
    const note = currentNote();
    if (note) exportNote(note, 'md');
  });

  document.getElementById('menu-import').addEventListener('click', () => {
    document.getElementById('note-menu').classList.add('hidden');
    document.getElementById('file-import').click();
  });

  document.getElementById('menu-delete').addEventListener('click', async () => {
    document.getElementById('note-menu').classList.add('hidden');
    const note = currentNote();
    if (!note) return;
    if (!confirm(`Delete "${note.title}"?`)) return;
    deleteNote(currentNoteId);
    currentNoteId = null;
    await saveState();
    renderNoteList('', '');
    renderCategoryFilter();
    // Select another note
    if (state.notes.length > 0) {
      selectNote(state.notes[0].id);
    } else {
      clearEditor();
    }
  });

  // File import
  document.getElementById('file-import').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) importFile(file);
    e.target.value = '';
  });

  // Category modal save
  document.getElementById('btn-category-save').addEventListener('click', async () => {
    const cat = document.getElementById('category-input').value.trim();
    if (currentNoteId) {
      updateNote(currentNoteId, { category: cat });
      await saveState();
      const badge = document.getElementById('note-category-badge');
      badge.textContent = cat;
      badge.style.display = cat ? 'inline-block' : 'none';
      renderNoteList(document.getElementById('category-filter').value, '');
      renderCategoryFilter();
    }
    closeCategoryModal();
  });

  document.getElementById('btn-category-cancel').addEventListener('click', closeCategoryModal);
  document.getElementById('category-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('btn-category-save').click();
    if (e.key === 'Escape') closeCategoryModal();
  });
}

function clearEditor() {
  document.getElementById('note-title').value = '';
  document.getElementById('rich-editor').innerHTML = '';
  document.getElementById('md-editor').value = '';
  document.getElementById('note-category-badge').textContent = '';
  document.getElementById('note-category-badge').style.display = 'none';
  document.getElementById('ts-created').textContent = '';
  document.getElementById('ts-modified').textContent = '';
  document.getElementById('word-count').textContent = '0 words';
  document.getElementById('char-count').textContent = '0 chars';
}

// ============================================================
// BOOT
// ============================================================
document.addEventListener('DOMContentLoaded', init);
