# 🔊 Iuppiter Volume Control

A Chrome extension (Manifest V3) for per-tab audio volume control — including boost **above 100%**.

## Features

| Feature | Details |
|---|---|
| **Per-tab volume** | Individual volume slider (0–200%) for each tab |
| **Boost above 100%** | Go up to 200% for quiet tabs — uses Web Audio API GainNode |
| **Mute toggle** | Mute/unmute per tab, or mute all at once |
| **Master volume** | Global slider that scales all tab volumes proportionally |
| **Audio detection** | Shows tabs that are currently playing or have played audio |
| **Playing indicator** | Green dot pulses on actively playing tabs |
| **Domain memory** | Save a volume setting per domain (e.g., YouTube always at 80%) |
| **Quick presets** | Buttons for 25%, 50%, 100%, 150%, 200% |
| **Favicon + title** | Each tab shows its favicon and title for easy identification |
| **Keyboard shortcut** | `Ctrl+Shift+M` mutes/unmutes the current tab |

## Installation

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer Mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `volume-control-extension/` folder

## Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl+Shift+M` | Mute/unmute the current active tab |

You can customize shortcuts at `chrome://extensions/shortcuts`.

## How Volume Boost Works

Standard HTML5 volume is capped at 100%. This extension injects a **Web Audio API** content script that:

1. Captures all `<audio>` and `<video>` elements on the page
2. Routes them through an `AudioContext` + `GainNode`
3. Applies your chosen gain (0.0–2.0) — enabling both reduction and boost

This is the standard approach used by dedicated volume booster extensions.

## Privacy

- **No data leaves your browser.** Volume preferences stored in `chrome.storage.local`.
- No analytics, no telemetry, no network requests.
- No accounts, no sign-in.

## Technical Details

- **Manifest Version:** 3
- **Content Script:** Injected on all URLs at `document_idle`
- **Permissions:** `tabs`, `storage`, `scripting`, `<all_urls>` (required for content script injection)
- **No external dependencies**

## UI

- Dark theme with Iuppiter gold (`#c4a44a`) and blue (`#2b579a`)
- Popup width: 350px
- Gold-styled sliders

## Notes

- Tabs must be visited/playing for the content script to be active
- Click **↻ Refresh Audio Tabs** in the popup if a tab doesn't appear
- Some tabs (e.g., Chrome internal pages) cannot be injected — this is a browser limitation
