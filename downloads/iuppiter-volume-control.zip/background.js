// Iuppiter Volume Control — Background Service Worker

// Track tabs that have had audio
// tabAudioMap: tabId → { url, title, favIconUrl, hasAudio, audible }
const tabAudioMap = new Map();

// ── TAB TRACKING ──────────────────────────────────────────────────────

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.audible !== undefined) {
    const entry = tabAudioMap.get(tabId) || {};
    tabAudioMap.set(tabId, {
      ...entry,
      tabId,
      url: tab.url,
      title: tab.title,
      favIconUrl: tab.favIconUrl || '',
      audible: changeInfo.audible,
      hasAudio: entry.hasAudio || changeInfo.audible
    });
  }
  if (changeInfo.title && tabAudioMap.has(tabId)) {
    tabAudioMap.get(tabId).title = changeInfo.title;
  }
  if (changeInfo.favIconUrl && tabAudioMap.has(tabId)) {
    tabAudioMap.get(tabId).favIconUrl = changeInfo.favIconUrl;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  tabAudioMap.delete(tabId);
});

// ── KEYBOARD SHORTCUT ─────────────────────────────────────────────────

chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'mute-current-tab') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;

    try {
      const results = await chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_MUTE' });
    } catch (e) {
      // Content script not loaded on this page — use native tab muting as fallback
      await chrome.tabs.update(tab.id, { muted: !tab.mutedInfo?.muted });
    }
  }
});

// ── MESSAGE RELAY ─────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'PAGE_HAS_AUDIO') {
    const tabId = sender.tab?.id;
    if (tabId) {
      const existing = tabAudioMap.get(tabId) || {};
      tabAudioMap.set(tabId, {
        ...existing,
        tabId,
        url: sender.tab.url,
        title: sender.tab.title,
        favIconUrl: sender.tab.favIconUrl || '',
        hasAudio: true,
        audible: sender.tab.audible || existing.audible || false
      });
    }
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === 'GET_AUDIO_TABS') {
    // Return all tabs we know about + any currently audible tabs
    chrome.tabs.query({}, (tabs) => {
      // Update audible state from current tab list
      tabs.forEach(t => {
        if (t.audible) {
          const e = tabAudioMap.get(t.id) || {};
          tabAudioMap.set(t.id, {
            ...e,
            tabId: t.id,
            url: t.url,
            title: t.title,
            favIconUrl: t.favIconUrl || '',
            hasAudio: true,
            audible: true
          });
        }
      });

      const result = Array.from(tabAudioMap.values())
        .filter(e => e.hasAudio || e.audible)
        .map(e => ({ ...e }));

      sendResponse({ tabs: result });
    });
    return true; // async
  }
});
