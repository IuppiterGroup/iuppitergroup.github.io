// Iuppiter Volume Control — Popup Script

// tabStates: tabId → { volume: 0.0–2.0, muted: bool }
const tabStates = new Map();
let masterVolume = 1.0;
let masterMuted = false;
let domainSettings = {};  // domain → volume (0.0–2.0)

const PRESETS = [25, 50, 100, 150, 200];

// ── INIT ──────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadDomainSettings();
  setupMasterControls();
  await refreshTabList();
  document.getElementById('refreshBtn').addEventListener('click', refreshTabList);
});

// ── DOMAIN SETTINGS ───────────────────────────────────────────────────
async function loadDomainSettings() {
  const data = await chrome.storage.local.get({ domainVolumes: {} });
  domainSettings = data.domainVolumes;
}

async function saveDomainSetting(domain, volume) {
  domainSettings[domain] = volume;
  await chrome.storage.local.set({ domainVolumes: domainSettings });
}

function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return '';
  }
}

// ── MASTER VOLUME ─────────────────────────────────────────────────────
function setupMasterControls() {
  const slider = document.getElementById('masterSlider');
  const val = document.getElementById('masterVal');
  const muteBtn = document.getElementById('masterMuteBtn');

  slider.addEventListener('input', () => {
    masterVolume = parseInt(slider.value, 10) / 100;
    val.textContent = slider.value + '%';
    updatePresetHighlight(parseInt(slider.value, 10));
    applyMasterToAll();
  });

  muteBtn.addEventListener('click', () => {
    masterMuted = !masterMuted;
    muteBtn.textContent = masterMuted ? '🔇 All' : '🔊 All';
    muteBtn.classList.toggle('muted', masterMuted);
    applyMasterToAll();
  });

  // Presets
  document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const preset = parseInt(btn.dataset.preset, 10);
      slider.value = preset;
      masterVolume = preset / 100;
      val.textContent = preset + '%';
      updatePresetHighlight(preset);
      applyMasterToAll();
    });
  });
}

function updatePresetHighlight(value) {
  document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.classList.toggle('active', parseInt(btn.dataset.preset, 10) === value);
  });
}

async function applyMasterToAll() {
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    const state = tabStates.get(tab.id);
    if (!state) continue;
    const effectiveVol = masterMuted ? 0 : state.muted ? 0 : masterVolume * state.volume;
    try {
      await chrome.tabs.sendMessage(tab.id, {
        type: 'SET_VOLUME',
        volume: effectiveVol,
        muted: masterMuted || state.muted
      });
    } catch (e) { /* tab may not have content script */ }
  }
  // Update UI volume labels
  document.querySelectorAll('.tab-vol-label[data-tabid]').forEach(el => {
    const tabId = parseInt(el.dataset.tabid, 10);
    const state = tabStates.get(tabId);
    if (state) {
      el.textContent = Math.round((state.muted ? 0 : masterVolume * state.volume) * 100) + '%';
    }
  });
}

// ── TAB LIST ──────────────────────────────────────────────────────────
async function refreshTabList() {
  // Ask background for tabs with audio
  const response = await chrome.runtime.sendMessage({ type: 'GET_AUDIO_TABS' });
  const audioTabs = response?.tabs || [];

  // Also query for currently audible tabs not yet tracked
  const allTabs = await chrome.tabs.query({});
  const audibleTabs = allTabs.filter(t => t.audible);

  // Merge
  const tabMap = new Map();
  audioTabs.forEach(t => tabMap.set(t.tabId, t));
  audibleTabs.forEach(t => {
    if (!tabMap.has(t.id)) {
      tabMap.set(t.id, {
        tabId: t.id,
        url: t.url,
        title: t.title,
        favIconUrl: t.favIconUrl || '',
        audible: true,
        hasAudio: true
      });
    } else {
      tabMap.get(t.id).audible = true;
    }
  });

  const tabs = Array.from(tabMap.values());

  renderTabList(tabs);
}

function renderTabList(tabs) {
  const list = document.getElementById('tabList');
  const empty = document.getElementById('emptyState');

  Array.from(list.children).forEach(c => { if (c !== empty) c.remove(); });

  if (tabs.length === 0) {
    empty.style.display = 'flex';
    return;
  }
  empty.style.display = 'none';

  tabs.forEach(tabInfo => {
    const item = buildTabItem(tabInfo);
    list.appendChild(item);
  });
}

function buildTabItem(tabInfo) {
  const tabId = tabInfo.tabId;
  const domain = getDomain(tabInfo.url || '');

  // Determine initial volume: domain setting → or 100%
  if (!tabStates.has(tabId)) {
    const domainVol = domainSettings[domain];
    tabStates.set(tabId, {
      volume: domainVol !== undefined ? domainVol : 1.0,
      muted: false
    });
  }

  const state = tabStates.get(tabId);
  const displayPct = Math.round(state.volume * 100);
  const sliderVal = Math.round(masterVolume * state.volume * 100);

  const item = document.createElement('div');
  item.className = 'tab-item';
  item.dataset.tabid = tabId;

  item.innerHTML = `
    <div class="tab-top">
      <div class="audio-dot ${tabInfo.audible ? 'playing' : ''}" title="${tabInfo.audible ? 'Playing' : 'Not currently playing'}"></div>
      <img class="tab-favicon"
           src="${escHtml(tabInfo.favIconUrl)}"
           alt=""
           onerror="this.style.display='none'" />
      <div class="tab-title" title="${escHtml(tabInfo.title || tabInfo.url || '')}">${escHtml(tabInfo.title || tabInfo.url || 'Unknown Tab')}</div>
      <div class="tab-vol-label" data-tabid="${tabId}">${sliderVal}%</div>
    </div>
    <div class="tab-controls">
      <input type="range" min="0" max="200" value="${displayPct}" step="1"
             class="tab-vol-slider" data-tabid="${tabId}" style="flex:1" />
      <button class="mute-btn tab-mute-btn ${state.muted ? 'muted' : ''}" data-tabid="${tabId}">
        ${state.muted ? '🔇' : '🔊'}
      </button>
    </div>
    <div class="domain-badge">
      <span>${escHtml(domain)}</span>
      ${domain ? `<button class="domain-save-btn" data-tabid="${tabId}" data-domain="${escHtml(domain)}" title="Save this volume for ${escHtml(domain)} always">Save for domain</button>` : ''}
    </div>
  `;

  // Volume slider
  const slider = item.querySelector('.tab-vol-slider');
  const volLabel = item.querySelector('.tab-vol-label');
  const muteBtn = item.querySelector('.tab-mute-btn');

  slider.addEventListener('input', async () => {
    const vol = parseInt(slider.value, 10) / 100;
    state.volume = vol;
    const effectiveVol = (masterMuted || state.muted) ? 0 : masterVolume * vol;
    volLabel.textContent = Math.round(effectiveVol * 100) + '%';
    updatePresetHighlight(-1); // deselect all presets
    try {
      await chrome.tabs.sendMessage(tabId, {
        type: 'SET_VOLUME',
        volume: effectiveVol,
        muted: masterMuted || state.muted
      });
    } catch (e) {}
  });

  // Mute toggle
  muteBtn.addEventListener('click', async () => {
    state.muted = !state.muted;
    muteBtn.classList.toggle('muted', state.muted);
    muteBtn.textContent = state.muted ? '🔇' : '🔊';
    const effectiveVol = (masterMuted || state.muted) ? 0 : masterVolume * state.volume;
    volLabel.textContent = Math.round(effectiveVol * 100) + '%';
    try {
      await chrome.tabs.sendMessage(tabId, {
        type: 'SET_VOLUME',
        volume: effectiveVol,
        muted: masterMuted || state.muted
      });
    } catch (e) {}
  });

  // Domain save
  const domainSaveBtn = item.querySelector('.domain-save-btn');
  if (domainSaveBtn) {
    domainSaveBtn.addEventListener('click', async () => {
      const d = domainSaveBtn.dataset.domain;
      await saveDomainSetting(d, state.volume);
      toast(`✓ Saved ${Math.round(state.volume * 100)}% for ${d}`);
    });
  }

  // Apply initial volume
  const effectiveVol = (masterMuted || state.muted) ? 0 : masterVolume * state.volume;
  chrome.tabs.sendMessage(tabId, {
    type: 'SET_VOLUME',
    volume: effectiveVol,
    muted: masterMuted || state.muted
  }).catch(() => {});

  return item;
}

// ── TOAST ─────────────────────────────────────────────────────────────
let toastTimer = null;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}

// ── UTILS ─────────────────────────────────────────────────────────────
function escHtml(str = '') {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
