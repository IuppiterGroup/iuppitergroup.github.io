// Iuppiter Volume Control — Content Script
// Hooks into audio/video elements via Web Audio API (AudioContext + GainNode)
// This enables volume above 100% and precise per-tab control.

(function () {
  'use strict';

  // Avoid double-injection
  if (window.__iuppiterVolumeInjected) return;
  window.__iuppiterVolumeInjected = true;

  const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  const masterGain = audioCtx.createGain();
  masterGain.connect(audioCtx.destination);

  // Map: HTMLMediaElement → GainNode
  const elementGains = new WeakMap();

  let currentVolume = 1.0;   // 0.0–2.0
  let currentMuted = false;

  // Intercept existing and future media elements
  function hookElement(el) {
    if (elementGains.has(el)) return;
    if (!(el instanceof HTMLMediaElement)) return;

    try {
      // Resume context if suspended (browser autoplay policy)
      if (audioCtx.state === 'suspended') audioCtx.resume();

      const source = audioCtx.createMediaElementSource(el);
      const gain = audioCtx.createGain();
      gain.gain.value = currentMuted ? 0 : currentVolume;

      source.connect(gain);
      gain.connect(masterGain);
      elementGains.set(el, gain);
    } catch (e) {
      // May fail if element already has a source node — safe to ignore
    }
  }

  // Hook all existing elements
  function hookAll() {
    document.querySelectorAll('audio, video').forEach(hookElement);
  }

  hookAll();

  // Watch for new elements
  const observer = new MutationObserver(() => hookAll());
  observer.observe(document.documentElement, { childList: true, subtree: true });

  // Apply volume to all tracked elements
  function applyVolume(vol, muted) {
    currentVolume = vol;
    currentMuted = muted;
    const targetGain = muted ? 0 : vol;
    elementGains && document.querySelectorAll('audio, video').forEach(el => {
      const gain = elementGains.get(el);
      if (gain) gain.gain.setTargetAtTime(targetGain, audioCtx.currentTime, 0.01);
    });
  }

  // Listen for messages from background/popup
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'SET_VOLUME') {
      applyVolume(msg.volume, msg.muted);
      sendResponse({ ok: true });
    } else if (msg.type === 'GET_VOLUME') {
      sendResponse({ volume: currentVolume, muted: currentMuted });
    } else if (msg.type === 'TOGGLE_MUTE') {
      applyVolume(currentVolume, !currentMuted);
      sendResponse({ muted: currentMuted, volume: currentVolume });
    } else if (msg.type === 'RESUME_CONTEXT') {
      audioCtx.resume().then(() => sendResponse({ ok: true }));
      return true;
    }
  });

  // Notify background that audio may be playing on this page
  function notifyAudioPresence() {
    chrome.runtime.sendMessage({ type: 'PAGE_HAS_AUDIO', url: location.href }).catch(() => {});
  }

  // Check for any media element presence
  function checkForMedia() {
    if (document.querySelector('audio, video')) {
      notifyAudioPresence();
    }
  }

  setTimeout(checkForMedia, 1000);
  setTimeout(checkForMedia, 3000);

  // Also fire on play events
  document.addEventListener('play', (e) => {
    hookElement(e.target);
    applyVolume(currentVolume, currentMuted);
    notifyAudioPresence();
  }, true);

  document.addEventListener('pause', () => {}, true);

})();
