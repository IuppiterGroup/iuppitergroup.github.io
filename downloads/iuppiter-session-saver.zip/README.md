# ⚡ Iuppiter Session Saver

A Chrome extension (Manifest V3) for saving, restoring, and managing browser tab sessions.

## Features

| Feature | Details |
|---|---|
| **One-click save** | Saves all tabs in the current window with a custom name |
| **Restore session** | Opens all tabs from a saved session |
| **Restore options** | New window or current window; optionally close existing tabs first |
| **Auto-save** | Configurable periodic auto-save (5 / 10 / 15 / 30 / 60 min) |
| **Edit names** | Click ✎ Rename to rename any session inline |
| **Delete** | Remove individual sessions or wipe all at once |
| **Merge** | Combine two or more sessions into one (deduplicates URLs) |
| **Export / Import** | Save and restore your session library as JSON |
| **Session metadata** | Shows tab count and date saved for each session |
| **Drag to reorder** | Drag the ⠿ handle to reorder your session list |
| **Keyboard shortcut** | `Ctrl+Shift+S` quick-saves the current session |

## Installation

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer Mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `session-saver-extension/` folder

## Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl+Shift+S` | Quick-save current session |

You can customize shortcuts at `chrome://extensions/shortcuts`.

## Privacy

- **No data leaves your browser.** Everything is stored in `chrome.storage.local`.
- No analytics, no telemetry, no network requests.
- No accounts, no sign-in.

## Technical Details

- **Manifest Version:** 3
- **Storage:** `chrome.storage.local` (no quota issues for typical use)
- **Permissions:** `tabs`, `storage`, `alarms`, `windows`
- **No external dependencies**

## UI

- Dark theme with Iuppiter gold (`#c4a44a`) and blue (`#2b579a`)
- Popup width: 380px
