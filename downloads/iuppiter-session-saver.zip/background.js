// Iuppiter Session Saver — Background Service Worker

const AUTOSAVE_ALARM = 'iuppiter-autosave';

// Listen for keyboard shortcut
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'quick-save') {
    await quickSave();
  }
});

// Handle alarm for auto-save
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === AUTOSAVE_ALARM) {
    await autoSave();
  }
});

// On install / startup, restore auto-save alarm if configured
chrome.runtime.onStartup.addListener(async () => {
  await restoreAutoSaveAlarm();
});

chrome.runtime.onInstalled.addListener(async () => {
  await restoreAutoSaveAlarm();
});

async function restoreAutoSaveAlarm() {
  const { autoSaveInterval } = await chrome.storage.local.get({ autoSaveInterval: 0 });
  if (autoSaveInterval > 0) {
    await chrome.alarms.create(AUTOSAVE_ALARM, { periodInMinutes: autoSaveInterval });
  }
}

async function quickSave() {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const now = new Date();
  const name = `Quick Save — ${now.toLocaleDateString()} ${now.toLocaleTimeString()}`;
  await saveSession(name, tabs);
}

async function autoSave() {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const now = new Date();
  const name = `Auto Save — ${now.toLocaleDateString()} ${now.toLocaleTimeString()}`;
  await saveSession(name, tabs);
}

async function saveSession(name, tabs) {
  const urls = tabs
    .filter(t => t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://'))
    .map(t => ({ url: t.url, title: t.title || t.url, favIconUrl: t.favIconUrl || '' }));

  if (urls.length === 0) return;

  const { sessions = [] } = await chrome.storage.local.get({ sessions: [] });
  const session = {
    id: Date.now().toString(),
    name,
    tabs: urls,
    savedAt: new Date().toISOString()
  };
  sessions.unshift(session);
  await chrome.storage.local.set({ sessions });
}

// Message relay for popup to trigger background actions
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'SET_AUTOSAVE') {
    handleSetAutoSave(msg.intervalMinutes).then(() => sendResponse({ ok: true }));
    return true;
  }
});

async function handleSetAutoSave(intervalMinutes) {
  await chrome.alarms.clear(AUTOSAVE_ALARM);
  await chrome.storage.local.set({ autoSaveInterval: intervalMinutes });
  if (intervalMinutes > 0) {
    await chrome.alarms.create(AUTOSAVE_ALARM, { periodInMinutes: intervalMinutes });
  }
}
