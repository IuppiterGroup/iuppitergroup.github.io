// Iuppiter Session Saver — Popup Script

let sessions = [];
let dragSrcIndex = null;

// ── INIT ──────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadSessions();
  await loadSettings();
  setupTabs();
  setupSaveBar();
  setupSettings();
  setupMerge();
  renderSessions();
  renderMerge();
});

// ── DATA ──────────────────────────────────────────────────────────────
async function loadSessions() {
  const data = await chrome.storage.local.get({ sessions: [] });
  sessions = data.sessions;
}

async function saveSessions() {
  await chrome.storage.local.set({ sessions });
}

async function loadSettings() {
  const { autoSaveInterval = 0 } = await chrome.storage.local.get({ autoSaveInterval: 0 });
  document.getElementById('autoSaveInterval').value = autoSaveInterval;
}

// ── TAB NAVIGATION ────────────────────────────────────────────────────
function setupTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
      btn.classList.add('active');
      const viewId = 'view-' + btn.dataset.view;
      document.getElementById(viewId).classList.add('active');
    });
  });

  // Gear button → settings tab
  document.getElementById('btnSettings').addEventListener('click', () => {
    switchTab('settings');
  });

  // Merge button → merge tab
  document.getElementById('btnMergeView').addEventListener('click', () => {
    switchTab('merge');
    renderMerge();
  });
}

function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.view === name);
  });
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById('view-' + name).classList.add('active');
}

// ── SAVE BAR ──────────────────────────────────────────────────────────
function setupSaveBar() {
  document.getElementById('btnSave').addEventListener('click', saveCurrentSession);
  document.getElementById('sessionName').addEventListener('keydown', e => {
    if (e.key === 'Enter') saveCurrentSession();
  });
}

async function saveCurrentSession() {
  const tabs = await chrome.tabs.query({ currentWindow: true });
  const urls = tabs
    .filter(t => t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://'))
    .map(t => ({ url: t.url, title: t.title || t.url, favIconUrl: t.favIconUrl || '' }));

  if (urls.length === 0) {
    toast('No saveable tabs in this window.');
    return;
  }

  const nameInput = document.getElementById('sessionName');
  const name = nameInput.value.trim() ||
    `Session — ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`;

  const session = {
    id: Date.now().toString(),
    name,
    tabs: urls,
    savedAt: new Date().toISOString()
  };

  sessions.unshift(session);
  await saveSessions();
  nameInput.value = '';
  renderSessions();
  renderMerge();
  toast(`✓ Saved "${name}" (${urls.length} tabs)`);
}

// ── RESTORE SESSION ───────────────────────────────────────────────────
async function restoreSession(id) {
  const session = sessions.find(s => s.id === id);
  if (!session) return;

  const openInNew = document.getElementById('optNewWindow').checked;
  const closeCurrent = document.getElementById('optCloseCurrent').checked;

  if (closeCurrent) {
    const currentTabs = await chrome.tabs.query({ currentWindow: true });
    const ids = currentTabs.map(t => t.id);
    // We'll close after opening to avoid closing the extension popup itself
    if (openInNew) {
      const win = await chrome.windows.create({ url: session.tabs.map(t => t.url) });
      // Close old tabs after window is created
      await chrome.tabs.remove(ids);
    } else {
      // Open all tabs, then close old ones
      const firstTab = await chrome.tabs.create({ url: session.tabs[0].url, active: true });
      for (let i = 1; i < session.tabs.length; i++) {
        await chrome.tabs.create({ url: session.tabs[i].url, active: false });
      }
      await chrome.tabs.remove(ids);
    }
  } else if (openInNew) {
    await chrome.windows.create({ url: session.tabs.map(t => t.url) });
  } else {
    for (let i = 0; i < session.tabs.length; i++) {
      await chrome.tabs.create({ url: session.tabs[i].url, active: i === 0 });
    }
  }

  window.close();
}

// ── RENDER SESSIONS ───────────────────────────────────────────────────
function renderSessions() {
  const list = document.getElementById('sessionList');
  const empty = document.getElementById('emptyState');

  // Clear existing items (keep emptyState)
  Array.from(list.children).forEach(child => {
    if (child !== empty) child.remove();
  });

  if (sessions.length === 0) {
    empty.style.display = 'flex';
    return;
  }
  empty.style.display = 'none';

  sessions.forEach((session, index) => {
    const item = buildSessionItem(session, index);
    list.appendChild(item);
  });
}

function buildSessionItem(session, index) {
  const item = document.createElement('div');
  item.className = 'session-item';
  item.dataset.index = index;

  const savedDate = new Date(session.savedAt);
  const dateStr = savedDate.toLocaleDateString() + ' ' + savedDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  item.innerHTML = `
    <div class="session-top">
      <span class="drag-handle" title="Drag to reorder">⠿</span>
      <span class="session-name" title="${escHtml(session.name)}">${escHtml(session.name)}</span>
      <span class="tab-count">${session.tabs.length}</span>
    </div>
    <div class="session-meta">
      <span>📅 ${dateStr}</span>
    </div>
    <div class="session-actions">
      <button class="btn btn-gold btn-restore" title="Restore session">▶ Restore</button>
      <button class="btn btn-ghost btn-edit" title="Edit name">✎ Rename</button>
      <button class="btn btn-ghost btn-view" title="View tabs">👁 Tabs</button>
      <button class="btn btn-danger btn-delete" title="Delete session">✕</button>
    </div>
  `;

  // Drag events
  item.setAttribute('draggable', 'true');
  item.querySelector('.drag-handle').addEventListener('mousedown', () => item.setAttribute('draggable', 'true'));

  item.addEventListener('dragstart', e => {
    dragSrcIndex = index;
    item.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
  });
  item.addEventListener('dragend', () => item.classList.remove('dragging'));
  item.addEventListener('dragover', e => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    item.classList.add('drag-over');
  });
  item.addEventListener('dragleave', () => item.classList.remove('drag-over'));
  item.addEventListener('drop', async e => {
    e.preventDefault();
    item.classList.remove('drag-over');
    if (dragSrcIndex === null || dragSrcIndex === index) return;
    const moved = sessions.splice(dragSrcIndex, 1)[0];
    sessions.splice(index, 0, moved);
    dragSrcIndex = null;
    await saveSessions();
    renderSessions();
    renderMerge();
  });

  // Restore
  item.querySelector('.btn-restore').addEventListener('click', () => restoreSession(session.id));

  // Rename
  item.querySelector('.btn-edit').addEventListener('click', () => {
    const nameSpan = item.querySelector('.session-name');
    const input = document.createElement('input');
    input.className = 'session-name-input';
    input.value = session.name;
    nameSpan.replaceWith(input);
    input.focus();
    input.select();

    const commit = async () => {
      const newName = input.value.trim() || session.name;
      session.name = newName;
      await saveSessions();
      renderSessions();
      renderMerge();
    };
    input.addEventListener('blur', commit);
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter') commit();
      if (e.key === 'Escape') { input.value = session.name; commit(); }
    });
  });

  // View tabs
  item.querySelector('.btn-view').addEventListener('click', () => {
    showTabList(session);
  });

  // Delete
  item.querySelector('.btn-delete').addEventListener('click', async () => {
    sessions = sessions.filter(s => s.id !== session.id);
    await saveSessions();
    renderSessions();
    renderMerge();
    toast(`Deleted "${session.name}"`);
  });

  return item;
}

function showTabList(session) {
  const list = document.getElementById('sessionList');
  // Replace list content with tab list temporarily
  const prev = list.innerHTML;
  list.innerHTML = `
    <div style="padding:8px 10px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px">
      <button class="btn btn-ghost" id="btnBackToSessions" style="padding:3px 8px;font-size:11px">← Back</button>
      <span style="font-size:12px;color:var(--gold);font-weight:600">${escHtml(session.name)}</span>
    </div>
    <div style="overflow-y:auto;flex:1">
      ${session.tabs.map(t => `
        <div style="padding:6px 10px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:8px;font-size:11px">
          <img src="${escHtml(t.favIconUrl)}" width="14" height="14" style="flex-shrink:0;border-radius:2px" onerror="this.style.visibility='hidden'" />
          <div style="flex:1;overflow:hidden">
            <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text)">${escHtml(t.title)}</div>
            <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text-dim);font-size:10px">${escHtml(t.url)}</div>
          </div>
        </div>
      `).join('')}
    </div>
  `;
  document.getElementById('btnBackToSessions').addEventListener('click', () => {
    renderSessions();
  });
}

// ── MERGE VIEW ────────────────────────────────────────────────────────
function renderMerge() {
  const mergeList = document.getElementById('mergeList');
  mergeList.innerHTML = '<p>Select two or more sessions to merge into one:</p>';

  sessions.forEach(session => {
    const row = document.createElement('label');
    row.className = 'merge-session-check';
    row.innerHTML = `
      <input type="checkbox" data-id="${session.id}" />
      <span style="flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escHtml(session.name)}</span>
      <span class="tab-count">${session.tabs.length}</span>
    `;
    mergeList.appendChild(row);
  });
}

function setupMerge() {
  document.getElementById('btnMerge').addEventListener('click', async () => {
    const checked = Array.from(document.querySelectorAll('#mergeList input[type=checkbox]:checked'));
    const ids = checked.map(cb => cb.dataset.id);
    if (ids.length < 2) {
      toast('Select at least 2 sessions to merge.');
      return;
    }

    const nameInput = document.getElementById('mergeName');
    const name = nameInput.value.trim() || `Merged Session — ${new Date().toLocaleDateString()}`;

    const selected = sessions.filter(s => ids.includes(s.id));
    const allTabs = [];
    const seen = new Set();
    for (const s of selected) {
      for (const t of s.tabs) {
        if (!seen.has(t.url)) {
          seen.add(t.url);
          allTabs.push(t);
        }
      }
    }

    const merged = {
      id: Date.now().toString(),
      name,
      tabs: allTabs,
      savedAt: new Date().toISOString()
    };

    sessions.unshift(merged);
    await saveSessions();
    nameInput.value = '';
    renderSessions();
    renderMerge();
    switchTab('sessions');
    toast(`✓ Merged ${ids.length} sessions (${allTabs.length} unique tabs)`);
  });
}

// ── SETTINGS ──────────────────────────────────────────────────────────
function setupSettings() {
  document.getElementById('autoSaveInterval').addEventListener('change', async (e) => {
    const interval = parseInt(e.target.value, 10);
    await chrome.runtime.sendMessage({ type: 'SET_AUTOSAVE', intervalMinutes: interval });
    toast(interval > 0 ? `Auto-save every ${interval} min` : 'Auto-save disabled');
  });

  // Export
  document.getElementById('btnExport').addEventListener('click', async () => {
    await loadSessions();
    const json = JSON.stringify({ version: 1, sessions }, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `iuppiter-sessions-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast('Sessions exported.');
  });

  // Import
  document.getElementById('btnImport').addEventListener('click', () => {
    document.getElementById('importFile').click();
  });

  document.getElementById('importFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      let imported = [];
      if (Array.isArray(data)) imported = data;
      else if (data.sessions) imported = data.sessions;
      else throw new Error('Unrecognized format');

      // Validate basic structure
      imported = imported.filter(s => s.id && s.name && Array.isArray(s.tabs));

      await loadSessions();
      // Merge avoiding duplicate IDs
      const existingIds = new Set(sessions.map(s => s.id));
      const newOnes = imported.filter(s => !existingIds.has(s.id));
      sessions = [...sessions, ...newOnes];
      await saveSessions();
      renderSessions();
      renderMerge();
      e.target.value = '';
      toast(`✓ Imported ${newOnes.length} sessions`);
    } catch (err) {
      toast('Import failed: invalid JSON');
    }
  });

  // Clear all
  document.getElementById('btnClearAll').addEventListener('click', async () => {
    if (!confirm('Delete ALL saved sessions? This cannot be undone.')) return;
    sessions = [];
    await saveSessions();
    renderSessions();
    renderMerge();
    switchTab('sessions');
    toast('All sessions deleted.');
  });
}

// ── TOAST ─────────────────────────────────────────────────────────────
let toastTimer = null;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2500);
}

// ── UTILS ─────────────────────────────────────────────────────────────
function escHtml(str = '') {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
