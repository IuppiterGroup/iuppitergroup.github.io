/**
 * Iuppiter Mail Tracker — Background Service Worker
 * Handles Gmail OAuth, API polling, and notifications.
 */

const GMAIL_API = 'https://www.googleapis.com/gmail/v1/users/me';
const POLL_ALARM = 'iuppiter-poll';
const POLL_INTERVAL_MINUTES = 5;

// ─── OAuth ────────────────────────────────────────────────────────────────────

async function getAuthToken(interactive = false) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive, scopes: [
      'https://www.googleapis.com/auth/gmail.readonly'
    ]}, (token) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(token);
      }
    });
  });
}

async function revokeToken() {
  return new Promise((resolve) => {
    chrome.identity.clearAllCachedAuthTokens(resolve);
  });
}

// ─── Gmail API Helpers ────────────────────────────────────────────────────────

async function gmailGet(path, token) {
  const res = await fetch(`${GMAIL_API}${path}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (res.status === 401) throw new Error('AUTH_EXPIRED');
  if (!res.ok) throw new Error(`Gmail API error ${res.status}`);
  return res.json();
}

async function getSentEmails(token, maxResults = 50) {
  const data = await gmailGet(
    `/messages?labelIds=SENT&maxResults=${maxResults}&fields=messages(id,threadId)`,
    token
  );
  return data.messages || [];
}

async function getThreadDetails(threadId, token) {
  const data = await gmailGet(
    `/threads/${threadId}?fields=id,messages(id,labelIds,payload(headers),internalDate)`,
    token
  );
  return data;
}

async function getMessageHeaders(msgId, token) {
  const data = await gmailGet(
    `/messages/${msgId}?fields=id,threadId,labelIds,payload(headers),internalDate`,
    token
  );
  return data;
}

function extractHeader(headers, name) {
  const h = (headers || []).find(h => h.name.toLowerCase() === name.toLowerCase());
  return h ? h.value : '';
}

// ─── Storage Helpers ──────────────────────────────────────────────────────────

async function getTrackedEmails() {
  const data = await chrome.storage.local.get('trackedEmails');
  return data.trackedEmails || {};
}

async function saveTrackedEmails(emails) {
  await chrome.storage.local.set({ trackedEmails: emails });
}

async function getSettings() {
  const data = await chrome.storage.local.get('settings');
  return data.settings || {
    enabled: true,
    notifications: true,
    autoPollSent: true
  };
}

// ─── Core Tracking Logic ──────────────────────────────────────────────────────

/**
 * Scan the last N sent emails and add any new ones to tracking.
 */
async function syncSentEmails(token) {
  const sentMsgs = await getSentEmails(token, 50);
  const tracked = await getTrackedEmails();
  let updated = false;

  for (const { id, threadId } of sentMsgs) {
    if (tracked[id]) continue; // already known

    try {
      const msg = await getMessageHeaders(id, token);
      const headers = msg.payload?.headers || [];
      const subject = extractHeader(headers, 'Subject') || '(no subject)';
      const to = extractHeader(headers, 'To');
      const date = parseInt(msg.internalDate, 10) || Date.now();

      tracked[id] = {
        messageId: id,
        threadId,
        subject,
        to,
        sentAt: date,
        status: 'sent',          // sent | replied | read_receipt
        repliedAt: null,
        readReceiptAt: null,
        notified: false,
        trackingEnabled: true
      };
      updated = true;
    } catch (e) {
      // Skip individual failures
    }
  }

  if (updated) await saveTrackedEmails(tracked);
}

/**
 * Check each tracked email's thread for replies or read receipts.
 */
async function pollEmailStatuses(token) {
  const tracked = await getTrackedEmails();
  const settings = await getSettings();
  let anyUpdated = false;

  for (const [id, email] of Object.entries(tracked)) {
    if (!email.trackingEnabled) continue;

    try {
      const thread = await getThreadDetails(email.threadId, token);
      const messages = thread.messages || [];

      // A reply exists if any message in the thread is NOT in SENT
      const hasReply = messages.some(m => {
        const labels = m.labelIds || [];
        return !labels.includes('SENT') && !labels.includes('DRAFT');
      });

      // Look for read receipt message
      const readReceiptMsg = messages.find(m => {
        const headers = m.payload?.headers || [];
        const subject = extractHeader(headers, 'Subject') || '';
        return subject.toLowerCase().includes('read:') ||
               subject.toLowerCase().includes('read receipt');
      });

      let statusChanged = false;

      if (readReceiptMsg && email.status !== 'read_receipt') {
        tracked[id].status = 'read_receipt';
        tracked[id].readReceiptAt = parseInt(readReceiptMsg.internalDate, 10) || Date.now();
        statusChanged = true;
      } else if (hasReply && email.status === 'sent') {
        // Find the first non-sent message as the reply
        const replyMsg = messages.find(m => {
          const labels = m.labelIds || [];
          return !labels.includes('SENT') && !labels.includes('DRAFT');
        });
        tracked[id].status = 'replied';
        tracked[id].repliedAt = replyMsg
          ? parseInt(replyMsg.internalDate, 10) || Date.now()
          : Date.now();
        statusChanged = true;
      }

      if (statusChanged) {
        anyUpdated = true;
        if (settings.notifications && !email.notified) {
          tracked[id].notified = true;
          const label = tracked[id].status === 'read_receipt' ? 'Read Receipt' : 'Got a Reply';
          chrome.notifications.create(`iuppiter-${id}`, {
            type: 'basic',
            iconUrl: 'icons/icon48.png',
            title: `✉️ Iuppiter: ${label}`,
            message: `"${email.subject.slice(0, 60)}" — ${label.toLowerCase()} from ${email.to.slice(0, 40)}`
          });
        }
      }
    } catch (e) {
      // Silently skip — thread may have been deleted
    }
  }

  if (anyUpdated) await saveTrackedEmails(tracked);
}

// ─── Main Poll Cycle ──────────────────────────────────────────────────────────

async function runPoll() {
  const settings = await getSettings();
  if (!settings.enabled) return;

  let token;
  try {
    token = await getAuthToken(false);
  } catch {
    return; // Not signed in yet — skip silently
  }

  try {
    await syncSentEmails(token);
    await pollEmailStatuses(token);
    await chrome.storage.local.set({ lastPoll: Date.now() });
  } catch (e) {
    if (e.message === 'AUTH_EXPIRED') {
      await revokeToken();
    }
  }
}

// ─── Alarm Setup ─────────────────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === POLL_ALARM) runPoll();
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(POLL_ALARM, {
    periodInMinutes: POLL_INTERVAL_MINUTES
  });
  runPoll();
});

chrome.runtime.onStartup.addListener(() => {
  runPoll();
});

// ─── Message Passing ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'GET_TRACKED') {
    getTrackedEmails().then(sendResponse);
    return true;
  }

  if (msg.type === 'SIGN_IN') {
    getAuthToken(true)
      .then(() => { runPoll(); sendResponse({ ok: true }); })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.type === 'SIGN_OUT') {
    revokeToken().then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'FORCE_POLL') {
    runPoll().then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'TOGGLE_TRACKING') {
    getTrackedEmails().then(async tracked => {
      if (tracked[msg.messageId]) {
        tracked[msg.messageId].trackingEnabled = msg.enabled;
        await saveTrackedEmails(tracked);
      }
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === 'GET_SETTINGS') {
    getSettings().then(sendResponse);
    return true;
  }

  if (msg.type === 'SAVE_SETTINGS') {
    chrome.storage.local.set({ settings: msg.settings }).then(() => sendResponse({ ok: true }));
    return true;
  }
});
