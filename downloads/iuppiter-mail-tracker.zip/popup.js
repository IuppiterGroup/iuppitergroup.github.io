/**
 * Iuppiter Mail Tracker — Popup Script
 */

const $ = id => document.getElementById(id);

let currentFilter = 'all';
let allEmails = {};
let settings = {};

// ─── View Switcher ────────────────────────────────────────────────────────────

function showView(name) {
  ['view-signin', 'view-main', 'view-settings'].forEach(v => {
    const el = $(v);
    if (el) el.classList.toggle('hidden', v !== `view-${name}`);
  });
}

// ─── Date Formatting ──────────────────────────────────────────────────────────

function fmtDate(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const now = new Date();
  const diffMs = now - d;
  const diffDays = Math.floor(diffMs / 86400000);
  if (diffDays === 0) return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  if (diffDays < 7) return `${diffDays}d ago`;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function fmtLastPoll(ts) {
  if (!ts) return 'never';
  const diffS = Math.floor((Date.now() - ts) / 1000);
  if (diffS < 60) return 'just now';
  if (diffS < 3600) return `${Math.floor(diffS / 60)}m ago`;
  return `${Math.floor(diffS / 3600)}h ago`;
}

// ─── Stats ────────────────────────────────────────────────────────────────────

function updateStats(emails) {
  const vals = Object.values(emails);
  const total = vals.length;
  const replied = vals.filter(e => e.status === 'replied').length;
  const receipt = vals.filter(e => e.status === 'read_receipt').length;
  const rate = total > 0 ? Math.round(((replied + receipt) / total) * 100) : 0;

  $('stat-total').textContent = total;
  $('stat-replied').textContent = replied;
  $('stat-receipt').textContent = receipt;
  $('stat-rate').textContent = total > 0 ? `${rate}%` : '—';
}

// ─── Email List Render ────────────────────────────────────────────────────────

const STATUS_LABELS = {
  sent: { icon: '✓', cls: 'status-sent', label: 'Sent' },
  replied: { icon: '✓✓', cls: 'status-replied', label: 'Replied' },
  read_receipt: { icon: '✓✓', cls: 'status-read_receipt', label: 'Read' }
};

function renderEmailList(emails) {
  const list = $('email-list');
  const emptyState = $('empty-state');

  const filtered = Object.entries(emails).filter(([, e]) => {
    if (currentFilter === 'all') return true;
    return e.status === currentFilter;
  });

  // Sort by sent date descending
  filtered.sort((a, b) => (b[1].sentAt || 0) - (a[1].sentAt || 0));

  if (filtered.length === 0) {
    emptyState.classList.remove('hidden');
    // Remove old items
    Array.from(list.querySelectorAll('.email-item')).forEach(el => el.remove());
    return;
  }

  emptyState.classList.add('hidden');

  // Build new list (remove old first)
  Array.from(list.querySelectorAll('.email-item')).forEach(el => el.remove());

  for (const [id, email] of filtered) {
    const statusInfo = STATUS_LABELS[email.status] || STATUS_LABELS.sent;
    const item = document.createElement('div');
    item.className = 'email-item';
    item.dataset.id = id;

    const trackLabel = email.trackingEnabled ? 'Pause' : 'Resume';
    const toggleCls = email.trackingEnabled ? '' : 'disabled';
    const dateStr = email.repliedAt
      ? `Replied ${fmtDate(email.repliedAt)}`
      : (email.readReceiptAt ? `Read ${fmtDate(email.readReceiptAt)}` : `Sent ${fmtDate(email.sentAt)}`);

    item.innerHTML = `
      <div class="email-status ${statusInfo.cls}">${statusInfo.icon}</div>
      <div class="email-info">
        <div class="email-subject" title="${escHtml(email.subject)}">${escHtml(truncate(email.subject, 45))}</div>
        <div class="email-to">${escHtml(truncate(email.to || '', 40))}</div>
        <div class="email-date">${dateStr}</div>
      </div>
      <button class="email-toggle ${toggleCls}" data-id="${id}" data-enabled="${email.trackingEnabled ? '1' : '0'}">${trackLabel}</button>
    `;
    list.appendChild(item);
  }

  // Toggle buttons
  list.querySelectorAll('.email-toggle').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const msgId = btn.dataset.id;
      const nowEnabled = btn.dataset.enabled === '1';
      chrome.runtime.sendMessage({
        type: 'TOGGLE_TRACKING',
        messageId: msgId,
        enabled: !nowEnabled
      }, () => loadData());
    });
  });
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function truncate(str, len) {
  return str.length > len ? str.slice(0, len) + '…' : str;
}

// ─── Load Data ────────────────────────────────────────────────────────────────

function loadData() {
  chrome.runtime.sendMessage({ type: 'GET_TRACKED' }, (emails) => {
    if (!emails) return;
    allEmails = emails;
    updateStats(emails);
    renderEmailList(emails);
  });

  chrome.storage.local.get('lastPoll', ({ lastPoll }) => {
    $('last-poll-label').textContent = `Last sync: ${fmtLastPoll(lastPoll)}`;
  });
}

// ─── Settings ─────────────────────────────────────────────────────────────────

function loadSettings() {
  chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }, (s) => {
    if (!s) return;
    settings = s;
    $('setting-enabled').checked = !!s.enabled;
    $('setting-notifs').checked = !!s.notifications;
    $('setting-auto').checked = !!s.autoPollSent;
  });
}

function saveSettings() {
  const updated = {
    enabled: $('setting-enabled').checked,
    notifications: $('setting-notifs').checked,
    autoPollSent: $('setting-auto').checked
  };
  chrome.runtime.sendMessage({ type: 'SAVE_SETTINGS', settings: updated });
}

// ─── Auth Check ───────────────────────────────────────────────────────────────

function checkAuth() {
  // Try to get token silently; if it fails, show sign-in
  chrome.identity.getAuthToken({ interactive: false }, (token) => {
    if (token) {
      showView('main');
      loadData();
    } else {
      showView('signin');
    }
  });
}

// ─── Event Wiring ─────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  checkAuth();

  $('btn-signin').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'SIGN_IN' }, (resp) => {
      if (resp?.ok) {
        showView('main');
        loadData();
      }
    });
  });

  $('btn-signout').addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'SIGN_OUT' }, () => {
      showView('signin');
    });
  });

  $('btn-refresh').addEventListener('click', () => {
    $('btn-refresh').textContent = '⟳';
    chrome.runtime.sendMessage({ type: 'FORCE_POLL' }, () => {
      setTimeout(() => {
        loadData();
        $('btn-refresh').textContent = '↻';
      }, 1500);
    });
  });

  $('btn-settings').addEventListener('click', () => {
    loadSettings();
    showView('settings');
  });

  $('btn-back').addEventListener('click', () => {
    saveSettings();
    showView('main');
    loadData();
  });

  // Tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentFilter = tab.dataset.filter;
      renderEmailList(allEmails);
    });
  });

  // Settings toggles auto-save
  ['setting-enabled', 'setting-notifs', 'setting-auto'].forEach(id => {
    $(id).addEventListener('change', saveSettings);
  });

  // Export
  $('btn-export').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(allEmails, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `iuppiter-tracker-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });

  // Clear data
  $('btn-clear').addEventListener('click', () => {
    if (confirm('Clear ALL tracking data? This cannot be undone.')) {
      chrome.storage.local.set({ trackedEmails: {} }, () => {
        allEmails = {};
        updateStats({});
        renderEmailList({});
        showView('main');
      });
    }
  });
});
