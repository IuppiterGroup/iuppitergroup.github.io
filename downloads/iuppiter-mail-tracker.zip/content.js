/**
 * Iuppiter Mail Tracker — Gmail Content Script
 * Injects status indicators (✓ / ✓✓ / 📨) next to sent emails in Gmail.
 */

const STATUS_ICONS = {
  sent: { icon: '✓', label: 'Sent', color: '#888' },
  replied: { icon: '✓✓', label: 'Replied', color: '#c4a44a' },
  read_receipt: { icon: '✓✓', label: 'Read (Receipt)', color: '#2b579a' }
};

let trackedEmails = {};
let injectInterval = null;

// ─── Communication ────────────────────────────────────────────────────────────

function loadTrackedEmails() {
  chrome.runtime.sendMessage({ type: 'GET_TRACKED' }, (resp) => {
    if (resp) {
      trackedEmails = resp;
      injectStatusBadges();
    }
  });
}

// ─── Badge Injection ──────────────────────────────────────────────────────────

/**
 * Find email rows in Gmail's sent view and inject status badges.
 * Gmail's DOM is heavily obfuscated — we match by subject text.
 */
function injectStatusBadges() {
  // Map subject -> tracked entry for fast lookup
  const bySubject = {};
  for (const [id, email] of Object.entries(trackedEmails)) {
    if (!email.trackingEnabled) continue;
    const key = normalizeSubject(email.subject);
    if (!bySubject[key]) bySubject[key] = email;
  }

  if (Object.keys(bySubject).length === 0) return;

  // Gmail email rows in list view
  const rows = document.querySelectorAll('tr.zA');
  for (const row of rows) {
    if (row.dataset.iuppiterBadged) continue;

    const subjectEl = row.querySelector('.bog, .bqe, span[data-thread-id]') ||
                      row.querySelector('.y6 > span');
    if (!subjectEl) continue;

    const subjectText = normalizeSubject(subjectEl.textContent || '');
    const match = bySubject[subjectText];
    if (!match) continue;

    const statusInfo = STATUS_ICONS[match.status] || STATUS_ICONS.sent;
    injectBadge(row, statusInfo, match);
    row.dataset.iuppiterBadged = '1';
  }
}

function injectBadge(row, statusInfo, email) {
  const badge = document.createElement('span');
  badge.className = 'iuppiter-badge';
  badge.title = `Iuppiter: ${statusInfo.label} — ${formatDate(email.sentAt)}`;
  badge.style.cssText = `
    display: inline-block;
    font-size: 11px;
    font-weight: bold;
    color: ${statusInfo.color};
    margin-left: 6px;
    cursor: default;
    vertical-align: middle;
    font-family: 'Google Sans', Arial, sans-serif;
    user-select: none;
  `;
  badge.textContent = statusInfo.icon;

  // Try to append after the subject span
  const subjectEl = row.querySelector('.bog') || row.querySelector('.bqe') || row.querySelector('.y6 > span');
  if (subjectEl) {
    subjectEl.parentNode.insertBefore(badge, subjectEl.nextSibling);
  }
}

function normalizeSubject(text) {
  return text.replace(/^(re:|fwd?:)\s*/i, '').trim().toLowerCase().slice(0, 80);
}

function formatDate(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });
}

// ─── DOM Observer ─────────────────────────────────────────────────────────────

let observer = null;
function startObserver() {
  observer = new MutationObserver(() => {
    injectStatusBadges();
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// ─── Compose Tracking Helper ──────────────────────────────────────────────────

/**
 * Watch for compose window open/close to trigger a poll after send.
 */
function watchForSend() {
  // Gmail fires a network request when email is sent; we detect compose close.
  const origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    if (method === 'POST' && url.includes('/gmail/v1/users/me/messages/send')) {
      setTimeout(() => {
        chrome.runtime.sendMessage({ type: 'FORCE_POLL' });
        setTimeout(loadTrackedEmails, 3000);
      }, 1500);
    }
    return origOpen.call(this, method, url, ...rest);
  };
}

// ─── Init ─────────────────────────────────────────────────────────────────────

function init() {
  loadTrackedEmails();
  startObserver();
  watchForSend();

  // Refresh badges every 30s (Gmail is a SPA — DOM changes frequently)
  setInterval(loadTrackedEmails, 30000);
}

// Wait for Gmail to fully load
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
