# Iuppiter Mail Tracker

Track your Gmail sent emails — see when recipients reply. Dark-themed, local-only, no accounts.

---

## Features

- **✓ / ✓✓ status badges** next to sent emails in Gmail (like WhatsApp read receipts)
- **Reply detection** — gold ✓✓ when a recipient replies to your email
- **Read receipt detection** — blue ✓✓ when Gmail read receipt is confirmed
- **Dashboard popup** with stats (total tracked, replied, read %, reply rate)
- **Filter by status** — All / Replied / Pending / Read
- **Notifications** — desktop alert when status changes
- **Per-email toggle** — pause tracking for individual emails
- **Export data** as JSON
- **100% local** — all data in chrome.storage.local, no servers

---

## Install

1. Generate icons (one-time):
   ```
   pip install Pillow
   python generate_icons.py
   ```

2. **Set up Gmail API credentials** (required for OAuth):
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project (e.g. "Iuppiter Mail Tracker")
   - Enable the **Gmail API**
   - Create **OAuth 2.0 credentials** → Application type: **Chrome Extension**
   - Add your extension ID (from `chrome://extensions/`) to authorized origins
   - Copy the **Client ID** and paste it into `manifest.json`:
     ```json
     "oauth2": {
       "client_id": "YOUR_CLIENT_ID.apps.googleusercontent.com",
       "scopes": ["https://www.googleapis.com/auth/gmail.readonly"]
     }
     ```

3. Open Chrome → `chrome://extensions/`
4. Enable **Developer mode** (top-right toggle)
5. Click **Load unpacked** → select this folder

---

## How Tracking Works

| Status | Icon | Meaning |
|--------|------|---------|
| Sent   | ✓ (grey) | Email delivered to recipient's server |
| Replied | ✓✓ (gold) | Recipient replied to your thread |
| Read Receipt | ✓✓ (blue) | Gmail read receipt confirmed |

> **Note:** Pixel-based open tracking (knowing exactly when someone *opened* your email without replying) requires a hosted pixel server. This extension uses Gmail API reply detection and read receipts — both are fully functional and require no server.

---

## Privacy

- No data is sent anywhere external
- All tracking data stored in `chrome.storage.local`
- Only reads your own Gmail sent folder (read-only OAuth scope)
- You can clear all data at any time from Settings

---

## Branding

Gold `#c4a44a` | Blue `#2b579a` | Dark background `#1a1a1e`
