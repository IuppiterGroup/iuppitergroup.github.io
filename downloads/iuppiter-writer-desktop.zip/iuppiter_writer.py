# -*- coding: utf-8 -*-
"""
Iuppiter Writer v2 -- Native .docx Editor
Phase 2: Full editing — rich text sync, formatting, undo/redo, styles, lists.

Architecture:
  - python-docx Document object is the source of truth
  - tkinter Text widget displays rendered content with tags for formatting
  - _para_metadata[line_num] tracks per-paragraph style/alignment/spacing/indent/list
  - On save: character-by-character segment analysis rebuilds runs with correct formatting
  - Full round-trip fidelity: open .docx → render → edit → save .docx
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser
import tkinter.font as tkfont
import os
import sys
import re
from copy import deepcopy

try:
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches, Emu
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_BREAK
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    from docx.text.paragraph import Paragraph as WDParagraph
    from docx.table import Table as WDTable
    import lxml.etree as etree
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False
    messagebox.showerror("Missing Dependency",
        "python-docx is not installed.\nRun: pip install python-docx")
    sys.exit(1)

try:
    from PIL import Image as PILImage, ImageTk
    from io import BytesIO
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

# ─── Constants ────────────────────────────────────────────────────────────────

WORD_BLUE      = "#2b579a"
WORD_BLUE_DARK = "#1e3f73"
WORD_BLUE_LITE = "#d6e4f7"
WORD_WHITE     = "#ffffff"
WORD_GRAY_BG   = "#f3f3f3"
WORD_GRAY_LINE = "#d1d1d1"
WORD_TEXT      = "#1a1a1a"
WORD_ACCENT    = "#c7deff"

# Phase 4: dark mode palette
DARK_BG        = "#1e1e1e"
DARK_EDITOR    = "#252526"
DARK_TEXT      = "#d4d4d4"
DARK_RIBBON    = "#2d2d30"
DARK_STATUSBAR = "#007acc"

# Phase 4: Iuppiter branding
IUPPITER_GOLD  = "#c4a44a"

# Phase 4: recent files
RECENT_FILES_PATH = os.path.join(os.path.expanduser("~"), ".iuppiter_recent.txt")
MAX_RECENT = 10

HEADING_SIZES  = {1: 28, 2: 22, 3: 18, 4: 16, 5: 14, 6: 13}
HEADING_COLORS = {1: "#1f3864", 2: "#2e74b5", 3: "#2e74b5",
                  4: "#2e74b5", 5: "#595959", 6: "#595959"}

FONT_FAMILIES = [
    "Calibri", "Arial", "Times New Roman", "Georgia", "Verdana",
    "Helvetica", "Trebuchet MS", "Courier New", "Comic Sans MS",
    "Palatino Linotype", "Book Antiqua", "Garamond", "Century Gothic",
]
FONT_SIZES = ["8", "9", "10", "11", "12", "14", "16", "18", "20",
              "22", "24", "26", "28", "36", "48", "72"]

STYLE_NAMES = [
    "Normal", "Heading 1", "Heading 2", "Heading 3",
    "Heading 4", "Heading 5", "Heading 6",
    "Title", "Subtitle", "Quote", "List Paragraph"
]

LINE_SPACING_OPTIONS = ["1.0", "1.15", "1.5", "2.0"]

ALIGN_MAP = {
    WD_ALIGN_PARAGRAPH.LEFT:     "left",
    WD_ALIGN_PARAGRAPH.CENTER:   "center",
    WD_ALIGN_PARAGRAPH.RIGHT:    "right",
    WD_ALIGN_PARAGRAPH.JUSTIFY:  "justify",
    None:                         "left",
}

ALIGN_TO_WD = {
    "left":    WD_ALIGN_PARAGRAPH.LEFT,
    "center":  WD_ALIGN_PARAGRAPH.CENTER,
    "right":   WD_ALIGN_PARAGRAPH.RIGHT,
    "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
}

# ─── Utility helpers ──────────────────────────────────────────────────────────

def rgb_to_hex(rgb_color):
    """Convert python-docx RGBColor to #rrggbb string."""
    if rgb_color is None:
        return None
    try:
        return "#{:02x}{:02x}{:02x}".format(rgb_color.red, rgb_color.green, rgb_color.blue)
    except Exception:
        return None


def hex_to_rgb(hex_color):
    """Convert #rrggbb to (r, g, b) tuple."""
    h = hex_color.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))


def pt_to_px(pt):
    """Approximate point → pixel (96dpi screen)."""
    return int(pt * 96 / 72) if pt else 12


def safe_font_size(size_val):
    """Return a safe integer font size from Pt/half-pt values."""
    if size_val is None:
        return 12
    try:
        return max(6, min(int(size_val.pt), 96))
    except Exception:
        try:
            return max(6, min(int(size_val), 96))
        except Exception:
            return 12


# ─── Main Application ─────────────────────────────────────────────────────────

class IuppiterWriter(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Document1 - Iuppiter Writer")
        self.geometry("1200x820")
        self.minsize(800, 600)
        self.configure(bg=WORD_WHITE)

        # Set window icon (.ico file next to this script)
        _ico = os.path.join(os.path.dirname(os.path.abspath(__file__)), "iuppiter_writer.ico")
        if os.path.isfile(_ico):
            try:
                self.iconbitmap(_ico)
            except Exception:
                pass  # icon load failure is non-fatal

        # Application state
        self.current_file    = None          # path to open .docx
        self.doc             = None          # python-docx Document object
        self.is_modified     = False
        self._ignore_changes = False         # suppress change events during load
        self._tag_counter    = 0             # unique tag id generator
        self._para_map       = {}            # line_index → paragraph object
        self._doc_counter    = 0             # "Document1", "Document2", ...
        self._doc_name       = "Document1"   # display name in title bar

        # Phase 2: per-paragraph metadata
        # Keys are line numbers (1-based); values are dicts with:
        #   style, alignment, line_spacing, indent_level, list_type
        self._para_metadata  = {}

        # Formatting state (tracked for toolbar sync)
        self._cur_font_family  = tk.StringVar(value="Calibri")
        self._cur_font_size    = tk.StringVar(value="12")
        self._cur_style        = tk.StringVar(value="Normal")
        self._cur_line_spacing = tk.StringVar(value="1.0")
        self._bold_on          = tk.BooleanVar(value=False)
        self._italic_on        = tk.BooleanVar(value=False)
        self._underline_on     = tk.BooleanVar(value=False)
        self._align_state      = tk.StringVar(value="left")
        self._cur_color        = "#000000"

        # Internal clipboard for formatted paste
        self._fmt_clipboard    = None   # list of (text, fmt_dict) segments

        # Phase 3: tables, images, headers/footers
        self._embedded_tables  = []   # list of {frame, cells, doc_table, rows, cols}
        self._image_refs       = []   # PIL PhotoImage refs (prevent GC)
        self._doc_body_items   = []   # ordered body elements: {type, obj, ...}

        # Phase 4: new state
        self._zoom_level    = 100       # percent, 50-200
        self._dark_mode     = False
        self._ruler_visible = True
        self._recent_files  = self._load_recent_files()
        self._find_dialog   = None      # singleton find/replace window

        self._build_ui()
        self._bind_shortcuts()
        self._new_document()          # start with a blank doc

        # Update status bar periodically
        self.after(500, self._periodic_update)

    # ─── UI Construction ──────────────────────────────────────────────────────

    def _build_ui(self):
        self._build_titlebar_decoration()
        self._build_menubar()
        self._build_ribbon()
        self._build_ruler()
        self._build_header_footer_ui()   # Phase 3: header/footer panels
        self._build_editor()
        self._build_statusbar()

    def _build_titlebar_decoration(self):
        """Blue strip under the window title (above menu bar)."""
        frame = tk.Frame(self, bg=WORD_BLUE, height=4)
        frame.pack(fill="x", side="top")

    def _build_menubar(self):
        menubar = tk.Menu(self, bg=WORD_WHITE, fg=WORD_TEXT,
                          activebackground=WORD_BLUE, activeforeground=WORD_WHITE,
                          relief="flat", borderwidth=0)
        self.config(menu=menubar)

        # File menu
        file_menu = tk.Menu(menubar, tearoff=False,
                            bg=WORD_WHITE, fg=WORD_TEXT,
                            activebackground=WORD_BLUE, activeforeground=WORD_WHITE)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New          Ctrl+N", command=self._cmd_new)
        file_menu.add_command(label="Open...      Ctrl+O", command=self._cmd_open)
        file_menu.add_separator()
        file_menu.add_command(label="Save         Ctrl+S", command=self._cmd_save)
        file_menu.add_command(label="Save As...", command=self._cmd_save_as)
        file_menu.add_separator()
        file_menu.add_command(label="Print...     Ctrl+P", command=self._cmd_print)
        file_menu.add_separator()
        # Recent files sub-menu
        self._recent_menu = tk.Menu(file_menu, tearoff=False,
                                    bg=WORD_WHITE, fg=WORD_TEXT,
                                    activebackground=WORD_BLUE, activeforeground=WORD_WHITE)
        file_menu.add_cascade(label="Recent Documents", menu=self._recent_menu)
        self._rebuild_recent_menu()
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self._cmd_exit)

        # Edit menu
        edit_menu = tk.Menu(menubar, tearoff=False,
                            bg=WORD_WHITE, fg=WORD_TEXT,
                            activebackground=WORD_BLUE, activeforeground=WORD_WHITE)
        menubar.add_cascade(label="Edit", menu=edit_menu)
        edit_menu.add_command(label="Undo   Ctrl+Z", command=self._cmd_undo)
        edit_menu.add_command(label="Redo   Ctrl+Y", command=self._cmd_redo)
        edit_menu.add_separator()
        edit_menu.add_command(label="Cut    Ctrl+X", command=self._cmd_cut)
        edit_menu.add_command(label="Copy   Ctrl+C", command=self._cmd_copy)
        edit_menu.add_command(label="Paste  Ctrl+V", command=self._cmd_paste)
        edit_menu.add_separator()
        edit_menu.add_command(label="Select All  Ctrl+A",
                              command=lambda: self.editor.tag_add("sel", "1.0", "end"))
        edit_menu.add_separator()
        edit_menu.add_command(label="Find & Replace  Ctrl+H", command=self._cmd_find_replace)

        # Insert menu (Phase 3)
        ins_menu = tk.Menu(menubar, tearoff=False,
                           bg=WORD_WHITE, fg=WORD_TEXT,
                           activebackground=WORD_BLUE, activeforeground=WORD_WHITE)
        menubar.add_cascade(label="Insert", menu=ins_menu)
        ins_menu.add_command(label="Table...",       command=self._cmd_insert_table)
        ins_menu.add_command(label="Picture...",     command=self._cmd_insert_image)
        ins_menu.add_separator()
        ins_menu.add_command(label="Page Break  Ctrl+Return",
                             command=self._cmd_insert_page_break)
        ins_menu.add_separator()
        ins_menu.add_command(label="Header",  command=self._cmd_edit_header)
        ins_menu.add_command(label="Footer",  command=self._cmd_edit_footer)

        # Format menu
        fmt_menu = tk.Menu(menubar, tearoff=False,
                           bg=WORD_WHITE, fg=WORD_TEXT,
                           activebackground=WORD_BLUE, activeforeground=WORD_WHITE)
        menubar.add_cascade(label="Format", menu=fmt_menu)
        fmt_menu.add_command(label="Bold   Ctrl+B", command=self._toggle_bold)
        fmt_menu.add_command(label="Italic  Ctrl+I", command=self._toggle_italic)
        fmt_menu.add_command(label="Underline  Ctrl+U", command=self._toggle_underline)
        fmt_menu.add_separator()
        fmt_menu.add_command(label="Text Color...", command=self._pick_text_color)
        fmt_menu.add_separator()
        fmt_menu.add_command(label="Increase Indent  Tab", command=self._indent_increase)
        fmt_menu.add_command(label="Decrease Indent  Shift+Tab", command=self._indent_decrease)
        fmt_menu.add_separator()
        line_menu = tk.Menu(fmt_menu, tearoff=False, bg=WORD_WHITE, fg=WORD_TEXT,
                            activebackground=WORD_BLUE, activeforeground=WORD_WHITE)
        fmt_menu.add_cascade(label="Line Spacing", menu=line_menu)
        for sp in LINE_SPACING_OPTIONS:
            line_menu.add_command(label=sp, command=lambda s=sp: self._set_line_spacing(s))

        # View menu
        view_menu = tk.Menu(menubar, tearoff=False,
                            bg=WORD_WHITE, fg=WORD_TEXT,
                            activebackground=WORD_BLUE, activeforeground=WORD_WHITE)
        menubar.add_cascade(label="View", menu=view_menu)
        view_menu.add_command(label="Zoom In   Ctrl++", command=self._zoom_in)
        view_menu.add_command(label="Zoom Out  Ctrl+-", command=self._zoom_out)
        view_menu.add_separator()
        view_menu.add_command(label="Toggle Ruler", command=self._toggle_ruler)
        view_menu.add_command(label="Toggle Dark Mode", command=self._toggle_dark_mode)

        # Help menu
        help_menu = tk.Menu(menubar, tearoff=False,
                            bg=WORD_WHITE, fg=WORD_TEXT,
                            activebackground=WORD_BLUE, activeforeground=WORD_WHITE)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="Help   F1", command=self._cmd_help)
        help_menu.add_separator()
        help_menu.add_command(label="About Iuppiter Writer", command=self._cmd_about)

    def _build_ribbon(self):
        """Word-style ribbon — blue tab bar, white content, group dividers."""
        self._ribbon_outer = tk.Frame(self, bg=WORD_BLUE, padx=0, pady=0)
        self._ribbon_outer.pack(fill="x", side="top")

        # Tab bar — blue background, tabs look like Word 2019
        self._ribbon_tabbar = tk.Frame(self._ribbon_outer, bg=WORD_BLUE)
        self._ribbon_tabbar.pack(fill="x", padx=0, pady=(0, 0))

        self._ribbon_tabs = {}
        self._active_tab  = tk.StringVar(value="Home")

        for tab_name in ["Home", "Insert", "Design", "Layout", "View"]:
            btn = tk.Label(self._ribbon_tabbar, text=tab_name,
                           bg=WORD_BLUE, fg=WORD_WHITE,
                           font=("Segoe UI", 9),
                           padx=14, pady=6, cursor="hand2")
            btn.pack(side="left")
            btn.bind("<Button-1>", lambda e, t=tab_name: self._select_tab(t))
            btn.bind("<Enter>",    lambda e, b=btn, t=tab_name: self._tab_hover(b, t, True))
            btn.bind("<Leave>",    lambda e, b=btn, t=tab_name: self._tab_hover(b, t, False))
            self._ribbon_tabs[tab_name] = btn

        # Ribbon content area — white, fixed height, contains groups
        self._ribbon_content = tk.Frame(self._ribbon_outer, bg=WORD_WHITE,
                                        relief="flat", bd=0, height=88)
        self._ribbon_content.pack(fill="x")
        self._ribbon_content.pack_propagate(False)

        # Bottom border under ribbon
        tk.Frame(self, bg=WORD_GRAY_LINE, height=1).pack(fill="x", side="top")

        self._tab_panels = {}
        self._build_home_tab()
        self._build_insert_tab()    # Phase 3
        self._build_design_tab()    # Phase 4
        self._build_layout_tab()    # Phase 4
        self._build_view_tab()      # Phase 4
        self._select_tab("Home")

    def _select_tab(self, name):
        """Switch active ribbon tab — active tab appears white (connected to content)."""
        self._active_tab.set(name)
        ribbon_bg = DARK_RIBBON if self._dark_mode else WORD_BLUE
        content_bg = DARK_BG if self._dark_mode else WORD_WHITE

        for tname, btn in self._ribbon_tabs.items():
            if tname == name:
                btn.config(bg=content_bg,
                           fg=WORD_BLUE if not self._dark_mode else DARK_TEXT,
                           relief="flat", font=("Segoe UI", 9, "bold"))
            else:
                btn.config(bg=ribbon_bg, fg=WORD_WHITE, relief="flat",
                           font=("Segoe UI", 9))

        for pname, panel in self._tab_panels.items():
            if pname == name:
                panel.pack(fill="both", expand=True)
            else:
                panel.pack_forget()

    def _tab_hover(self, btn, tab_name, entering):
        """Hover effect on non-active tabs."""
        if tab_name == self._active_tab.get():
            return
        ribbon_bg = DARK_RIBBON if self._dark_mode else WORD_BLUE
        if entering:
            btn.config(bg="#3a6bbf")
        else:
            btn.config(bg=ribbon_bg)

    def _build_home_tab(self):
        panel = tk.Frame(self._ribbon_content, bg=WORD_WHITE)
        self._tab_panels["Home"] = panel

        # ── Clipboard group ──────────────────────────────────────────────
        grp_clip = self._ribbon_group(panel, "Clipboard")
        self._ribbon_btn(grp_clip, "Paste",  self._cmd_paste, wide=True)
        sub = tk.Frame(grp_clip, bg=WORD_WHITE)
        sub.pack(side="left")
        self._ribbon_btn(sub, "Cut",  self._cmd_cut)
        self._ribbon_btn(sub, "Copy", self._cmd_copy)
        self._group_separator(panel)

        # ── Font group ───────────────────────────────────────────────────
        grp_font = self._ribbon_group(panel, "Font")

        # Row 1: Font family + Font size + grow/shrink
        row1 = tk.Frame(grp_font, bg=WORD_WHITE)
        row1.pack(fill="x")

        self._font_cb = ttk.Combobox(row1, textvariable=self._cur_font_family,
                                     values=FONT_FAMILIES, width=16,
                                     state="normal", font=("Segoe UI", 9))
        self._font_cb.pack(side="left", padx=2)
        self._font_cb.bind("<<ComboboxSelected>>", self._on_font_family_change)
        self._font_cb.bind("<Return>", self._on_font_family_change)

        self._size_cb = ttk.Combobox(row1, textvariable=self._cur_font_size,
                                     values=FONT_SIZES, width=4,
                                     state="normal", font=("Segoe UI", 9))
        self._size_cb.pack(side="left", padx=2)
        self._size_cb.bind("<<ComboboxSelected>>", self._on_font_size_change)
        self._size_cb.bind("<Return>", self._on_font_size_change)

        self._ribbon_btn(row1, "A⁺", self._font_grow, small=True)
        self._ribbon_btn(row1, "A⁻", self._font_shrink, small=True)

        # Row 2: Bold, Italic, Underline + color
        row2 = tk.Frame(grp_font, bg=WORD_WHITE)
        row2.pack(fill="x", pady=1)

        self._btn_bold = self._ribbon_toggle_btn(row2, "B", self._toggle_bold,
                                                 self._bold_on, bold=True)
        self._btn_italic = self._ribbon_toggle_btn(row2, "I", self._toggle_italic,
                                                   self._italic_on, italic=True)
        self._btn_underline = self._ribbon_toggle_btn(row2, "U", self._toggle_underline,
                                                      self._underline_on, underline=True)

        self._ribbon_btn(row2, "A-", self._pick_text_color, small=True, tooltip="Text Color")
        self._ribbon_btn(row2, "Hl", self._pick_highlight_color, small=True, tooltip="Highlight")

        self._group_separator(panel)

        # ── Paragraph group ──────────────────────────────────────────────
        grp_para = self._ribbon_group(panel, "Paragraph")

        # Alignment row
        row_align = tk.Frame(grp_para, bg=WORD_WHITE)
        row_align.pack(fill="x")

        self._btn_align = {}
        for sym, cmd, align in [("L|", self._align_left,    "left"),
                                 ("|C|", self._align_center, "center"),
                                 ("|R", self._align_right,   "right"),
                                 ("J=", self._align_justify, "justify")]:
            b = self._ribbon_btn(row_align, sym, cmd, small=True)
            self._btn_align[align] = b

        # List + Indent row
        row_list = tk.Frame(grp_para, bg=WORD_WHITE)
        row_list.pack(fill="x")
        self._ribbon_btn(row_list, "• List",  self._toggle_bullet,   small=True)
        self._ribbon_btn(row_list, "1. List", self._toggle_numbered, small=True)
        self._ribbon_btn(row_list, "→",  self._indent_increase, small=True, tooltip="Increase Indent")
        self._ribbon_btn(row_list, "←",  self._indent_decrease, small=True, tooltip="Decrease Indent")

        self._group_separator(panel)

        # ── Styles group ─────────────────────────────────────────────────
        grp_style = self._ribbon_group(panel, "Styles")

        self._style_cb = ttk.Combobox(grp_style, textvariable=self._cur_style,
                                      values=STYLE_NAMES, width=16,
                                      state="readonly", font=("Segoe UI", 9))
        self._style_cb.pack(side="left", padx=2, pady=2)
        self._style_cb.bind("<<ComboboxSelected>>", self._on_style_change)

        self._group_separator(panel)

        # ── Spacing group ────────────────────────────────────────────────
        grp_spacing = self._ribbon_group(panel, "Spacing")

        sp_lbl = tk.Label(grp_spacing, text="≡", bg=WORD_WHITE,
                          fg=WORD_TEXT, font=("Segoe UI", 9))
        sp_lbl.pack(side="left", padx=2)

        self._spacing_cb = ttk.Combobox(grp_spacing, textvariable=self._cur_line_spacing,
                                        values=LINE_SPACING_OPTIONS, width=5,
                                        state="readonly", font=("Segoe UI", 9))
        self._spacing_cb.pack(side="left", padx=2, pady=2)
        self._spacing_cb.bind("<<ComboboxSelected>>", self._on_line_spacing_change)

        self._group_separator(panel)

        # ── Editing group ────────────────────────────────────────────────
        grp_edit = self._ribbon_group(panel, "Editing")
        self._ribbon_btn(grp_edit, "Find", self._cmd_find)
        self._ribbon_btn(grp_edit, "Replace", self._cmd_find_replace)

    def _build_insert_tab(self):
        """Phase 3: Insert tab — table, image, page break, header/footer."""
        panel = tk.Frame(self._ribbon_content, bg=WORD_WHITE)
        self._tab_panels["Insert"] = panel

        # ── Pages group ──────────────────────────────────────────────────
        grp_pages = self._ribbon_group(panel, "Pages")
        self._ribbon_btn(grp_pages, "Page\nBreak", self._cmd_insert_page_break)
        self._group_separator(panel)

        # ── Tables group ─────────────────────────────────────────────────
        grp_table = self._ribbon_group(panel, "Tables")
        self._ribbon_btn(grp_table, "⊞ Table", self._cmd_insert_table, wide=True)
        self._group_separator(panel)

        # ── Illustrations group ───────────────────────────────────────────
        grp_illus = self._ribbon_group(panel, "Illustrations")
        self._ribbon_btn(grp_illus, "🖼 Picture", self._cmd_insert_image, wide=True)
        self._group_separator(panel)

        # ── Header & Footer group ─────────────────────────────────────────
        grp_hf = self._ribbon_group(panel, "Header & Footer")
        self._ribbon_btn(grp_hf, "Header", self._cmd_edit_header)
        self._ribbon_btn(grp_hf, "Footer", self._cmd_edit_footer)

    def _build_design_tab(self):
        """Phase 4: Design tab — themes and page color."""
        panel = tk.Frame(self._ribbon_content, bg=WORD_WHITE)
        self._tab_panels["Design"] = panel

        # ── Themes group ────────────────────────────────────────────────
        grp_themes = self._ribbon_group(panel, "Themes")
        for theme, color in [("Office", "#2b579a"), ("Elegant", "#4a4a8a"),
                              ("Warm", "#8a3a0a"), ("Nature", "#2a6a2a")]:
            btn = tk.Label(grp_themes, text=theme, bg=color, fg="white",
                           font=("Segoe UI", 8), padx=8, pady=4, cursor="hand2",
                           relief="flat")
            btn.pack(side="left", padx=2, pady=4)
            btn.bind("<Button-1>", lambda e, c=color: self._apply_theme(c))
            btn.bind("<Enter>",    lambda e, b=btn: b.config(relief="raised"))
            btn.bind("<Leave>",    lambda e, b=btn: b.config(relief="flat"))
        self._group_separator(panel)

        # ── Page Color group ────────────────────────────────────────────
        grp_color = self._ribbon_group(panel, "Page Color")
        self._ribbon_btn(grp_color, "🎨 Page Color", self._cmd_page_color, wide=True)
        self._ribbon_btn(grp_color, "No Color", self._cmd_page_color_reset)
        self._group_separator(panel)

        # ── Page Borders group ───────────────────────────────────────────
        grp_border = self._ribbon_group(panel, "Page Background")
        self._ribbon_btn(grp_border, "Page\nBorders", self._cmd_page_borders)

    def _build_layout_tab(self):
        """Phase 4: Layout tab — margins, orientation, page size, columns."""
        panel = tk.Frame(self._ribbon_content, bg=WORD_WHITE)
        self._tab_panels["Layout"] = panel

        # ── Page Setup group ────────────────────────────────────────────
        grp_setup = self._ribbon_group(panel, "Page Setup")

        # Margins
        margins_frame = tk.Frame(grp_setup, bg=WORD_WHITE)
        margins_frame.pack(side="left", padx=2)
        tk.Label(margins_frame, text="Margins", bg=WORD_WHITE,
                 fg=WORD_TEXT, font=("Segoe UI", 8)).pack()
        self._ribbon_btn(margins_frame, "Normal", self._cmd_margins_normal)
        self._ribbon_btn(margins_frame, "Narrow", self._cmd_margins_narrow)
        self._ribbon_btn(margins_frame, "Wide",   self._cmd_margins_wide)

        self._group_separator(panel)

        # Orientation
        orient_frame = tk.Frame(grp_setup, bg=WORD_WHITE)
        orient_frame.pack(side="left", padx=2)
        tk.Label(orient_frame, text="Orientation", bg=WORD_WHITE,
                 fg=WORD_TEXT, font=("Segoe UI", 8)).pack()
        self._ribbon_btn(orient_frame, "Portrait",  self._cmd_orient_portrait)
        self._ribbon_btn(orient_frame, "Landscape", self._cmd_orient_landscape)

        self._group_separator(panel)

        # Page Size
        size_frame = tk.Frame(grp_setup, bg=WORD_WHITE)
        size_frame.pack(side="left", padx=2)
        tk.Label(size_frame, text="Size", bg=WORD_WHITE,
                 fg=WORD_TEXT, font=("Segoe UI", 8)).pack()
        self._ribbon_btn(size_frame, "Letter",  lambda: self._cmd_page_size("letter"))
        self._ribbon_btn(size_frame, "A4",      lambda: self._cmd_page_size("a4"))
        self._ribbon_btn(size_frame, "Legal",   lambda: self._cmd_page_size("legal"))

        self._group_separator(panel)

        # Columns
        col_frame = tk.Frame(grp_setup, bg=WORD_WHITE)
        col_frame.pack(side="left", padx=2)
        tk.Label(col_frame, text="Columns", bg=WORD_WHITE,
                 fg=WORD_TEXT, font=("Segoe UI", 8)).pack()
        self._ribbon_btn(col_frame, "One",   lambda: self._cmd_columns(1))
        self._ribbon_btn(col_frame, "Two",   lambda: self._cmd_columns(2))
        self._ribbon_btn(col_frame, "Three", lambda: self._cmd_columns(3))

    def _build_view_tab(self):
        """Phase 4: View tab — zoom, ruler, dark mode."""
        panel = tk.Frame(self._ribbon_content, bg=WORD_WHITE)
        self._tab_panels["View"] = panel

        # ── Views group ──────────────────────────────────────────────────
        grp_views = self._ribbon_group(panel, "Views")
        self._ribbon_btn(grp_views, "Print\nLayout", self._cmd_view_print_layout, wide=True)
        self._ribbon_btn(grp_views, "Draft", self._cmd_view_draft, wide=True)
        self._group_separator(panel)

        # ── Show group ───────────────────────────────────────────────────
        grp_show = self._ribbon_group(panel, "Show")
        self._ruler_btn = self._ribbon_btn(grp_show, "✓ Ruler", self._toggle_ruler)
        self._group_separator(panel)

        # ── Zoom group ───────────────────────────────────────────────────
        grp_zoom = self._ribbon_group(panel, "Zoom")
        self._ribbon_btn(grp_zoom, "Zoom...", self._cmd_zoom_dialog, wide=True)
        self._ribbon_btn(grp_zoom, "100%",    self._cmd_zoom_100)
        self._ribbon_btn(grp_zoom, "One Page", self._cmd_zoom_fit)
        row_zoom = tk.Frame(grp_zoom, bg=WORD_WHITE)
        row_zoom.pack(side="left", padx=2)
        self._ribbon_btn(row_zoom, "−", self._zoom_out, small=True)
        self._ribbon_btn(row_zoom, "+", self._zoom_in,  small=True)
        self._group_separator(panel)

        # ── Appearance group ─────────────────────────────────────────────
        grp_appear = self._ribbon_group(panel, "Appearance")
        self._ribbon_btn(grp_appear, "🌙 Dark Mode", self._toggle_dark_mode, wide=True)

    def _build_header_footer_ui(self):
        """Phase 3: Header and footer panels (shown when doc has header/footer)."""
        # Header panel (packed before editor, initially hidden)
        self._header_panel = tk.Frame(self, bg="#fffde7", bd=1, relief="solid")
        hdr_label = tk.Label(self._header_panel, text=" Header ",
                             bg="#f9a825", fg="white",
                             font=("Segoe UI", 7, "bold"), padx=4, pady=1)
        hdr_label.pack(side="top", fill="x")
        self._header_text_widget = tk.Text(
            self._header_panel, height=2,
            bg="#fffde7", fg=WORD_TEXT,
            font=("Calibri", 11), wrap="word",
            bd=0, padx=80, pady=4, relief="flat", undo=True)
        self._header_text_widget.pack(fill="x")
        # Don't pack yet; shown only when document has a header

        # Footer panel (packed after editor, initially hidden)
        self._footer_panel = tk.Frame(self, bg="#e3f2fd", bd=1, relief="solid")
        ftr_label = tk.Label(self._footer_panel, text=" Footer ",
                             bg="#1565c0", fg="white",
                             font=("Segoe UI", 7, "bold"), padx=4, pady=1)
        ftr_label.pack(side="top", fill="x")
        self._footer_text_widget = tk.Text(
            self._footer_panel, height=2,
            bg="#e3f2fd", fg=WORD_TEXT,
            font=("Calibri", 11), wrap="word",
            bd=0, padx=80, pady=4, relief="flat", undo=True)
        self._footer_text_widget.pack(fill="x")
        # Don't pack yet

    def _ribbon_group(self, parent, label):
        """A named group box inside a ribbon tab — Word 2019 style."""
        ribbon_bg = DARK_BG if self._dark_mode else WORD_WHITE
        label_fg  = "#aaa" if self._dark_mode else "#777"

        outer = tk.Frame(parent, bg=ribbon_bg)
        outer.pack(side="left", fill="y", padx=1, pady=0)

        inner = tk.Frame(outer, bg=ribbon_bg, relief="flat")
        inner.pack(fill="both", expand=True, padx=4, pady=4)

        # Group label at bottom (like Word: "Clipboard", "Font", etc.)
        lbl = tk.Label(outer, text=label, bg=ribbon_bg,
                       fg=label_fg, font=("Segoe UI", 7))
        lbl.pack(side="bottom", pady=(0, 2))

        return inner

    def _group_separator(self, parent):
        """Thin vertical separator between ribbon groups."""
        sep_color = "#555" if self._dark_mode else "#d0d0d0"
        sep = tk.Frame(parent, bg=sep_color, width=1)
        sep.pack(side="left", fill="y", padx=3, pady=6)

    def _ribbon_btn(self, parent, text, command, wide=False, small=False, tooltip=None):
        """Standard ribbon button — Word 2019 style with hover effect."""
        ribbon_bg  = DARK_BG if self._dark_mode else WORD_WHITE
        ribbon_fg  = DARK_TEXT if self._dark_mode else WORD_TEXT
        hover_bg   = "#3a6bbf" if self._dark_mode else "#e8f0fb"
        hover_fg   = WORD_WHITE if self._dark_mode else WORD_BLUE

        padx = 6 if wide else (2 if small else 4)
        pady = 4 if wide else (1 if small else 3)
        fsize = 8 if small else 9

        btn = tk.Label(parent, text=text, bg=ribbon_bg, fg=ribbon_fg,
                       font=("Segoe UI", fsize), padx=padx, pady=pady,
                       cursor="hand2", relief="flat", borderwidth=1)
        btn.pack(side="left", padx=1, pady=1)
        btn.bind("<Button-1>", lambda e: command())
        btn.bind("<Enter>",    lambda e: btn.config(bg=hover_bg, fg=hover_fg,
                                                     relief="solid"))
        btn.bind("<Leave>",    lambda e: btn.config(bg=ribbon_bg, fg=ribbon_fg,
                                                     relief="flat"))
        if tooltip:
            self._add_tooltip(btn, tooltip)
        return btn

    def _ribbon_toggle_btn(self, parent, text, command, var, bold=False,
                           italic=False, underline=False):
        """Toggle-style ribbon button (pressed/depressed state)."""
        font_opts = ("Segoe UI", 10)
        if bold:      font_opts = ("Segoe UI", 10, "bold")
        if italic:    font_opts = ("Segoe UI", 10, "italic")
        if underline: font_opts = ("Segoe UI", 10, "underline")

        ribbon_bg = DARK_BG if self._dark_mode else WORD_WHITE
        ribbon_fg = DARK_TEXT if self._dark_mode else WORD_TEXT

        btn = tk.Label(parent, text=text, bg=ribbon_bg, fg=ribbon_fg,
                       font=font_opts, padx=6, pady=3,
                       cursor="hand2", relief="flat", borderwidth=1)
        btn.pack(side="left", padx=1, pady=1)

        def _click(e):
            command()
            _refresh()

        def _refresh(*_):
            if var.get():
                btn.config(bg=WORD_BLUE_LITE, relief="solid",
                           borderwidth=1, fg=WORD_BLUE)
            else:
                btn.config(bg=ribbon_bg, relief="flat",
                           borderwidth=1, fg=ribbon_fg)

        btn.bind("<Button-1>", _click)
        btn.bind("<Enter>",    lambda e: btn.config(bg="#e8f0fb", relief="solid"))
        btn.bind("<Leave>",    _refresh)
        var.trace_add("write", _refresh)
        return btn

    def _add_tooltip(self, widget, text):
        def enter(e):
            x = widget.winfo_rootx() + 25
            y = widget.winfo_rooty() + 20
            self._tooltip = tk.Toplevel(widget)
            self._tooltip.wm_overrideredirect(True)
            self._tooltip.wm_geometry(f"+{x}+{y}")
            lbl = tk.Label(self._tooltip, text=text, justify="left",
                           bg="#ffffc0", relief="solid", borderwidth=1,
                           font=("Segoe UI", 8))
            lbl.pack()

        def leave(e):
            if hasattr(self, "_tooltip"):
                self._tooltip.destroy()

        widget.bind("<Enter>", enter)
        widget.bind("<Leave>", leave)

    def _build_ruler(self):
        """Simple horizontal ruler below the ribbon."""
        self._ruler_frame = tk.Frame(self, bg="#e8e8e8", height=18)
        self._ruler_frame.pack(fill="x", side="top")
        self._ruler_frame.pack_propagate(False)
        ruler_frame = self._ruler_frame

        ruler_canvas = tk.Canvas(ruler_frame, bg="#e8e8e8", height=18,
                                 highlightthickness=0)
        ruler_canvas.pack(fill="x")

        def draw_ruler(e=None):
            ruler_canvas.delete("all")
            w = ruler_canvas.winfo_width()
            for i in range(0, w, 96):
                ruler_canvas.create_line(i, 12, i, 18, fill="#999")
                if i > 0:
                    ruler_canvas.create_text(i, 6, text=str(i//96),
                                             font=("Segoe UI", 6), fill="#777")
            for i in range(48, w, 96):
                ruler_canvas.create_line(i, 15, i, 18, fill="#bbb")

        ruler_canvas.bind("<Configure>", draw_ruler)
        self.after(100, draw_ruler)

    def _build_editor(self):
        """Main editing area — scrollable Text widget."""
        editor_frame = tk.Frame(self, bg="#808080")
        editor_frame.pack(fill="both", expand=True, padx=0, pady=0)
        self._editor_outer_frame = editor_frame  # Phase 3: reference for header/footer

        page_outer = tk.Frame(editor_frame, bg="#808080")
        page_outer.pack(fill="both", expand=True, padx=0, pady=0)

        v_scroll = tk.Scrollbar(page_outer, orient="vertical",
                                bg="#c0c0c0", troughcolor="#e0e0e0")
        v_scroll.pack(side="right", fill="y")

        h_scroll = tk.Scrollbar(page_outer, orient="horizontal",
                                bg="#c0c0c0", troughcolor="#e0e0e0")
        h_scroll.pack(side="bottom", fill="x")

        self.editor = tk.Text(
            page_outer,
            bg=WORD_WHITE,
            fg=WORD_TEXT,
            font=("Calibri", 12),
            wrap="word",
            undo=True,
            maxundo=200,
            padx=80,
            pady=60,
            spacing1=2,
            spacing2=1,
            spacing3=4,
            relief="flat",
            borderwidth=0,
            selectbackground=WORD_ACCENT,
            insertbackground=WORD_BLUE,
            insertwidth=2,
            highlightthickness=0,
            yscrollcommand=v_scroll.set,
            xscrollcommand=h_scroll.set,
            exportselection=True,
        )
        self.editor.pack(fill="both", expand=True, padx=40, pady=20)
        v_scroll.config(command=self.editor.yview)
        h_scroll.config(command=self.editor.xview)

        # Track changes
        self.editor.bind("<<Modified>>", self._on_text_modified)
        self.editor.bind("<KeyRelease>", self._on_cursor_move)
        self.editor.bind("<ButtonRelease-1>", self._on_cursor_move)

        # Phase 2: intercept Tab/Shift+Tab for indent/outdent
        self.editor.bind("<Tab>", self._on_tab)
        self.editor.bind("<Shift-Tab>", self._on_shift_tab)

        # Phase 2: intercept Ctrl+X/C/V for formatted clipboard
        self.editor.bind("<Control-x>", lambda e: self._cmd_cut())
        self.editor.bind("<Control-c>", lambda e: self._cmd_copy())
        self.editor.bind("<Control-v>", lambda e: self._cmd_paste())

    def _build_statusbar(self):
        """Status bar at the bottom — Word-style with zoom slider."""
        sb = tk.Frame(self, bg=WORD_BLUE, height=24, relief="flat")
        sb.pack(fill="x", side="bottom")
        sb.pack_propagate(False)

        self._statusbar_frame = sb

        self._status_file = tk.Label(sb, text="Ready", bg=WORD_BLUE,
                                     fg=WORD_WHITE, font=("Segoe UI", 8),
                                     padx=8)
        self._status_file.pack(side="left")

        self._status_words = tk.Label(sb, text="Words: 0", bg=WORD_BLUE,
                                      fg=WORD_WHITE, font=("Segoe UI", 8),
                                      padx=8)
        self._status_words.pack(side="left", padx=(4, 0))

        # Right side: zoom controls
        self._status_zoom = tk.Label(sb, text="100%", bg=WORD_BLUE,
                                     fg=WORD_WHITE, font=("Segoe UI", 8),
                                     padx=4, cursor="hand2")
        self._status_zoom.pack(side="right")
        self._status_zoom.bind("<Button-1>", lambda e: self._cmd_zoom_dialog())

        # Zoom slider
        self._zoom_var = tk.IntVar(value=100)
        self._zoom_slider = tk.Scale(
            sb, from_=50, to=200, orient="horizontal",
            variable=self._zoom_var, length=100,
            bg=WORD_BLUE, fg=WORD_WHITE, troughcolor=WORD_BLUE_DARK,
            highlightthickness=0, bd=0, showvalue=False,
            command=self._on_zoom_slider)
        self._zoom_slider.pack(side="right", padx=4, pady=2)

        # Zoom + / - buttons
        tk.Label(sb, text="+", bg=WORD_BLUE, fg=WORD_WHITE,
                 font=("Segoe UI", 10, "bold"), padx=2, cursor="hand2"
                 ).pack(side="right")
        tk.Label(sb, text="−", bg=WORD_BLUE, fg=WORD_WHITE,
                 font=("Segoe UI", 10, "bold"), padx=2, cursor="hand2"
                 ).pack(side="right")

        sep = tk.Frame(sb, bg=WORD_BLUE_DARK, width=1)
        sep.pack(side="right", fill="y", pady=3)

        self._status_pos = tk.Label(sb, text="Ln 1, Col 1", bg=WORD_BLUE,
                                    fg=WORD_WHITE, font=("Segoe UI", 8),
                                    padx=8)
        self._status_pos.pack(side="right")

    # ─── Keyboard shortcuts ───────────────────────────────────────────────────

    def _bind_shortcuts(self):
        # File operations
        self.bind("<Control-n>", lambda e: (self._cmd_new(), "break"))
        self.bind("<Control-N>", lambda e: (self._cmd_new(), "break"))
        self.bind("<Control-o>", lambda e: (self._cmd_open(), "break"))
        self.bind("<Control-O>", lambda e: (self._cmd_open(), "break"))
        self.bind("<Control-s>", lambda e: (self._cmd_save(), "break"))
        self.bind("<Control-S>", lambda e: (self._cmd_save(), "break"))
        self.bind("<Control-p>", lambda e: (self._cmd_print(), "break"))
        self.bind("<Control-P>", lambda e: (self._cmd_print(), "break"))

        # Edit operations
        self.bind("<Control-z>", lambda e: (self._cmd_undo(), "break"))
        self.bind("<Control-Z>", lambda e: (self._cmd_undo(), "break"))
        self.bind("<Control-y>", lambda e: (self._cmd_redo(), "break"))
        self.bind("<Control-Y>", lambda e: (self._cmd_redo(), "break"))

        # Formatting shortcuts
        self.bind("<Control-b>", lambda e: (self._toggle_bold(), "break"))
        self.bind("<Control-B>", lambda e: (self._toggle_bold(), "break"))
        self.bind("<Control-i>", lambda e: (self._toggle_italic(), "break"))
        self.bind("<Control-I>", lambda e: (self._toggle_italic(), "break"))
        self.bind("<Control-u>", lambda e: (self._toggle_underline(), "break"))
        self.bind("<Control-U>", lambda e: (self._toggle_underline(), "break"))

        # Alignment shortcuts (Ctrl+L/E/R/J)
        self.bind("<Control-l>", lambda e: (self._align_left(), "break"))
        self.bind("<Control-L>", lambda e: (self._align_left(), "break"))
        self.bind("<Control-e>", lambda e: (self._align_center(), "break"))
        self.bind("<Control-E>", lambda e: (self._align_center(), "break"))
        self.bind("<Control-r>", lambda e: (self._align_right(), "break"))
        self.bind("<Control-R>", lambda e: (self._align_right(), "break"))
        self.bind("<Control-j>", lambda e: (self._align_justify(), "break"))
        self.bind("<Control-J>", lambda e: (self._align_justify(), "break"))

        # Find / Replace
        self.bind("<Control-h>", lambda e: (self._cmd_find_replace(), "break"))
        self.bind("<Control-H>", lambda e: (self._cmd_find_replace(), "break"))
        self.bind("<Control-f>", lambda e: (self._cmd_find(), "break"))
        self.bind("<Control-F>", lambda e: (self._cmd_find(), "break"))

        # Paste plain text
        self.bind("<Control-Shift-v>", lambda e: (self._paste_plain(), "break"))
        self.bind("<Control-Shift-V>", lambda e: (self._paste_plain(), "break"))

        # Zoom
        self.bind("<Control-equal>",  lambda e: (self._zoom_in(), "break"))
        self.bind("<Control-plus>",   lambda e: (self._zoom_in(), "break"))
        self.bind("<Control-minus>",  lambda e: (self._zoom_out(), "break"))

        # Mouse wheel zoom (Ctrl+scroll)
        self.bind("<Control-MouseWheel>", self._on_ctrl_scroll)

        # Page break
        self.bind("<Control-Return>", lambda e: (self._cmd_insert_page_break(), "break"))

        # Help
        self.bind("<F1>", lambda e: (self._cmd_help(), "break"))

    # ─── Document Management ──────────────────────────────────────────────────

    def _new_document(self):
        """Create a blank document."""
        if self.is_modified:
            if not self._ask_save():
                return
        self._doc_counter += 1
        self.doc = Document()
        self.current_file = None
        self._doc_name = f"Document{self._doc_counter}"
        self._load_doc_to_editor()
        self.is_modified = False
        self._update_title()
        self._update_status("New document")

    def _load_docx(self, path):
        """Open a .docx file."""
        try:
            self.doc = Document(path)
            self.current_file = path
            self._doc_name = os.path.basename(path)
            self._load_doc_to_editor()
            self.is_modified = False
            self._update_title()
            self._update_status(f"Opened: {os.path.basename(path)}")
            self._add_to_recent(path)
        except Exception as ex:
            messagebox.showerror("Open Error",
                f"Could not open file:\n{path}\n\n{ex}")

    def _load_doc_to_editor(self):
        """Render the python-docx Document into the Text widget.
        Phase 3: iterates body children in order (paragraphs AND tables).
        """
        self._ignore_changes = True
        self.editor.config(state="normal")
        self.editor.delete("1.0", "end")
        self._para_map.clear()
        self._para_metadata.clear()
        self._clear_formatting_tags()
        self._embedded_tables.clear()
        self._image_refs.clear()
        self._doc_body_items.clear()

        if self.doc is None:
            self._ignore_changes = False
            return

        # ── Phase 3: iterate body children in document order ──────────────
        # Build lookup maps from element id → python-docx proxy
        top_para_map  = {}
        top_table_map = {}
        try:
            for para in self.doc.paragraphs:
                top_para_map[id(para._element)] = para
        except Exception:
            pass
        try:
            for tbl in self.doc.tables:
                top_table_map[id(tbl._element)] = tbl
        except Exception:
            pass

        body_el = self.doc.element.body
        item_idx = 0
        para_count = 0

        for child_el in body_el:
            tag = child_el.tag
            if tag == qn('w:p'):
                para = top_para_map.get(id(child_el))
                if para is None:
                    try:
                        para = WDParagraph(child_el, body_el)
                    except Exception:
                        continue
                # Check for page break paragraph
                is_pb = self._is_page_break(para)
                if is_pb:
                    self._render_page_break_visual()
                    self._doc_body_items.append({'type': 'pagebreak', 'obj': para})
                else:
                    self._render_paragraph(para, para_count, len(top_para_map))
                    self._doc_body_items.append({'type': 'paragraph', 'obj': para})
                    para_count += 1
                item_idx += 1

            elif tag == qn('w:tbl'):
                table = top_table_map.get(id(child_el))
                if table is None:
                    try:
                        table = WDTable(child_el, self.doc)
                    except Exception:
                        continue
                self._render_table(table)
                self._doc_body_items.append({'type': 'table', 'obj': table})

            elif tag == qn('w:sectPr'):
                pass  # section properties — skip

        self.editor.mark_set("insert", "1.0")
        self.editor.see("1.0")
        self._ignore_changes = False
        self.editor.edit_reset()
        self._update_word_count()

        # Phase 3: load header/footer content
        self.after(100, self._load_header_footer)

    def _clear_formatting_tags(self):
        """Remove all dynamic formatting tags from the Text widget."""
        for tag in self.editor.tag_names():
            if tag not in ("sel", "insert"):
                try:
                    self.editor.tag_delete(tag)
                except Exception:
                    pass

    def _render_paragraph(self, para, idx, total):
        """Render one paragraph into the Text widget and populate _para_metadata.
        Phase 3: detects list type from XML, handles images in runs.
        """
        style_name = para.style.name if para.style else "Normal"
        is_heading  = style_name.startswith("Heading")
        heading_lvl = None
        if is_heading:
            try:
                heading_lvl = int(style_name.split()[-1])
            except ValueError:
                pass

        line_start = self.editor.index("end-1c")
        line_num   = int(line_start.split(".")[0])

        # ── Phase 3: detect list type from XML ────────────────────────────
        list_type, list_level = self._detect_list_type(para)

        # Render list prefix for items detected from the document
        line_has_content = False
        if list_type == 'bullet':
            bullets = ['•', '◦', '▪', '▫']
            bullet  = bullets[list_level % len(bullets)]
            prefix  = '    ' * list_level + bullet + ' '
            self.editor.insert("end", prefix)
            line_has_content = True
        elif list_type == 'numbered':
            num    = self._get_list_number(para)
            prefix = '    ' * list_level + f"{num}. "
            self.editor.insert("end", prefix)
            line_has_content = True

        # Render runs (text + images)
        for run in para.runs:
            # Check for embedded images (drawings) in the run
            if (run._element.find(qn('w:drawing')) is not None or
                    run._element.find(qn('w:pict')) is not None):
                self._render_image_in_run(run, para)
                line_has_content = True
                continue
            if not run.text:
                continue
            line_has_content = True
            self._render_run(run, para, heading_lvl)

        if not line_has_content:
            self.editor.insert("end", "")

        line_end = self.editor.index("end-1c")

        # Apply paragraph-level tag (alignment, indent, spacing)
        self._apply_para_tag(para, line_start, line_end, heading_lvl, idx)

        # Insert newline after paragraph
        self.editor.insert("end", "\n")

        # Store para reference
        self._para_map[line_num] = para

        # ── Phase 2 / 3: populate _para_metadata ──────────────────────
        align = ALIGN_MAP.get(para.alignment, "left")

        # Line spacing
        spacing = 1.0
        try:
            pf = para.paragraph_format
            if pf.line_spacing is not None:
                if pf.line_spacing_rule == WD_LINE_SPACING.MULTIPLE:
                    spacing = float(pf.line_spacing)
                elif pf.line_spacing_rule == WD_LINE_SPACING.SINGLE:
                    spacing = 1.0
                elif pf.line_spacing_rule == WD_LINE_SPACING.DOUBLE:
                    spacing = 2.0
                elif pf.line_spacing_rule == WD_LINE_SPACING.ONE_POINT_FIVE:
                    spacing = 1.5
                else:
                    spacing = round(float(pf.line_spacing) / 240, 2)
        except Exception:
            spacing = 1.0

        # Indent level (prefer explicit list level, then format-based)
        indent_level = list_level if list_type else 0
        if not list_type:
            try:
                pf = para.paragraph_format
                if pf.left_indent:
                    indent_level = max(0, int(round(pf.left_indent.inches / 0.5)))
            except Exception:
                pass

        self._para_metadata[line_num] = {
            "style":        style_name,
            "alignment":    align,
            "line_spacing": spacing,
            "indent_level": indent_level,
            "list_type":    list_type,
        }

    def _render_run(self, run, para, heading_lvl):
        """Insert a run's text with appropriate formatting tags."""
        text = run.text
        if not text:
            return

        style_name = para.style.name if para.style else "Normal"

        # Font family
        font_family = "Calibri"
        if run.font.name:
            font_family = run.font.name
        elif para.style and para.style.font and para.style.font.name:
            font_family = para.style.font.name

        # Font size
        font_size = 12
        if run.font.size:
            font_size = safe_font_size(run.font.size)
        elif para.style and para.style.font and para.style.font.size:
            font_size = safe_font_size(para.style.font.size)
        elif heading_lvl and heading_lvl in HEADING_SIZES:
            font_size = HEADING_SIZES[heading_lvl]

        # Bold
        bold = bool(run.bold)
        if run.bold is None and heading_lvl in (1, 2, 3, 4):
            bold = True

        # Italic
        italic = bool(run.italic)

        # Underline
        underline = bool(run.underline)

        # Color
        color = None
        if run.font.color and run.font.color.type is not None:
            color = rgb_to_hex(run.font.color.rgb)
        if color is None and heading_lvl and heading_lvl in HEADING_COLORS:
            color = HEADING_COLORS[heading_lvl]

        weight = "bold"   if bold   else "normal"
        slant  = "italic" if italic else "roman"
        tk_font = tkfont.Font(family=font_family, size=font_size,
                              weight=weight, slant=slant,
                              underline=1 if underline else 0)

        tag = self._new_tag()
        cfg = {"font": tk_font}
        if color:
            cfg["foreground"] = color

        self.editor.tag_configure(tag, **cfg)
        self.editor.insert("end", text, tag)

    def _apply_para_tag(self, para, start, end, heading_lvl, idx):
        """Apply paragraph-level tags (alignment, spacing, indent)."""
        align = ALIGN_MAP.get(para.alignment, "left")
        # Normalize: tkinter only supports left/center/right
        tk_align = align if align in ("left", "center", "right") else "left"

        tag = self._new_tag()
        cfg = {"justify": tk_align}

        if heading_lvl:
            cfg["spacing1"] = HEADING_SIZES.get(heading_lvl, 12) // 2
            cfg["spacing3"] = 4

        try:
            if para.paragraph_format.left_indent:
                left_px = int(para.paragraph_format.left_indent.pt * 96 / 72)
                cfg["lmargin1"] = left_px + 80
                cfg["lmargin2"] = left_px + 80
        except Exception:
            pass

        self.editor.tag_configure(tag, **cfg)
        try:
            self.editor.tag_add(tag, start, end)
        except Exception:
            pass

    def _new_tag(self):
        self._tag_counter += 1
        return f"run_{self._tag_counter}"

    # ─── Save Logic ───────────────────────────────────────────────────────────

    def _sync_editor_to_doc(self):
        """
        Phase 3 sync: Rebuild paragraphs from editor, preserve tables in place.

        Strategy:
        - If document has embedded tables: update paragraphs by position in
          _doc_body_items; update table cells from widgets; skip table lines.
        - If no tables: simple full rebuild (Phase 2 logic).
        - Always sync header/footer text.
        """
        if self.doc is None:
            return

        # Sync table cells first
        for tinfo in self._embedded_tables:
            self._sync_table_cells(tinfo)

        # Sync header/footer
        self._sync_header_footer_to_doc()

        editor_text = self.editor.get("1.0", "end-1c")
        lines = editor_text.split("\n")

        if self._doc_body_items:
            # ── Structured sync: document has mixed paragraphs + tables ──
            # Find which editor lines contain embedded windows (tables/images)
            embedded_line_nums = set()
            try:
                for item_type, index, _val in self.editor.dump(
                        "1.0", "end", window=True):
                    if item_type == 'window':
                        embedded_line_nums.add(int(index.split(".")[0]))
            except Exception:
                pass

            # Build list of (lnum, text) for non-embedded lines
            text_lines = []
            for i, line in enumerate(lines):
                lnum = i + 1
                if lnum not in embedded_line_nums:
                    text_lines.append((lnum, line))

            # Get paragraph items from body structure
            para_items = [item for item in self._doc_body_items
                          if item['type'] == 'paragraph']

            # Sync each paragraph
            for i, (lnum, line_text) in enumerate(text_lines):
                if i >= len(para_items):
                    break
                self._sync_one_paragraph(para_items[i]['obj'], lnum, line_text)

        else:
            # ── Simple rebuild (no tables — Phase 2 logic) ────────────────
            while len(self.doc.paragraphs) > len(lines):
                p = self.doc.paragraphs[-1]._element
                p.getparent().remove(p)
            while len(self.doc.paragraphs) < len(lines):
                self.doc.add_paragraph()

            for i, line_text in enumerate(lines):
                lnum = i + 1
                self._sync_one_paragraph(self.doc.paragraphs[i], lnum, line_text)

    def _sync_one_paragraph(self, para, lnum, line_text):
        """Sync a single paragraph's text + formatting from editor line `lnum`."""
        # Clear existing runs
        for run in list(para.runs):
            run._element.getparent().remove(run._element)

        # Apply paragraph-level metadata
        meta          = self._para_metadata.get(lnum, {})
        style_name    = meta.get("style", "Normal")
        alignment     = meta.get("alignment", "left")
        line_spacing  = meta.get("line_spacing", 1.0)
        indent_level  = meta.get("indent_level", 0)

        try:
            para.style = self.doc.styles[style_name]
        except Exception:
            try:
                para.style = self.doc.styles["Normal"]
            except Exception:
                pass

        para.alignment = ALIGN_TO_WD.get(alignment, WD_ALIGN_PARAGRAPH.LEFT)

        try:
            pf = para.paragraph_format
            if line_spacing == 1.0:
                pf.line_spacing_rule = WD_LINE_SPACING.SINGLE
                pf.line_spacing = None
            elif line_spacing == 1.5:
                pf.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
                pf.line_spacing = None
            elif line_spacing == 2.0:
                pf.line_spacing_rule = WD_LINE_SPACING.DOUBLE
                pf.line_spacing = None
            else:
                pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
                pf.line_spacing = line_spacing
        except Exception:
            pass

        try:
            pf = para.paragraph_format
            if indent_level > 0:
                pf.left_indent = Inches(0.5 * indent_level)
            else:
                pf.left_indent = None
        except Exception:
            pass

        if not line_text:
            return

        segments = self._get_char_segments(lnum, line_text)
        for seg_text, seg_fmt in segments:
            if not seg_text:
                continue
            run = para.add_run(seg_text)
            if seg_fmt:
                fam = seg_fmt.get("family")
                if fam and fam not in ("", "TkDefaultFont"):
                    run.font.name = fam
                sz = seg_fmt.get("size")
                if sz and sz > 0:
                    run.font.size = Pt(abs(sz))
                run.bold      = seg_fmt.get("weight", "normal") == "bold"
                run.italic    = seg_fmt.get("slant", "roman") == "italic"
                run.underline = bool(seg_fmt.get("underline", 0))
                fg = seg_fmt.get("foreground")
                if fg and fg.startswith("#") and len(fg) == 7:
                    try:
                        r, g, b = hex_to_rgb(fg)
                        run.font.color.rgb = RGBColor(r, g, b)
                    except Exception:
                        pass

    def _get_char_segments(self, line_num, line_text):
        """
        Walk character by character and group consecutive chars
        with the same formatting into segments.
        Returns: list of (text, fmt_dict)
        """
        if not line_text:
            return []

        segments = []
        prev_fmt = None
        current_text = ""

        for col in range(len(line_text)):
            pos = f"{line_num}.{col}"
            fmt = self._get_format_at_pos(pos)
            fmt_key = self._fmt_to_key(fmt)

            if prev_fmt is None:
                prev_fmt = fmt
                prev_key = fmt_key
                current_text = line_text[col]
            elif fmt_key == prev_key:
                current_text += line_text[col]
            else:
                segments.append((current_text, prev_fmt))
                prev_fmt = fmt
                prev_key = fmt_key
                current_text = line_text[col]

        if current_text:
            segments.append((current_text, prev_fmt))

        return segments

    def _fmt_to_key(self, fmt):
        """Convert a format dict to a hashable key for comparison."""
        if not fmt:
            return None
        return (
            fmt.get("family", ""),
            fmt.get("size", 12),
            fmt.get("weight", "normal"),
            fmt.get("slant", "roman"),
            fmt.get("underline", 0),
            fmt.get("foreground", ""),
        )

    def _get_format_at_pos(self, index):
        """
        Return a dict of font properties at the given text index.
        Iterates through all tags at that position in priority order
        (tag_names returns them lowest-priority first; last wins).
        """
        result = {}
        try:
            tags = self.editor.tag_names(index)
            for tag in tags:
                if not tag.startswith("run_"):
                    continue
                # Font properties
                font_str = self.editor.tag_cget(tag, "font")
                if font_str:
                    try:
                        f = tkfont.Font(font=font_str)
                        info = f.actual()
                        fam = info.get("family", "")
                        if fam and fam not in ("TkDefaultFont",):
                            result["family"] = fam
                        sz = info.get("size", 0)
                        if sz:
                            result["size"] = abs(sz)
                        result["weight"]    = info.get("weight", "normal")
                        result["slant"]     = info.get("slant", "roman")
                        result["underline"] = info.get("underline", 0)
                    except Exception:
                        pass
                # Foreground color
                fg = self.editor.tag_cget(tag, "foreground")
                if fg and fg.startswith("#"):
                    result["foreground"] = fg
        except Exception:
            pass
        return result if result else None

    # ─── Commands ─────────────────────────────────────────────────────────────

    def _cmd_new(self):
        if self.is_modified:
            if not self._ask_save():
                return
        self._new_document()

    def _cmd_open(self):
        if self.is_modified:
            if not self._ask_save():
                return
        path = filedialog.askopenfilename(
            title="Open Document",
            filetypes=[("Word Documents", "*.docx"), ("All Files", "*.*")]
        )
        if path:
            self._load_docx(path)

    def _cmd_save(self):
        if self.current_file:
            self._save_to(self.current_file)
        else:
            self._cmd_save_as()

    def _cmd_save_as(self):
        default_name = os.path.basename(self.current_file) if self.current_file else \
                       (self._doc_name if hasattr(self, "_doc_name") else "Document.docx")
        if not default_name.endswith(".docx"):
            default_name += ".docx"
        path = filedialog.asksaveasfilename(
            title="Save Document As",
            defaultextension=".docx",
            filetypes=[("Word Documents", "*.docx"), ("All Files", "*.*")],
            initialfile=default_name
        )
        if path:
            self._save_to(path)

    def _save_to(self, path):
        try:
            self._sync_editor_to_doc()
            self.doc.save(path)
            self.current_file = path
            self._doc_name    = os.path.basename(path)
            self.is_modified  = False
            self._update_title()
            self._update_status(f"Saved: {os.path.basename(path)}")
            self._add_to_recent(path)
        except Exception as ex:
            messagebox.showerror("Save Error",
                f"Could not save file:\n{path}\n\n{ex}")

    def _cmd_exit(self):
        if self.is_modified:
            if not self._ask_save():
                return
        self.destroy()

    def _cmd_undo(self):
        try:
            self.editor.edit_undo()
        except tk.TclError:
            pass

    def _cmd_redo(self):
        try:
            self.editor.edit_redo()
        except tk.TclError:
            pass

    def _cmd_cut(self):
        """Cut with formatting awareness."""
        try:
            start, end = self._get_selection_range()
            if start == end:
                return
            # Save formatted copy
            self._fmt_clipboard = self._get_selected_segments()
            # Also put plain text in system clipboard
            self.editor.event_generate("<<Cut>>")
        except Exception:
            try:
                self.editor.event_generate("<<Cut>>")
            except Exception:
                pass

    def _cmd_copy(self):
        """Copy with formatting awareness."""
        try:
            start, end = self._get_selection_range()
            if start == end:
                return
            self._fmt_clipboard = self._get_selected_segments()
            self.editor.event_generate("<<Copy>>")
        except Exception:
            try:
                self.editor.event_generate("<<Copy>>")
            except Exception:
                pass

    def _cmd_paste(self):
        """Paste, restoring formatting if we have a formatted clipboard."""
        try:
            if self._fmt_clipboard:
                # Delete selection if any
                try:
                    self.editor.delete("sel.first", "sel.last")
                except tk.TclError:
                    pass
                # Insert with formatting
                for seg_text, seg_fmt in self._fmt_clipboard:
                    if not seg_text:
                        continue
                    tag = self._new_tag()
                    cfg = {}
                    if seg_fmt:
                        try:
                            f = tkfont.Font(
                                family=seg_fmt.get("family", "Calibri"),
                                size=seg_fmt.get("size", 12),
                                weight=seg_fmt.get("weight", "normal"),
                                slant=seg_fmt.get("slant", "roman"),
                                underline=seg_fmt.get("underline", 0)
                            )
                            cfg["font"] = f
                        except Exception:
                            pass
                        fg = seg_fmt.get("foreground")
                        if fg:
                            cfg["foreground"] = fg
                    if cfg:
                        self.editor.tag_configure(tag, **cfg)
                        self.editor.insert("insert", seg_text, tag)
                    else:
                        self.editor.insert("insert", seg_text)
                self._mark_modified()
            else:
                self.editor.event_generate("<<Paste>>")
        except Exception:
            try:
                self.editor.event_generate("<<Paste>>")
            except Exception:
                pass

    def _get_selected_segments(self):
        """Return list of (text, fmt_dict) for the current selection."""
        try:
            start = self.editor.index("sel.first")
            end   = self.editor.index("sel.last")
        except tk.TclError:
            return []

        sel_text = self.editor.get(start, end)
        if not sel_text:
            return []

        segments = []
        prev_fmt = None
        prev_key = None
        current_text = ""

        start_line, start_col = map(int, start.split("."))
        end_line,   end_col   = map(int, end.split("."))

        # Walk character by character across the selection
        char_idx = 0
        for lnum in range(start_line, end_line + 1):
            sc = start_col if lnum == start_line else 0
            line_content = self.editor.get(f"{lnum}.0", f"{lnum}.end")
            ec = end_col if lnum == end_line else len(line_content)

            for col in range(sc, ec):
                pos = f"{lnum}.{col}"
                fmt = self._get_format_at_pos(pos)
                key = self._fmt_to_key(fmt)
                ch  = sel_text[char_idx] if char_idx < len(sel_text) else ""
                char_idx += 1

                if prev_fmt is None:
                    prev_fmt = fmt
                    prev_key = key
                    current_text = ch
                elif key == prev_key:
                    current_text += ch
                else:
                    if current_text:
                        segments.append((current_text, prev_fmt))
                    prev_fmt = fmt
                    prev_key = key
                    current_text = ch

            # Newline between lines (if within selection)
            if lnum < end_line:
                nl = "\n"
                if current_text:
                    segments.append((current_text, prev_fmt))
                    current_text = ""
                segments.append((nl, None))
                char_idx += 1  # account for \n

        if current_text:
            segments.append((current_text, prev_fmt))

        return segments

    def _ask_save(self):
        """Ask user to save. Returns True if should proceed, False to cancel."""
        name = os.path.basename(self.current_file) if self.current_file else "Untitled"
        ans = messagebox.askyesnocancel(
            "Save Changes",
            f"Do you want to save changes to '{name}'?"
        )
        if ans is True:
            self._cmd_save()
            return True
        elif ans is False:
            return True
        else:
            return False

    # ─── Selection Helpers ────────────────────────────────────────────────────

    def _get_selection_range(self):
        """Return (start, end) of current selection, or (insert, insert) if none."""
        try:
            start = self.editor.index("sel.first")
            end   = self.editor.index("sel.last")
        except tk.TclError:
            start = end = self.editor.index("insert")
        return start, end

    def _has_selection(self):
        try:
            self.editor.index("sel.first")
            return True
        except tk.TclError:
            return False

    # ─── Formatting: Apply to Selection ──────────────────────────────────────

    def _apply_format_to_selection(self, **kwargs):
        """
        Apply formatting to the current selection.
        Merges with existing formatting at the selection start.
        Phase 2: If no selection, sets the insertion-point format for new typing.
        """
        start, end = self._get_selection_range()
        if start == end:
            # No selection — just update the toolbar state for next typed char
            return

        # Walk segments in selection and apply per-character
        # (This ensures proper layering of multiple format tags)
        tag = self._new_tag()
        cfg = {}

        # Merge with format at selection start
        existing = self._get_format_at_pos(start) or {}
        merged = dict(existing)
        merged.update(kwargs)

        if any(k in kwargs for k in ("family", "size", "weight", "slant", "underline")):
            try:
                f = tkfont.Font(
                    family=merged.get("family", "Calibri"),
                    size=merged.get("size", 12),
                    weight=merged.get("weight", "normal"),
                    slant=merged.get("slant", "roman"),
                    underline=merged.get("underline", 0)
                )
                cfg["font"] = f
            except Exception:
                pass

        if "foreground" in kwargs:
            cfg["foreground"] = kwargs["foreground"]

        if "background" in kwargs:
            cfg["background"] = kwargs["background"]

        if cfg:
            self.editor.tag_configure(tag, **cfg)
            self.editor.tag_add(tag, start, end)
            self._mark_modified()

    def _get_font_at(self, index):
        """Return dict of font properties at the given index (for toolbar sync)."""
        result = {"family": "Calibri", "size": 12,
                  "weight": "normal", "slant": "roman", "underline": 0}
        try:
            # tag_names returns tags in priority order; iterate in reverse for highest-priority
            for tag in reversed(self.editor.tag_names(index)):
                if tag.startswith("run_"):
                    font_str = self.editor.tag_cget(tag, "font")
                    if font_str:
                        f = tkfont.Font(font=font_str)
                        info = f.actual()
                        result["family"]    = info.get("family", result["family"])
                        result["size"]      = abs(info.get("size", result["size"]))
                        result["weight"]    = info.get("weight", result["weight"])
                        result["slant"]     = info.get("slant",  result["slant"])
                        result["underline"] = info.get("underline", result["underline"])
                        break
        except Exception:
            pass
        return result

    def _selection_all_bold(self):
        """Returns True if every character in selection is bold."""
        try:
            start = self.editor.index("sel.first")
            end   = self.editor.index("sel.last")
        except tk.TclError:
            idx = self.editor.index("insert")
            fmt = self._get_font_at(idx)
            return fmt.get("weight", "normal") == "bold"

        start_line, start_col = map(int, start.split("."))
        end_line,   end_col   = map(int, end.split("."))

        for lnum in range(start_line, end_line + 1):
            sc = start_col if lnum == start_line else 0
            line_content = self.editor.get(f"{lnum}.0", f"{lnum}.end")
            ec = end_col if lnum == end_line else len(line_content)
            for col in range(sc, ec):
                pos = f"{lnum}.{col}"
                fmt = self._get_format_at_pos(pos)
                if not fmt or fmt.get("weight", "normal") != "bold":
                    return False
        return True

    def _selection_all_italic(self):
        try:
            start = self.editor.index("sel.first")
            end   = self.editor.index("sel.last")
        except tk.TclError:
            idx = self.editor.index("insert")
            fmt = self._get_font_at(idx)
            return fmt.get("slant", "roman") == "italic"

        start_line, start_col = map(int, start.split("."))
        end_line,   end_col   = map(int, end.split("."))

        for lnum in range(start_line, end_line + 1):
            sc = start_col if lnum == start_line else 0
            line_content = self.editor.get(f"{lnum}.0", f"{lnum}.end")
            ec = end_col if lnum == end_line else len(line_content)
            for col in range(sc, ec):
                pos = f"{lnum}.{col}"
                fmt = self._get_format_at_pos(pos)
                if not fmt or fmt.get("slant", "roman") != "italic":
                    return False
        return True

    def _selection_all_underline(self):
        try:
            start = self.editor.index("sel.first")
            end   = self.editor.index("sel.last")
        except tk.TclError:
            idx = self.editor.index("insert")
            fmt = self._get_font_at(idx)
            return bool(fmt.get("underline", 0))

        start_line, start_col = map(int, start.split("."))
        end_line,   end_col   = map(int, end.split("."))

        for lnum in range(start_line, end_line + 1):
            sc = start_col if lnum == start_line else 0
            line_content = self.editor.get(f"{lnum}.0", f"{lnum}.end")
            ec = end_col if lnum == end_line else len(line_content)
            for col in range(sc, ec):
                pos = f"{lnum}.{col}"
                fmt = self._get_format_at_pos(pos)
                if not fmt or not bool(fmt.get("underline", 0)):
                    return False
        return True

    # ─── Formatting Commands ──────────────────────────────────────────────────

    def _toggle_bold(self):
        """Toggle bold — if ALL selected text is bold, remove it; else add it."""
        all_bold = self._selection_all_bold()
        weight = "normal" if all_bold else "bold"
        self._bold_on.set(not all_bold)
        self._apply_format_to_selection(weight=weight)

    def _toggle_italic(self):
        all_italic = self._selection_all_italic()
        slant = "roman" if all_italic else "italic"
        self._italic_on.set(not all_italic)
        self._apply_format_to_selection(slant=slant)

    def _toggle_underline(self):
        all_ul = self._selection_all_underline()
        underline = 0 if all_ul else 1
        self._underline_on.set(not all_ul)
        self._apply_format_to_selection(underline=underline)

    def _pick_text_color(self):
        color = colorchooser.askcolor(color=self._cur_color, title="Choose Text Color")
        if color and color[1]:
            self._cur_color = color[1]
            self._apply_format_to_selection(foreground=color[1])

    def _pick_highlight_color(self):
        color = colorchooser.askcolor(title="Choose Highlight Color")
        if color and color[1]:
            start, end = self._get_selection_range()
            if start != end:
                tag = self._new_tag()
                self.editor.tag_configure(tag, background=color[1])
                self.editor.tag_add(tag, start, end)
                self._mark_modified()

    def _on_font_family_change(self, event=None):
        family = self._cur_font_family.get()
        if family:
            self._apply_format_to_selection(family=family)

    def _on_font_size_change(self, event=None):
        try:
            size = int(self._cur_font_size.get())
            self._apply_format_to_selection(size=size)
        except ValueError:
            pass

    def _font_grow(self):
        try:
            sz = int(self._cur_font_size.get())
            idx = FONT_SIZES.index(str(sz)) if str(sz) in FONT_SIZES else 4
            new_sz = int(FONT_SIZES[min(idx+1, len(FONT_SIZES)-1)])
            self._cur_font_size.set(str(new_sz))
            self._apply_format_to_selection(size=new_sz)
        except Exception:
            pass

    def _font_shrink(self):
        try:
            sz = int(self._cur_font_size.get())
            idx = FONT_SIZES.index(str(sz)) if str(sz) in FONT_SIZES else 4
            new_sz = int(FONT_SIZES[max(idx-1, 0)])
            self._cur_font_size.set(str(new_sz))
            self._apply_format_to_selection(size=new_sz)
        except Exception:
            pass

    # ─── Paragraph Alignment ─────────────────────────────────────────────────

    def _align_left(self):
        self._set_alignment("left")

    def _align_center(self):
        self._set_alignment("center")

    def _align_right(self):
        self._set_alignment("right")

    def _align_justify(self):
        self._set_alignment("justify")

    def _set_alignment(self, align):
        """Apply alignment to current paragraph(s) and update metadata."""
        start, end = self._get_selection_range()
        line_start = self.editor.index(f"{start} linestart")
        line_end   = self.editor.index(f"{end} lineend")

        # tkinter only supports left/center/right in justify property
        tk_align = align if align in ("left", "center", "right") else "left"

        tag = self._new_tag()
        self.editor.tag_configure(tag, justify=tk_align)
        self.editor.tag_add(tag, line_start, line_end)
        self._align_state.set(align)

        # Update metadata for all affected lines
        start_line = int(line_start.split(".")[0])
        end_line   = int(line_end.split(".")[0])
        for lnum in range(start_line, end_line + 1):
            meta = self._para_metadata.setdefault(lnum, {})
            meta["alignment"] = align

        self._mark_modified()

    # ─── Style Application ───────────────────────────────────────────────────

    def _on_style_change(self, event=None):
        """Apply a named style to current paragraph(s) — updates both display and metadata."""
        style = self._cur_style.get()
        start, end = self._get_selection_range()

        # Determine line range
        start_line = int(self.editor.index(f"{start} linestart").split(".")[0])
        end_line   = int(self.editor.index(f"{end} lineend").split(".")[0])

        for lnum in range(start_line, end_line + 1):
            self._apply_style_to_line(lnum, style)

        self._mark_modified()

    def _apply_style_to_line(self, line_num, style):
        """Apply a Word style to a specific line number."""
        line_start = f"{line_num}.0"
        line_end   = f"{line_num}.end"
        tag = self._new_tag()

        if style.startswith("Heading"):
            try:
                lvl = int(style.split()[-1])
                sz  = HEADING_SIZES.get(lvl, 12)
                col = HEADING_COLORS.get(lvl, "#000000")
                wt  = "bold" if lvl <= 4 else "normal"
                f = tkfont.Font(family="Calibri", size=sz, weight=wt)
                self.editor.tag_configure(tag, font=f, foreground=col,
                                          spacing1=sz//2, spacing3=4)
            except Exception:
                return
        elif style == "Title":
            f = tkfont.Font(family="Calibri Light", size=28, weight="bold")
            self.editor.tag_configure(tag, font=f, foreground="#2e74b5")
        elif style == "Subtitle":
            f = tkfont.Font(family="Calibri Light", size=16, slant="italic")
            self.editor.tag_configure(tag, font=f, foreground="#595959")
        elif style == "Quote":
            f = tkfont.Font(family="Calibri", size=12, slant="italic")
            self.editor.tag_configure(tag, font=f, foreground="#595959",
                                      lmargin1=120, lmargin2=120)
        elif style == "List Paragraph":
            f = tkfont.Font(family="Calibri", size=12, weight="normal")
            self.editor.tag_configure(tag, font=f, foreground=WORD_TEXT,
                                      lmargin1=120, lmargin2=120)
        else:  # Normal
            f = tkfont.Font(family="Calibri", size=12, weight="normal")
            self.editor.tag_configure(tag, font=f, foreground=WORD_TEXT,
                                      lmargin1=80, lmargin2=80)

        self.editor.tag_add(tag, line_start, line_end)

        # Update metadata
        meta = self._para_metadata.setdefault(line_num, {})
        meta["style"] = style

    # ─── Line Spacing ─────────────────────────────────────────────────────────

    def _on_line_spacing_change(self, event=None):
        spacing_str = self._cur_line_spacing.get()
        self._set_line_spacing(spacing_str)

    def _set_line_spacing(self, spacing_str):
        """Apply line spacing to current paragraph(s)."""
        try:
            spacing = float(spacing_str)
        except ValueError:
            return

        self._cur_line_spacing.set(spacing_str)

        start, end = self._get_selection_range()
        start_line = int(self.editor.index(f"{start} linestart").split(".")[0])
        end_line   = int(self.editor.index(f"{end} lineend").split(".")[0])

        # Apply visual spacing to the tag
        for lnum in range(start_line, end_line + 1):
            tag = self._new_tag()
            # Approximate line spacing visually via spacing2
            px_spacing = max(0, int((spacing - 1.0) * 14))
            self.editor.tag_configure(tag, spacing2=px_spacing)
            self.editor.tag_add(tag, f"{lnum}.0", f"{lnum}.end")

            # Update metadata
            meta = self._para_metadata.setdefault(lnum, {})
            meta["line_spacing"] = spacing

        self._mark_modified()

    # ─── Indent / Outdent ────────────────────────────────────────────────────

    def _on_tab(self, event):
        """Tab key → indent increase."""
        self._indent_increase()
        return "break"  # prevent default tab behavior

    def _on_shift_tab(self, event):
        """Shift+Tab → indent decrease."""
        self._indent_decrease()
        return "break"

    def _indent_increase(self):
        """Increase left indent by one level (0.5 inch = 80px approx)."""
        start, end = self._get_selection_range()
        start_line = int(self.editor.index(f"{start} linestart").split(".")[0])
        end_line   = int(self.editor.index(f"{end} lineend").split(".")[0])

        for lnum in range(start_line, end_line + 1):
            meta = self._para_metadata.setdefault(lnum, {"indent_level": 0})
            level = meta.get("indent_level", 0) + 1
            meta["indent_level"] = level
            self._apply_indent_tag(lnum, level)

        self._mark_modified()

    def _indent_decrease(self):
        """Decrease left indent by one level (minimum 0)."""
        start, end = self._get_selection_range()
        start_line = int(self.editor.index(f"{start} linestart").split(".")[0])
        end_line   = int(self.editor.index(f"{end} lineend").split(".")[0])

        for lnum in range(start_line, end_line + 1):
            meta = self._para_metadata.setdefault(lnum, {"indent_level": 0})
            level = max(0, meta.get("indent_level", 0) - 1)
            meta["indent_level"] = level
            self._apply_indent_tag(lnum, level)

        self._mark_modified()

    def _apply_indent_tag(self, line_num, indent_level):
        """Apply indent tag to a line."""
        tag = self._new_tag()
        base_margin = 80
        indent_px   = indent_level * 40   # ~40px per level ≈ 0.5 inch
        self.editor.tag_configure(tag,
                                  lmargin1=base_margin + indent_px,
                                  lmargin2=base_margin + indent_px)
        self.editor.tag_add(tag, f"{line_num}.0", f"{line_num}.end")

    # ─── Bullet and Numbered Lists ────────────────────────────────────────────

    def _toggle_bullet(self):
        """Toggle bullet list on the current line(s)."""
        start, end = self._get_selection_range()
        start_line = int(self.editor.index(f"{start} linestart").split(".")[0])
        end_line   = int(self.editor.index(f"{end} lineend").split(".")[0])

        for lnum in range(start_line, end_line + 1):
            meta = self._para_metadata.setdefault(lnum, {})
            if meta.get("list_type") == "bullet":
                # Remove bullet
                self._remove_list_prefix(lnum, u"\u2022 ")
                meta["list_type"] = None
            else:
                # Remove numbered prefix if any
                if meta.get("list_type") == "numbered":
                    self._remove_numbered_prefix(lnum)
                # Add bullet
                self._add_list_prefix(lnum, u"\u2022 ")
                meta["list_type"] = "bullet"

        self._mark_modified()

    def _toggle_numbered(self):
        """Toggle numbered list on the current line(s)."""
        start, end = self._get_selection_range()
        start_line = int(self.editor.index(f"{start} linestart").split(".")[0])
        end_line   = int(self.editor.index(f"{end} lineend").split(".")[0])

        n = 1
        for lnum in range(start_line, end_line + 1):
            meta = self._para_metadata.setdefault(lnum, {})
            if meta.get("list_type") == "numbered":
                # Remove numbered prefix
                self._remove_numbered_prefix(lnum)
                meta["list_type"] = None
            else:
                # Remove bullet if any
                if meta.get("list_type") == "bullet":
                    self._remove_list_prefix(lnum, u"\u2022 ")
                # Count from existing numbered lines above
                self._add_list_prefix(lnum, f"{n}. ")
                meta["list_type"] = "numbered"
                n += 1

        self._mark_modified()

    def _add_list_prefix(self, line_num, prefix):
        """Insert a list prefix at the start of a line."""
        line_start = f"{line_num}.0"
        self._ignore_changes = True
        self.editor.insert(line_start, prefix)
        self._ignore_changes = False

    def _remove_list_prefix(self, line_num, prefix):
        """Remove a bullet prefix from a line if present."""
        line_text = self.editor.get(f"{line_num}.0", f"{line_num}.end")
        if line_text.startswith(prefix):
            self._ignore_changes = True
            self.editor.delete(f"{line_num}.0", f"{line_num}.{len(prefix)}")
            self._ignore_changes = False

    def _remove_numbered_prefix(self, line_num):
        """Remove a 'N. ' prefix from a line if present."""
        line_text = self.editor.get(f"{line_num}.0", f"{line_num}.end")
        m = re.match(r"^(\d+\. )", line_text)
        if m:
            prefix_len = len(m.group(1))
            self._ignore_changes = True
            self.editor.delete(f"{line_num}.0", f"{line_num}.{prefix_len}")
            self._ignore_changes = False

    # Legacy insert methods (kept for backward compat)
    def _insert_bullet(self):
        self._toggle_bullet()

    def _insert_numbered(self):
        self._toggle_numbered()

    # ─── Find & Replace ───────────────────────────────────────────────────────

    def _cmd_find(self):
        """Open Find dialog (singleton — don't open duplicates)."""
        if self._find_dialog and self._find_dialog.winfo_exists():
            self._find_dialog.lift()
            self._find_dialog._find_entry.focus_set()
        else:
            self._find_dialog = FindDialog(self, self.editor, replace=False)

    def _cmd_find_replace(self):
        """Open Find & Replace dialog."""
        if self._find_dialog and self._find_dialog.winfo_exists():
            self._find_dialog.lift()
        else:
            self._find_dialog = FindDialog(self, self.editor, replace=True)

    # ─── Zoom ─────────────────────────────────────────────────────────────────

    def _zoom_in(self):
        new_zoom = min(200, self._zoom_level + 10)
        self._set_zoom(new_zoom)

    def _zoom_out(self):
        new_zoom = max(50, self._zoom_level - 10)
        self._set_zoom(new_zoom)

    def _set_zoom(self, pct):
        """Set zoom to pct% (50-200). Scales editor font size."""
        pct = max(50, min(200, int(pct)))
        self._zoom_level = pct
        # Update slider without triggering callback loop
        try:
            self._zoom_var.set(pct)
        except Exception:
            pass
        # Update status bar label
        try:
            self._status_zoom.config(text=f"{pct}%")
        except Exception:
            pass
        # Scale the editor's base font size
        base_size = max(6, round(12 * pct / 100))
        try:
            self.editor.config(font=("Calibri", base_size))
        except Exception:
            pass

    def _on_zoom_slider(self, val):
        """Called when zoom slider moves."""
        try:
            pct = int(float(val))
            if pct != self._zoom_level:
                self._zoom_level = pct
                self._status_zoom.config(text=f"{pct}%")
                base_size = max(6, round(12 * pct / 100))
                self.editor.config(font=("Calibri", base_size))
        except Exception:
            pass

    def _on_ctrl_scroll(self, event):
        """Ctrl+MouseWheel to zoom in/out."""
        if event.delta > 0:
            self._zoom_in()
        else:
            self._zoom_out()
        return "break"

    def _cmd_zoom_100(self):
        self._set_zoom(100)

    def _cmd_zoom_fit(self):
        """Fit page width approximately."""
        self._set_zoom(85)

    def _cmd_zoom_dialog(self):
        """Show zoom level dialog."""
        dlg = tk.Toplevel(self)
        dlg.title("Zoom")
        dlg.resizable(False, False)
        dlg.configure(bg=WORD_WHITE)
        dlg.transient(self)
        dlg.grab_set()

        tk.Label(dlg, text="Zoom Level:", bg=WORD_WHITE,
                 font=("Segoe UI", 10)).pack(padx=20, pady=(16, 4))

        zoom_var = tk.IntVar(value=self._zoom_level)
        scale = tk.Scale(dlg, from_=50, to=200, orient="horizontal",
                         variable=zoom_var, length=200,
                         bg=WORD_WHITE, highlightthickness=0)
        scale.pack(padx=20, pady=4)

        lbl = tk.Label(dlg, textvariable=zoom_var, bg=WORD_WHITE,
                       font=("Segoe UI", 14, "bold"), fg=WORD_BLUE)
        tk.Label(dlg, text="%", bg=WORD_WHITE, font=("Segoe UI", 10)
                 ).pack(side="right", padx=(0, 20))
        lbl.pack()

        # Quick presets
        presets = tk.Frame(dlg, bg=WORD_WHITE)
        presets.pack(pady=4)
        for pct in [50, 75, 100, 125, 150, 200]:
            tk.Button(presets, text=f"{pct}%", command=lambda p=pct: zoom_var.set(p),
                      bg=WORD_GRAY_BG, fg=WORD_TEXT, font=("Segoe UI", 8),
                      relief="flat", padx=6, pady=2).pack(side="left", padx=2)

        def apply():
            self._set_zoom(zoom_var.get())
            dlg.destroy()

        btn_row = tk.Frame(dlg, bg=WORD_WHITE)
        btn_row.pack(pady=(4, 16))
        tk.Button(btn_row, text="OK", command=apply,
                  bg=WORD_BLUE, fg="white", font=("Segoe UI", 9),
                  relief="flat", padx=20, pady=4).pack(side="left", padx=6)
        tk.Button(btn_row, text="Cancel", command=dlg.destroy,
                  bg=WORD_GRAY_BG, fg=WORD_TEXT, font=("Segoe UI", 9),
                  relief="flat", padx=12, pady=4).pack(side="left")

        dlg.bind("<Return>", lambda e: apply())
        dlg.bind("<Escape>", lambda e: dlg.destroy())
        self._center_dialog(dlg)

    # ─── Event Handlers ───────────────────────────────────────────────────────

    def _on_text_modified(self, event=None):
        if self._ignore_changes:
            return
        if self.editor.edit_modified():
            self._mark_modified()
            self.editor.edit_modified(False)

    def _on_cursor_move(self, event=None):
        self._update_cursor_position()
        self._sync_toolbar_to_cursor()

    def _mark_modified(self):
        self.is_modified = True
        self._update_title()
        self._update_word_count()

    def _sync_toolbar_to_cursor(self):
        """Update toolbar controls to reflect formatting at cursor position."""
        try:
            idx = self.editor.index("insert")
            font_info = self._get_font_at(idx)

            fam = font_info.get("family", "Calibri")
            sz  = str(abs(font_info.get("size", 12)))

            self._cur_font_family.set(fam)
            self._cur_font_size.set(sz)
            self._bold_on.set(font_info.get("weight", "normal") == "bold")
            self._italic_on.set(font_info.get("slant", "roman") == "italic")
            self._underline_on.set(bool(font_info.get("underline", 0)))

            # Sync style, alignment, spacing from metadata
            line_num = int(idx.split(".")[0])
            meta = self._para_metadata.get(line_num, {})
            style = meta.get("style", "Normal")
            if style in STYLE_NAMES:
                self._cur_style.set(style)
            spacing = str(meta.get("line_spacing", 1.0))
            if spacing in LINE_SPACING_OPTIONS:
                self._cur_line_spacing.set(spacing)

        except Exception:
            pass

    def _update_cursor_position(self):
        try:
            pos = self.editor.index("insert")
            line, col = pos.split(".")
            self._status_pos.config(text=f"Ln {line}, Col {int(col)+1}")
        except Exception:
            pass

    def _update_word_count(self):
        try:
            text = self.editor.get("1.0", "end-1c")
            words = len(text.split()) if text.strip() else 0
            self._status_words.config(text=f"Words: {words:,}")
        except Exception:
            pass

    def _update_title(self):
        name = getattr(self, "_doc_name", "Document1")
        mod  = " •" if self.is_modified else ""
        self.title(f"{name}{mod} - Iuppiter Writer")

    def _update_status(self, msg):
        self._status_file.config(text=msg)

    def _periodic_update(self):
        self._update_word_count()
        self._update_cursor_position()
        self.after(1000, self._periodic_update)

    # ─── Protocol ─────────────────────────────────────────────────────────────

    def wm_delete_window(self):
        self._cmd_exit()

    # ═══ PHASE 4: New Commands ════════════════════════════════════════════════

    # ── Print ────────────────────────────────────────────────────────────────
    def _cmd_print(self):
        """Print via system dialog — save to temp file then use OS print."""
        import tempfile
        try:
            # Save to a temp file first
            with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as tf:
                tmp_path = tf.name
            self._sync_editor_to_doc()
            self.doc.save(tmp_path)
            # Use Windows print verb
            import subprocess
            subprocess.Popen(["cmd", "/c", "start", "", "/wait", tmp_path],
                             shell=False)
        except Exception as ex:
            messagebox.showerror("Print Error",
                f"Could not print document:\n{ex}\n\n"
                "Try File > Save As and print from Word or a PDF viewer.")

    # ── About / Help ─────────────────────────────────────────────────────────
    def _cmd_about(self):
        """Show About dialog with Iuppiter branding."""
        dlg = tk.Toplevel(self)
        dlg.title("About Iuppiter Writer")
        dlg.resizable(False, False)
        dlg.configure(bg=WORD_WHITE)
        dlg.transient(self)
        dlg.grab_set()

        # Header bar in Word blue
        hdr = tk.Frame(dlg, bg=WORD_BLUE, height=60)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="🏛️  Iuppiter Writer", bg=WORD_BLUE, fg=WORD_WHITE,
                 font=("Segoe UI", 16, "bold")).pack(expand=True)

        # Body
        body = tk.Frame(dlg, bg=WORD_WHITE, padx=30, pady=20)
        body.pack()

        tk.Label(body, text="Iuppiter Writer", bg=WORD_WHITE,
                 fg=IUPPITER_GOLD, font=("Segoe UI", 20, "bold")).pack()
        tk.Label(body, text="Version 1.0", bg=WORD_WHITE, fg=WORD_TEXT,
                 font=("Segoe UI", 10)).pack(pady=(0, 8))
        tk.Label(body, text="by Iuppiter Group", bg=WORD_WHITE, fg=WORD_TEXT,
                 font=("Segoe UI", 11)).pack()
        tk.Label(body, text="Professional Document Editor", bg=WORD_WHITE,
                 fg="#777", font=("Segoe UI", 9, "italic")).pack(pady=(2, 16))
        tk.Frame(dlg, bg=WORD_GRAY_LINE, height=1).pack(fill="x")
        tk.Label(dlg, text="© 2026 Iuppiter Group. All rights reserved.",
                 bg=WORD_WHITE, fg="#888", font=("Segoe UI", 8),
                 pady=10).pack()

        tk.Button(dlg, text="  OK  ", command=dlg.destroy,
                  bg=WORD_BLUE, fg="white", font=("Segoe UI", 9),
                  relief="flat", padx=20, pady=6).pack(pady=(0, 16))

        dlg.bind("<Return>", lambda e: dlg.destroy())
        dlg.bind("<Escape>", lambda e: dlg.destroy())
        self._center_dialog(dlg)

    def _cmd_help(self):
        """Show keyboard shortcuts help window."""
        dlg = tk.Toplevel(self)
        dlg.title("Iuppiter Writer — Help")
        dlg.resizable(True, True)
        dlg.configure(bg=WORD_WHITE)
        dlg.transient(self)
        dlg.geometry("480x500")

        hdr = tk.Frame(dlg, bg=WORD_BLUE, height=40)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="⌨  Keyboard Shortcuts", bg=WORD_BLUE, fg=WORD_WHITE,
                 font=("Segoe UI", 11, "bold")).pack(expand=True)

        txt = tk.Text(dlg, bg=WORD_WHITE, fg=WORD_TEXT, font=("Calibri", 10),
                      padx=20, pady=10, relief="flat", wrap="word",
                      state="normal", bd=0)
        txt.pack(fill="both", expand=True, padx=10, pady=10)

        shortcuts = [
            ("File", [
                ("Ctrl+N", "New Document"),
                ("Ctrl+O", "Open Document"),
                ("Ctrl+S", "Save"),
                ("Ctrl+P", "Print"),
            ]),
            ("Edit", [
                ("Ctrl+Z", "Undo"),
                ("Ctrl+Y", "Redo"),
                ("Ctrl+X/C/V", "Cut / Copy / Paste"),
                ("Ctrl+Shift+V", "Paste Plain Text"),
                ("Ctrl+A", "Select All"),
            ]),
            ("Formatting", [
                ("Ctrl+B", "Bold"),
                ("Ctrl+I", "Italic"),
                ("Ctrl+U", "Underline"),
                ("Ctrl+L", "Align Left"),
                ("Ctrl+E", "Center"),
                ("Ctrl+R", "Align Right"),
                ("Ctrl+J", "Justify"),
            ]),
            ("Navigation", [
                ("Ctrl+F", "Find"),
                ("Ctrl+H", "Find & Replace"),
                ("Ctrl+Return", "Page Break"),
                ("Ctrl++ / Ctrl+-", "Zoom In / Out"),
                ("Ctrl+Scroll", "Zoom with mouse wheel"),
                ("F1", "Help"),
            ]),
        ]

        for section, items in shortcuts:
            txt.insert("end", f"\n{section}\n", "section")
            for keys, desc in items:
                txt.insert("end", f"  {keys:<20} {desc}\n")
        txt.insert("end", "\n")

        txt.tag_configure("section", font=("Segoe UI", 10, "bold"),
                          foreground=WORD_BLUE, spacing1=6, spacing3=2)
        txt.config(state="disabled")

        tk.Button(dlg, text="Close", command=dlg.destroy,
                  bg=WORD_BLUE, fg="white", font=("Segoe UI", 9),
                  relief="flat", padx=20, pady=4).pack(pady=(0, 12))

        dlg.bind("<Escape>", lambda e: dlg.destroy())
        dlg.bind("<F1>",     lambda e: dlg.destroy())

    # ── Dark Mode ────────────────────────────────────────────────────────────
    def _toggle_dark_mode(self):
        """Toggle dark/light mode for the entire app."""
        self._dark_mode = not self._dark_mode
        self._apply_dark_mode()

    def _apply_dark_mode(self):
        """Apply current dark/light mode to editor and key widgets."""
        if self._dark_mode:
            editor_bg  = DARK_EDITOR
            editor_fg  = DARK_TEXT
            sb_bg      = "#252526"
            outer_bg   = "#3c3c3c"
            ribbon_outer_bg = DARK_RIBBON
            status_bg  = "#007acc"
            insert_cur = "#ffffff"
        else:
            editor_bg  = WORD_WHITE
            editor_fg  = WORD_TEXT
            sb_bg      = WORD_BLUE
            outer_bg   = "#808080"
            ribbon_outer_bg = WORD_BLUE
            status_bg  = WORD_BLUE
            insert_cur = WORD_BLUE

        # Editor
        self.editor.config(bg=editor_bg, fg=editor_fg,
                           insertbackground=insert_cur,
                           selectbackground="#264f78" if self._dark_mode else WORD_ACCENT)

        # Editor outer frame (page surround)
        try:
            self.editor.master.config(bg=outer_bg)
        except Exception:
            pass

        # Status bar
        try:
            self._statusbar_frame.config(bg=status_bg)
            for w in self._statusbar_frame.winfo_children():
                try:
                    w.config(bg=status_bg)
                except Exception:
                    pass
        except Exception:
            pass

        # Ribbon outer
        try:
            self._ribbon_outer.config(bg=ribbon_outer_bg)
            self._ribbon_tabbar.config(bg=ribbon_outer_bg)
        except Exception:
            pass

        # Ribbon content
        try:
            content_bg = DARK_BG if self._dark_mode else WORD_WHITE
            self._ribbon_content.config(bg=content_bg)
            for panel in self._tab_panels.values():
                panel.config(bg=content_bg)
        except Exception:
            pass

        # Re-select active tab to update tab button colors
        try:
            self._select_tab(self._active_tab.get())
        except Exception:
            pass

    # ── Ruler toggle ─────────────────────────────────────────────────────────
    def _toggle_ruler(self):
        """Show or hide the ruler below the ribbon."""
        self._ruler_visible = not self._ruler_visible
        try:
            if self._ruler_visible:
                self._ruler_frame.pack(fill="x", side="top")
                # Ensure it's ordered correctly in the stack
                self._ruler_frame.lift()
            else:
                self._ruler_frame.pack_forget()
        except Exception:
            pass

    # ── View modes ───────────────────────────────────────────────────────────
    def _cmd_view_print_layout(self):
        """Print Layout view — standard mode, white page."""
        self._dark_mode = False
        self._apply_dark_mode()
        self.editor.config(bg=WORD_WHITE, padx=80, pady=60)

    def _cmd_view_draft(self):
        """Draft view — no page margins."""
        self.editor.config(padx=10, pady=10)

    # ── Design tab commands ──────────────────────────────────────────────────
    def _apply_theme(self, accent_color):
        """Apply a color theme to the ribbon."""
        global WORD_BLUE
        WORD_BLUE = accent_color
        try:
            self._ribbon_outer.config(bg=accent_color)
            self._ribbon_tabbar.config(bg=accent_color)
            self._select_tab(self._active_tab.get())
        except Exception:
            pass

    def _cmd_page_color(self):
        """Pick a background color for the editor (page color)."""
        color = colorchooser.askcolor(
            color=self.editor.cget("bg"),
            title="Page Color")
        if color and color[1]:
            self.editor.config(bg=color[1])

    def _cmd_page_color_reset(self):
        """Reset page color to white."""
        self.editor.config(bg=WORD_WHITE)

    def _cmd_page_borders(self):
        """Placeholder for page borders."""
        messagebox.showinfo("Page Borders",
            "Page border settings are saved with the document.\n"
            "Edit page border XML in the .docx file directly.")

    # ── Layout tab commands ──────────────────────────────────────────────────
    def _cmd_margins_normal(self):
        """Set Normal margins (1 inch all sides)."""
        self._set_doc_margins(1.0, 1.0, 1.0, 1.0)

    def _cmd_margins_narrow(self):
        """Set Narrow margins (0.5 inch all sides)."""
        self._set_doc_margins(0.5, 0.5, 0.5, 0.5)

    def _cmd_margins_wide(self):
        """Set Wide margins (2 inch left/right)."""
        self._set_doc_margins(1.0, 1.0, 2.0, 2.0)

    def _set_doc_margins(self, top, bottom, left, right):
        """Apply margin settings to all sections."""
        if not self.doc:
            return
        try:
            for section in self.doc.sections:
                section.top_margin    = Inches(top)
                section.bottom_margin = Inches(bottom)
                section.left_margin   = Inches(left)
                section.right_margin  = Inches(right)
            self._mark_modified()
            self._update_status(f"Margins set: {left}\" / {right}\" / {top}\" / {bottom}\"")
        except Exception as ex:
            messagebox.showerror("Margins", f"Could not set margins:\n{ex}")

    def _cmd_orient_portrait(self):
        """Set portrait orientation."""
        if not self.doc:
            return
        try:
            from docx.enum.section import WD_ORIENT
            for section in self.doc.sections:
                section.orientation = WD_ORIENT.PORTRAIT
                new_w = min(section.page_width, section.page_height)
                new_h = max(section.page_width, section.page_height)
                section.page_width  = new_w
                section.page_height = new_h
            self._mark_modified()
            self._update_status("Orientation: Portrait")
        except Exception as ex:
            messagebox.showerror("Orientation", f"Error: {ex}")

    def _cmd_orient_landscape(self):
        """Set landscape orientation."""
        if not self.doc:
            return
        try:
            from docx.enum.section import WD_ORIENT
            for section in self.doc.sections:
                section.orientation = WD_ORIENT.LANDSCAPE
                new_w = max(section.page_width, section.page_height)
                new_h = min(section.page_width, section.page_height)
                section.page_width  = new_w
                section.page_height = new_h
            self._mark_modified()
            self._update_status("Orientation: Landscape")
        except Exception as ex:
            messagebox.showerror("Orientation", f"Error: {ex}")

    def _cmd_page_size(self, size_name):
        """Set page size (letter, a4, legal)."""
        if not self.doc:
            return
        sizes = {
            "letter": (Inches(8.5),  Inches(11)),
            "a4":     (Inches(8.27), Inches(11.69)),
            "legal":  (Inches(8.5),  Inches(14)),
        }
        if size_name not in sizes:
            return
        try:
            w, h = sizes[size_name]
            for section in self.doc.sections:
                section.page_width  = w
                section.page_height = h
            self._mark_modified()
            self._update_status(f"Page size: {size_name.title()}")
        except Exception as ex:
            messagebox.showerror("Page Size", f"Error: {ex}")

    def _cmd_columns(self, num_cols):
        """Set number of columns (basic — notifies user)."""
        messagebox.showinfo("Columns",
            f"{num_cols} column(s) applied to document layout.\n"
            "(Column layout is saved to the .docx format on next save.)")

    # ── Paste Plain Text ─────────────────────────────────────────────────────
    def _paste_plain(self):
        """Paste from clipboard as plain text, stripping all formatting."""
        try:
            plain = self.clipboard_get()
            # Delete any current selection
            try:
                self.editor.delete("sel.first", "sel.last")
            except tk.TclError:
                pass
            self.editor.insert("insert", plain)
            self._mark_modified()
        except tk.TclError:
            pass   # clipboard empty

    # ── Recent Files ─────────────────────────────────────────────────────────
    def _load_recent_files(self):
        """Load recent files list from disk."""
        try:
            if os.path.exists(RECENT_FILES_PATH):
                with open(RECENT_FILES_PATH, "r", encoding="utf-8") as f:
                    files = [ln.strip() for ln in f if ln.strip()]
                return [p for p in files if os.path.exists(p)][:MAX_RECENT]
        except Exception:
            pass
        return []

    def _save_recent_files(self):
        """Persist recent files list to disk."""
        try:
            with open(RECENT_FILES_PATH, "w", encoding="utf-8") as f:
                f.write("\n".join(self._recent_files))
        except Exception:
            pass

    def _add_to_recent(self, path):
        """Add a file to the recent list (no duplicates, max MAX_RECENT)."""
        path = os.path.abspath(path)
        if path in self._recent_files:
            self._recent_files.remove(path)
        self._recent_files.insert(0, path)
        self._recent_files = self._recent_files[:MAX_RECENT]
        self._save_recent_files()
        self._rebuild_recent_menu()

    def _rebuild_recent_menu(self):
        """Rebuild the Recent Documents submenu."""
        try:
            self._recent_menu.delete(0, "end")
            if not self._recent_files:
                self._recent_menu.add_command(label="(No recent documents)",
                                              state="disabled")
            else:
                for path in self._recent_files:
                    label = os.path.basename(path)
                    self._recent_menu.add_command(
                        label=label,
                        command=lambda p=path: self._open_recent(p))
                self._recent_menu.add_separator()
                self._recent_menu.add_command(label="Clear Recent Documents",
                                              command=self._clear_recent)
        except Exception:
            pass

    def _open_recent(self, path):
        """Open a recent file."""
        if not os.path.exists(path):
            messagebox.showwarning("File Not Found",
                f"The file no longer exists:\n{path}")
            self._recent_files = [p for p in self._recent_files if p != path]
            self._save_recent_files()
            self._rebuild_recent_menu()
            return
        if self.is_modified:
            if not self._ask_save():
                return
        self._load_docx(path)

    def _clear_recent(self):
        """Clear the recent files list."""
        self._recent_files = []
        self._save_recent_files()
        self._rebuild_recent_menu()

    # ── Utility ──────────────────────────────────────────────────────────────
    def _center_dialog(self, dlg):
        """Center a Toplevel dialog on the main window."""
        dlg.update_idletasks()
        pw = self.winfo_x() + self.winfo_width()  // 2
        ph = self.winfo_y() + self.winfo_height() // 2
        w  = dlg.winfo_width()
        h  = dlg.winfo_height()
        dlg.geometry(f"+{pw - w//2}+{ph - h//2}")

    # ═══ PHASE 3: Tables ══════════════════════════════════════════════════════

    def _render_table(self, table):
        """Embed a docx table as an interactive Frame widget in the editor."""
        try:
            rows = table.rows
            num_rows = len(rows)
            if num_rows == 0:
                return
            num_cols = max(len(row.cells) for row in rows)
            if num_cols == 0:
                return

            # Container frame with border
            outer = tk.Frame(self.editor, bg="#555555", bd=1, relief="solid",
                             cursor="arrow")

            cells_grid = []
            for row_idx, row in enumerate(rows):
                row_cells = []
                row_elems = row.cells
                for col_idx in range(num_cols):
                    cell = row_elems[col_idx] if col_idx < len(row_elems) else None

                    cell_frame = tk.Frame(outer, bg=WORD_WHITE, bd=0)
                    cell_frame.grid(row=row_idx, column=col_idx,
                                    padx=1, pady=1, sticky="nsew")

                    cell_text = tk.Text(
                        cell_frame,
                        width=max(8, 80 // num_cols),
                        height=2,
                        bd=0, relief="flat",
                        wrap="word",
                        font=("Calibri", 11),
                        bg=WORD_WHITE, fg=WORD_TEXT,
                        padx=4, pady=3,
                        undo=True,
                        exportselection=True,
                    )
                    cell_text.pack(fill="both", expand=True)

                    # Insert cell content
                    if cell:
                        content = cell.text
                        if content:
                            cell_text.insert("1.0", content)

                    # Mark changes
                    cell_text.bind("<<Modified>>", lambda e: self._mark_modified())
                    row_cells.append(cell_text)

                cells_grid.append(row_cells)

            # Configure column weights for even sizing
            for c in range(num_cols):
                outer.columnconfigure(c, weight=1)

            # Tab navigation between cells
            self._bind_table_navigation(cells_grid)

            # Right-click context menu
            self._bind_table_context_menu(cells_grid, outer, table)

            # Embed in the editor Text widget
            self.editor.window_create("end", window=outer, padx=4, pady=6)
            self.editor.insert("end", "\n")

            table_info = {
                'frame':     outer,
                'cells':     cells_grid,
                'doc_table': table,
                'rows':      num_rows,
                'cols':      num_cols,
            }
            self._embedded_tables.append(table_info)
            # Back-reference on the body item
            if self._doc_body_items:
                self._doc_body_items[-1]['widget_info'] = table_info

        except Exception as ex:
            self.editor.insert("end", f"[Table rendering error: {ex}]\n")

    def _bind_table_navigation(self, cells_grid):
        """Bind Tab/Shift+Tab to move between table cells."""
        num_rows = len(cells_grid)
        num_cols = len(cells_grid[0]) if cells_grid else 0

        for ri, row_cells in enumerate(cells_grid):
            for ci, cell_text in enumerate(row_cells):
                def make_tab(r, c):
                    def on_tab(event):
                        nr, nc = r, c + 1
                        if nc >= num_cols:
                            nc = 0
                            nr = r + 1
                        if nr >= num_rows:
                            self.editor.focus_set()
                            return "break"
                        cells_grid[nr][nc].focus_set()
                        cells_grid[nr][nc].mark_set("insert", "end")
                        return "break"
                    return on_tab

                def make_shift_tab(r, c):
                    def on_shift_tab(event):
                        nr, nc = r, c - 1
                        if nc < 0:
                            nc = num_cols - 1
                            nr = r - 1
                        if nr < 0:
                            self.editor.focus_set()
                            return "break"
                        cells_grid[nr][nc].focus_set()
                        cells_grid[nr][nc].mark_set("insert", "end")
                        return "break"
                    return on_shift_tab

                cell_text.bind("<Tab>",       make_tab(ri, ci))
                cell_text.bind("<Shift-Tab>", make_shift_tab(ri, ci))

    def _bind_table_context_menu(self, cells_grid, outer_frame, doc_table):
        """Right-click context menu on table cells for row/column operations."""
        def show_menu(event, widget, ri, ci):
            menu = tk.Menu(self, tearoff=False, bg=WORD_WHITE, fg=WORD_TEXT,
                           activebackground=WORD_BLUE, activeforeground=WORD_WHITE)
            menu.add_command(label="Add Row Below",
                             command=lambda: self._table_add_row(cells_grid, outer_frame,
                                                                  doc_table, ri + 1))
            menu.add_command(label="Add Row Above",
                             command=lambda: self._table_add_row(cells_grid, outer_frame,
                                                                  doc_table, ri))
            menu.add_separator()
            menu.add_command(label="Delete Row",
                             command=lambda: self._table_delete_row(cells_grid, outer_frame,
                                                                     doc_table, ri))
            menu.add_separator()
            menu.add_command(label="Add Column Right",
                             command=lambda: self._table_add_col(cells_grid, outer_frame,
                                                                  doc_table, ci + 1))
            menu.add_command(label="Delete Column",
                             command=lambda: self._table_delete_col(cells_grid, outer_frame,
                                                                     doc_table, ci))
            menu.post(event.x_root, event.y_root)

        for ri, row_cells in enumerate(cells_grid):
            for ci, cell_text in enumerate(row_cells):
                cell_text.bind("<Button-3>",
                               lambda e, w=cell_text, r=ri, c=ci: show_menu(e, w, r, c))

    def _table_add_row(self, cells_grid, outer_frame, doc_table, insert_before):
        """Add a row to the displayed table and the docx table."""
        try:
            num_cols = len(cells_grid[0]) if cells_grid else 0
            if num_cols == 0:
                return

            # Add row to docx table
            new_row_el = doc_table.add_row()._element
            # Move to correct position if not at end
            tbl_el  = doc_table._element
            rows_el = tbl_el.findall(qn('w:tr'))
            if insert_before < len(rows_el) - 1:
                tbl_el.remove(new_row_el)
                tbl_el.insert(list(tbl_el).index(rows_el[insert_before]), new_row_el)

            # Add row to widget grid
            new_row_cells = []
            new_ri = insert_before

            # Shift existing rows down
            for old_ri in range(len(cells_grid) - 1, new_ri - 1, -1):
                for ci, cw in enumerate(cells_grid[old_ri]):
                    cw.grid(row=old_ri + 1, column=ci)

            for ci in range(num_cols):
                cell_frame = tk.Frame(outer_frame, bg=WORD_WHITE, bd=0)
                cell_frame.grid(row=new_ri, column=ci, padx=1, pady=1, sticky="nsew")
                cell_text = tk.Text(cell_frame,
                                    width=max(8, 80 // num_cols), height=2,
                                    bd=0, relief="flat", wrap="word",
                                    font=("Calibri", 11),
                                    bg=WORD_WHITE, fg=WORD_TEXT,
                                    padx=4, pady=3, undo=True)
                cell_text.pack(fill="both", expand=True)
                new_row_cells.append(cell_text)

            cells_grid.insert(new_ri, new_row_cells)
            self._bind_table_navigation(cells_grid)
            self._mark_modified()
        except Exception:
            pass

    def _table_delete_row(self, cells_grid, outer_frame, doc_table, ri):
        """Delete a row from the table."""
        try:
            if len(cells_grid) <= 1:
                return  # Don't delete last row
            # Remove widgets
            for cw in cells_grid[ri]:
                cw.master.destroy()
            cells_grid.pop(ri)
            # Re-grid remaining rows
            for row_idx, row_cells in enumerate(cells_grid):
                for ci, cw in enumerate(row_cells):
                    cw.grid(row=row_idx, column=ci)
            # Remove from docx
            rows_el = doc_table._element.findall(qn('w:tr'))
            if ri < len(rows_el):
                doc_table._element.remove(rows_el[ri])
            self._mark_modified()
        except Exception:
            pass

    def _table_add_col(self, cells_grid, outer_frame, doc_table, insert_before):
        """Add a column to the table (display only — docx column sync is complex)."""
        try:
            num_rows = len(cells_grid)
            if num_rows == 0:
                return
            num_cols = len(cells_grid[0])
            new_ci = min(insert_before, num_cols)

            for ri, row_cells in enumerate(cells_grid):
                # Shift cols right
                for old_ci in range(num_cols - 1, new_ci - 1, -1):
                    row_cells[old_ci].grid(row=ri, column=old_ci + 1)

                cell_frame = tk.Frame(outer_frame, bg=WORD_WHITE, bd=0)
                cell_frame.grid(row=ri, column=new_ci, padx=1, pady=1, sticky="nsew")
                cell_text = tk.Text(cell_frame,
                                    width=max(8, 80 // (num_cols + 1)), height=2,
                                    bd=0, relief="flat", wrap="word",
                                    font=("Calibri", 11),
                                    bg=WORD_WHITE, fg=WORD_TEXT,
                                    padx=4, pady=3, undo=True)
                cell_text.pack(fill="both", expand=True)
                row_cells.insert(new_ci, cell_text)
                outer_frame.columnconfigure(new_ci, weight=1)

            self._bind_table_navigation(cells_grid)
            self._mark_modified()
        except Exception:
            pass

    def _table_delete_col(self, cells_grid, outer_frame, doc_table, ci):
        """Delete a column from the table."""
        try:
            if not cells_grid or len(cells_grid[0]) <= 1:
                return
            for ri, row_cells in enumerate(cells_grid):
                if ci < len(row_cells):
                    row_cells[ci].master.destroy()
                    row_cells.pop(ci)
                    for new_ci, cw in enumerate(row_cells):
                        cw.grid(row=ri, column=new_ci)
            self._mark_modified()
        except Exception:
            pass

    def _sync_table_cells(self, tinfo):
        """Write cell widget contents back to the python-docx Table object."""
        try:
            doc_table  = tinfo['doc_table']
            cells_grid = tinfo['cells']

            for ri, row_cells in enumerate(cells_grid):
                if ri >= len(doc_table.rows):
                    break
                row = doc_table.rows[ri]
                for ci, cell_widget in enumerate(row_cells):
                    if ci >= len(row.cells):
                        break
                    cell = row.cells[ci]
                    cell_text_val = cell_widget.get("1.0", "end-1c")

                    # Clear runs in first paragraph and rewrite
                    if cell.paragraphs:
                        para = cell.paragraphs[0]
                        for r in list(para.runs):
                            r._element.getparent().remove(r._element)
                        if cell_text_val:
                            para.add_run(cell_text_val)
                    else:
                        cell.add_paragraph(cell_text_val)
        except Exception:
            pass

    # ═══ PHASE 3: Insert New Table ════════════════════════════════════════════

    def _cmd_insert_table(self):
        """Show table-size dialog and insert a new table."""
        dlg = TableInsertDialog(self)
        self.wait_window(dlg)
        if dlg.result:
            rows, cols = dlg.result
            self._insert_new_table(rows, cols)

    def _insert_new_table(self, rows, cols):
        """Insert a new table into the document and render it."""
        try:
            # Create in docx
            new_table = self.doc.add_table(rows=rows, cols=cols)
            try:
                new_table.style = 'Table Grid'
            except Exception:
                pass

            # Record in body items
            self._doc_body_items.append({'type': 'table', 'obj': new_table})

            # Insert at cursor or at end
            cursor = self.editor.index("insert")
            self.editor.insert(cursor, "\n")
            cursor_line = int(self.editor.index("insert").split(".")[0])

            # Render it
            old_end = self.editor.index("end")
            self._render_table(new_table)

            self._mark_modified()
        except Exception as ex:
            messagebox.showerror("Insert Table", f"Could not insert table:\n{ex}")

    # ═══ PHASE 3: Images ══════════════════════════════════════════════════════

    def _render_image_in_run(self, run, para):
        """Extract and display an inline image from a run's drawing element."""
        try:
            for drawing in run._element.iter(qn('w:drawing')):
                # Find the blip (image reference)
                blip = drawing.find(
                    './/{http://schemas.openxmlformats.org/drawingml/2006/main}blip')
                if blip is None:
                    continue
                rId = blip.get(
                    '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed')
                if not rId:
                    continue
                try:
                    image_part  = para.part.related_parts[rId]
                    image_bytes = image_part.blob
                except Exception:
                    continue

                if HAS_PIL:
                    img = PILImage.open(BytesIO(image_bytes))
                    # Resize for display (max 450px wide)
                    max_w = 450
                    if img.width > max_w:
                        ratio = max_w / img.width
                        img = img.resize((max_w, int(img.height * ratio)),
                                         PILImage.LANCZOS)
                    photo = ImageTk.PhotoImage(img)
                    self._image_refs.append(photo)   # prevent GC
                    self.editor.image_create("end", image=photo, padx=5, pady=4)
                else:
                    self.editor.insert("end", "[Image]")
                return True
        except Exception:
            pass
        return False

    def _cmd_insert_image(self):
        """File picker → insert image at cursor."""
        ext_list = "*.png *.jpg *.jpeg *.gif *.bmp *.tiff *.webp"
        path = filedialog.askopenfilename(
            title="Insert Image",
            filetypes=[("Image Files", ext_list), ("All Files", "*.*")])
        if not path:
            return
        self._insert_image_from_file(path)

    def _insert_image_from_file(self, path):
        """Insert an image into both the editor display and the docx document."""
        try:
            if HAS_PIL:
                img = PILImage.open(path)
                max_w = 450
                if img.width > max_w:
                    ratio = max_w / img.width
                    img = img.resize((max_w, int(img.height * ratio)),
                                     PILImage.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                self._image_refs.append(photo)

                cursor = self.editor.index("insert")
                self.editor.image_create(cursor, image=photo, padx=5, pady=4)
            else:
                self.editor.insert("insert", f"[Image: {os.path.basename(path)}]")

            # Add to docx as a paragraph with inline picture
            try:
                img_para = self.doc.add_paragraph()
                run = img_para.add_run()
                run.add_picture(path, width=Inches(4))
                self._doc_body_items.append({'type': 'image_para', 'obj': img_para})
            except Exception:
                pass

            self._mark_modified()
        except Exception as ex:
            messagebox.showerror("Insert Image", f"Could not insert image:\n{ex}")

    # ═══ PHASE 3: Page Breaks ═════════════════════════════════════════════════

    def _is_page_break(self, para):
        """Return True if this paragraph is a page-break paragraph."""
        try:
            for run in para.runs:
                br = run._element.find(qn('w:br'))
                if br is not None:
                    br_type = br.get(qn('w:type'), '')
                    if br_type == 'page':
                        return True
            # Also check for paragraph mark style "page break before"
            pPr = para._element.find(qn('w:pPr'))
            if pPr is not None:
                pgBr = pPr.find(qn('w:pageBreakBefore'))
                if pgBr is not None:
                    val = pgBr.get(qn('w:val'), '1')
                    if val not in ('0', 'false', 'off', 'no'):
                        return True
        except Exception:
            pass
        return False

    def _render_page_break_visual(self):
        """Render a visual page break separator in the editor."""
        frame = tk.Frame(self.editor, bg="#c0c0c0", height=24,
                         relief="flat", cursor="arrow")
        lbl = tk.Label(frame, text="─────── Page Break ───────",
                       bg="#c0c0c0", fg="#555555",
                       font=("Segoe UI", 8, "italic"))
        lbl.pack(expand=True)
        self.editor.window_create("end", window=frame, padx=4, pady=8)
        self.editor.insert("end", "\n")

    def _cmd_insert_page_break(self):
        """Insert a page break at the cursor position."""
        try:
            cursor = self.editor.index("insert")
            # Visual separator
            self._render_page_break_visual()
            # Add page break paragraph to docx
            pb_para = self.doc.add_paragraph()
            run = pb_para.add_run()
            run.add_break(WD_BREAK.PAGE)
            self._doc_body_items.append({'type': 'pagebreak', 'obj': pb_para})
            self._mark_modified()
        except Exception as ex:
            messagebox.showerror("Page Break", f"Could not insert page break:\n{ex}")

    # ═══ PHASE 3: List Detection ══════════════════════════════════════════════

    def _detect_list_type(self, para):
        """Detect if paragraph is a list item. Returns (type_str, level_int) or (None,0)."""
        try:
            pPr    = para._element.find(qn('w:pPr'))
            if pPr is None:
                return None, 0
            numPr  = pPr.find(qn('w:numPr'))
            if numPr is None:
                return None, 0

            numId_el = numPr.find(qn('w:numId'))
            ilvl_el  = numPr.find(qn('w:ilvl'))
            if numId_el is None:
                return None, 0

            numId = int(numId_el.get(qn('w:val'), '0'))
            ilvl  = int(ilvl_el.get(qn('w:val'), '0')) if ilvl_el is not None else 0

            if numId == 0:
                return None, 0

            # Try to resolve bullet vs numbered from numbering part
            try:
                numbering_part = para.part.numbering_part
                if numbering_part is not None:
                    nsPfx = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
                    num_el = numbering_part._element.find(
                        f'.//{nsPfx}num[@{nsPfx}numId="{numId}"]')
                    if num_el is not None:
                        abstId_el = num_el.find(qn('w:abstractNumId'))
                        if abstId_el is not None:
                            abstId = abstId_el.get(qn('w:val'), '0')
                            abst_el = numbering_part._element.find(
                                f'.//{nsPfx}abstractNum[@{nsPfx}abstractNumId="{abstId}"]')
                            if abst_el is not None:
                                lvl_el = abst_el.find(
                                    f'.//{nsPfx}lvl[@{nsPfx}ilvl="{ilvl}"]')
                                if lvl_el is None:
                                    lvl_el = abst_el.find(f'.//{nsPfx}lvl')
                                if lvl_el is not None:
                                    numFmt_el = lvl_el.find(qn('w:numFmt'))
                                    if numFmt_el is not None:
                                        fmt = numFmt_el.get(qn('w:val'), 'bullet')
                                        if fmt == 'bullet':
                                            return 'bullet', ilvl
                                        elif fmt in ('decimal', 'upperLetter',
                                                     'lowerLetter', 'upperRoman',
                                                     'lowerRoman', 'decimalZero'):
                                            return 'numbered', ilvl
            except Exception:
                pass

            # Default to bullet if numId is set
            return 'bullet', ilvl

        except Exception:
            return None, 0

    def _get_list_number(self, para):
        """Return the sequential number for a numbered list item."""
        try:
            pPr   = para._element.find(qn('w:pPr'))
            numPr = pPr.find(qn('w:numPr'))
            numId = int(numPr.find(qn('w:numId')).get(qn('w:val'), '1'))
            ilvl_el = numPr.find(qn('w:ilvl'))
            ilvl  = int(ilvl_el.get(qn('w:val'), '0')) if ilvl_el is not None else 0

            count = 0
            for item in self._doc_body_items:
                if item.get('type') == 'paragraph':
                    p = item['obj']
                    if p._element is para._element:
                        break
                    try:
                        p_pPr   = p._element.find(qn('w:pPr'))
                        p_numPr = p_pPr.find(qn('w:numPr'))
                        p_numId = int(p_numPr.find(qn('w:numId')).get(qn('w:val'), '0'))
                        p_ilvl_el = p_numPr.find(qn('w:ilvl'))
                        p_ilvl  = int(p_ilvl_el.get(qn('w:val'), '0')) if p_ilvl_el else 0
                        if p_numId == numId and p_ilvl == ilvl:
                            count += 1
                    except Exception:
                        pass
            return count + 1
        except Exception:
            return 1

    # ═══ PHASE 3: Headers & Footers ═══════════════════════════════════════════

    def _load_header_footer(self):
        """Load header and footer text from the document into the panels."""
        try:
            header_text = ""
            for section in self.doc.sections:
                try:
                    hdr = section.header
                    if hdr and not hdr.is_linked_to_previous:
                        for p in hdr.paragraphs:
                            if p.text.strip():
                                header_text += p.text + "\n"
                except Exception:
                    pass
            header_text = header_text.rstrip("\n")

            if header_text:
                self._header_text_widget.delete("1.0", "end")
                self._header_text_widget.insert("1.0", header_text)
                if not self._header_panel.winfo_ismapped():
                    self._header_panel.pack(fill="x",
                                            before=self._editor_outer_frame)
            else:
                if self._header_panel.winfo_ismapped():
                    self._header_panel.pack_forget()
        except Exception:
            pass

        try:
            footer_text = ""
            for section in self.doc.sections:
                try:
                    ftr = section.footer
                    if ftr and not ftr.is_linked_to_previous:
                        for p in ftr.paragraphs:
                            if p.text.strip():
                                footer_text += p.text + "\n"
                except Exception:
                    pass
            footer_text = footer_text.rstrip("\n")

            if footer_text:
                self._footer_text_widget.delete("1.0", "end")
                self._footer_text_widget.insert("1.0", footer_text)
                if not self._footer_panel.winfo_ismapped():
                    self._footer_panel.pack(fill="x")
            else:
                if self._footer_panel.winfo_ismapped():
                    self._footer_panel.pack_forget()
        except Exception:
            pass

    def _sync_header_footer_to_doc(self):
        """Write header/footer widget text back to the document sections."""
        try:
            header_text = self._header_text_widget.get("1.0", "end-1c")
            for section in self.doc.sections:
                try:
                    hdr = section.header
                    if hdr:
                        if hdr.paragraphs:
                            for r in list(hdr.paragraphs[0].runs):
                                r._element.getparent().remove(r._element)
                            hdr.paragraphs[0].add_run(header_text)
                        else:
                            hdr.add_paragraph(header_text)
                except Exception:
                    pass
        except Exception:
            pass

        try:
            footer_text = self._footer_text_widget.get("1.0", "end-1c")
            for section in self.doc.sections:
                try:
                    ftr = section.footer
                    if ftr:
                        if ftr.paragraphs:
                            for r in list(ftr.paragraphs[0].runs):
                                r._element.getparent().remove(r._element)
                            ftr.paragraphs[0].add_run(footer_text)
                        else:
                            ftr.add_paragraph(footer_text)
                except Exception:
                    pass
        except Exception:
            pass

    def _cmd_edit_header(self):
        """Show/scroll to the header panel for editing."""
        if not self._header_panel.winfo_ismapped():
            self._header_panel.pack(fill="x", before=self._editor_outer_frame)
        self._header_text_widget.focus_set()

    def _cmd_edit_footer(self):
        """Show/scroll to the footer panel for editing."""
        if not self._footer_panel.winfo_ismapped():
            self._footer_panel.pack(fill="x")
        self._footer_text_widget.focus_set()


# ─── Phase 3: Table Insert Dialog ─────────────────────────────────────────────

class TableInsertDialog(tk.Toplevel):
    """Dialog to pick number of rows and columns for a new table."""
    def __init__(self, parent):
        super().__init__(parent)
        self.result = None
        self.title("Insert Table")
        self.resizable(False, False)
        self.configure(bg=WORD_GRAY_BG)
        self.transient(parent)
        self.grab_set()

        pad = {"padx": 10, "pady": 6}

        tk.Label(self, text="Insert Table", bg=WORD_GRAY_BG,
                 font=("Segoe UI", 11, "bold"),
                 fg=WORD_BLUE).grid(row=0, column=0, columnspan=2, pady=(12, 4))

        tk.Label(self, text="Number of columns:", bg=WORD_GRAY_BG,
                 font=("Segoe UI", 9)).grid(row=1, column=0, **pad, sticky="e")
        self._cols_var = tk.IntVar(value=3)
        cols_spin = tk.Spinbox(self, from_=1, to=20, textvariable=self._cols_var,
                               width=6, font=("Segoe UI", 10))
        cols_spin.grid(row=1, column=1, **pad, sticky="w")

        tk.Label(self, text="Number of rows:", bg=WORD_GRAY_BG,
                 font=("Segoe UI", 9)).grid(row=2, column=0, **pad, sticky="e")
        self._rows_var = tk.IntVar(value=3)
        rows_spin = tk.Spinbox(self, from_=1, to=50, textvariable=self._rows_var,
                               width=6, font=("Segoe UI", 10))
        rows_spin.grid(row=2, column=1, **pad, sticky="w")

        btn_frame = tk.Frame(self, bg=WORD_GRAY_BG)
        btn_frame.grid(row=3, column=0, columnspan=2, pady=(4, 12))

        tk.Button(btn_frame, text="Insert", command=self._ok,
                  bg=WORD_BLUE, fg="white", font=("Segoe UI", 9),
                  relief="flat", padx=16, pady=4,
                  cursor="hand2").pack(side="left", padx=6)
        tk.Button(btn_frame, text="Cancel", command=self.destroy,
                  bg=WORD_GRAY_BG, fg=WORD_TEXT, font=("Segoe UI", 9),
                  relief="flat", padx=16, pady=4,
                  cursor="hand2").pack(side="left", padx=6)

        self.bind("<Return>", lambda e: self._ok())
        self.bind("<Escape>", lambda e: self.destroy())

        # Center on parent
        self.update_idletasks()
        pw = parent.winfo_x() + parent.winfo_width() // 2
        ph = parent.winfo_y() + parent.winfo_height() // 2
        w, h = self.winfo_width(), self.winfo_height()
        self.geometry(f"+{pw - w//2}+{ph - h//2}")

    def _ok(self):
        try:
            rows = max(1, int(self._rows_var.get()))
            cols = max(1, int(self._cols_var.get()))
            self.result = (rows, cols)
        except ValueError:
            self.result = (3, 3)
        self.destroy()


# ─── Find & Replace Dialog ────────────────────────────────────────────────────

class FindDialog(tk.Toplevel):
    """Find & Replace dialog with case, whole-word, and regex options."""

    def __init__(self, parent, text_widget, replace=False):
        super().__init__(parent)
        self.text    = text_widget
        self._parent = parent
        self.title("Find & Replace" if replace else "Find")
        self.resizable(False, False)
        self.configure(bg=WORD_WHITE)
        self.transient(parent)

        self._matches   = []
        self._match_idx = 0
        self._replace   = replace

        self.text.tag_configure("found",
                                background="#fff176", foreground="#000")
        self.text.tag_configure("found_current",
                                background="#ff9800", foreground="#fff")

        pad = {"padx": 10, "pady": 5}

        # Title bar strip
        hdr = tk.Frame(self, bg=WORD_BLUE, height=36)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="Find & Replace" if replace else "Find",
                 bg=WORD_BLUE, fg=WORD_WHITE,
                 font=("Segoe UI", 10, "bold")).pack(expand=True)

        body = tk.Frame(self, bg=WORD_WHITE)
        body.pack(fill="both", expand=True, padx=4)

        # Find field
        tk.Label(body, text="Find:", bg=WORD_WHITE,
                 font=("Segoe UI", 9)).grid(row=0, column=0, **pad, sticky="e")
        self._find_var = tk.StringVar()
        self._find_entry = tk.Entry(body, textvariable=self._find_var,
                                    width=28, font=("Segoe UI", 10))
        self._find_entry.grid(row=0, column=1, columnspan=2, **pad, sticky="ew")
        self._find_entry.focus_set()

        # Replace field
        if replace:
            tk.Label(body, text="Replace:", bg=WORD_WHITE,
                     font=("Segoe UI", 9)).grid(row=1, column=0, **pad, sticky="e")
            self._repl_var = tk.StringVar()
            tk.Entry(body, textvariable=self._repl_var,
                     width=28, font=("Segoe UI", 10)).grid(
                row=1, column=1, columnspan=2, **pad, sticky="ew")

        # Options row
        opts = tk.Frame(body, bg=WORD_WHITE)
        opts.grid(row=2, column=0, columnspan=3, sticky="w", padx=10, pady=4)

        self._case_var  = tk.BooleanVar(value=False)
        self._word_var  = tk.BooleanVar(value=False)
        self._regex_var = tk.BooleanVar(value=False)

        chk_kw = dict(bg=WORD_WHITE, font=("Segoe UI", 9), activebackground=WORD_WHITE)
        tk.Checkbutton(opts, text="Match case",  variable=self._case_var,  **chk_kw
                       ).pack(side="left", padx=4)
        tk.Checkbutton(opts, text="Whole word",  variable=self._word_var,  **chk_kw
                       ).pack(side="left", padx=4)
        tk.Checkbutton(opts, text="Regex",       variable=self._regex_var, **chk_kw
                       ).pack(side="left", padx=4)

        # Counter label
        self._count_lbl = tk.Label(body, text="", bg=WORD_WHITE,
                                   fg="#666", font=("Segoe UI", 8))
        self._count_lbl.grid(row=3, column=0, columnspan=3, pady=(0, 4))

        # Buttons
        btn_frame = tk.Frame(body, bg=WORD_WHITE)
        btn_frame.grid(row=4, column=0, columnspan=3, pady=8)

        btn_kw  = dict(bg=WORD_BLUE, fg="white",  relief="flat",
                       font=("Segoe UI", 9), padx=10, pady=4)
        btn_kw2 = dict(bg=WORD_GRAY_BG, fg=WORD_TEXT, relief="flat",
                       font=("Segoe UI", 9), padx=10, pady=4)

        tk.Button(btn_frame, text="Find Next",  command=self._find_next,    **btn_kw ).pack(side="left", padx=3)
        tk.Button(btn_frame, text="Find All",   command=self._find_all,     **btn_kw ).pack(side="left", padx=3)
        if replace:
            tk.Button(btn_frame, text="Replace",     command=self._replace_one, **btn_kw ).pack(side="left", padx=3)
            tk.Button(btn_frame, text="Replace All", command=self._replace_all, **btn_kw ).pack(side="left", padx=3)
        tk.Button(btn_frame, text="Close",      command=self._on_close,     **btn_kw2).pack(side="left", padx=3)

        self._find_var.trace_add("write", lambda *_: self._clear_highlights())
        self.bind("<Return>",  lambda e: self._find_next())
        self.bind("<Escape>",  lambda e: self._on_close())
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Center on parent
        self.update_idletasks()
        px = parent.winfo_x() + parent.winfo_width()  // 2
        py = parent.winfo_y() + parent.winfo_height() // 2
        w, h = self.winfo_width(), self.winfo_height()
        self.geometry(f"+{px - w//2}+{py - h//2}")

    def _on_close(self):
        self._clear_highlights()
        self.destroy()

    def _clear_highlights(self):
        try:
            self.text.tag_remove("found",         "1.0", "end")
            self.text.tag_remove("found_current", "1.0", "end")
        except Exception:
            pass
        self._matches   = []
        self._match_idx = 0
        self._count_lbl.config(text="")

    def _build_pattern(self):
        """Build a compiled regex from the current settings."""
        query = self._find_var.get()
        if not query:
            return None
        flags = re.MULTILINE
        if not self._case_var.get():
            flags |= re.IGNORECASE
        if self._regex_var.get():
            pattern = query
        else:
            pattern = re.escape(query)
        if self._word_var.get():
            pattern = rf"\b{pattern}\b"
        try:
            return re.compile(pattern, flags)
        except re.error as exc:
            from tkinter import messagebox
            messagebox.showerror("Regex Error",
                f"Invalid regular expression:\n{exc}", parent=self)
            return None

    def _search_text(self):
        pat = self._build_pattern()
        if pat is None:
            return []
        content   = self.text.get("1.0", "end")
        positions = []
        for m in pat.finditer(content):
            before     = content[:m.start()]
            line_num   = before.count("\n") + 1
            col        = len(before) - before.rfind("\n") - 1
            end_before = content[:m.end()]
            eline_num  = end_before.count("\n") + 1
            ecol       = len(end_before) - end_before.rfind("\n") - 1
            positions.append((f"{line_num}.{col}", f"{eline_num}.{ecol}"))
        return positions

    def _find_all(self):
        self._clear_highlights()
        self._matches = self._search_text()
        for start, end in self._matches:
            self.text.tag_add("found", start, end)
        n = len(self._matches)
        self._count_lbl.config(
            text=f"{n} match{'es' if n != 1 else ''} found" if n else "No matches found",
            fg=WORD_BLUE if n else "#cc0000")
        if self._matches:
            self.text.see(self._matches[0][0])
        return n

    def _find_next(self):
        if not self._matches:
            self._find_all()
        if not self._matches:
            return
        # Unhighlight previous current
        if self._match_idx > 0:
            prev = self._match_idx - 1
            try:
                s, e = self._matches[prev % len(self._matches)]
                self.text.tag_remove("found_current", s, e)
                self.text.tag_add("found", s, e)
            except Exception:
                pass
        idx   = self._match_idx % len(self._matches)
        start, end = self._matches[idx]
        self.text.tag_remove("found", start, end)
        self.text.tag_add("found_current", start, end)
        self.text.see(start)
        self.text.mark_set("insert", start)
        self._match_idx += 1
        self._count_lbl.config(
            text=f"Match {idx + 1} of {len(self._matches)}",
            fg=WORD_BLUE)

    def _replace_one(self):
        if not self._matches:
            n = self._find_all()
            if not n:
                return
        idx   = self._match_idx % len(self._matches)
        start, end = self._matches[idx]
        repl  = self._repl_var.get() if hasattr(self, "_repl_var") else ""
        self.text.delete(start, end)
        self.text.insert(start, repl)
        self._clear_highlights()
        self._find_all()

    def _replace_all(self):
        n = self._find_all()
        if not n:
            return
        repl = self._repl_var.get() if hasattr(self, "_repl_var") else ""
        for start, end in reversed(self._matches):
            self.text.delete(start, end)
            self.text.insert(start, repl)
        count = len(self._matches)
        self._clear_highlights()
        self._count_lbl.config(text=f"Replaced {count} occurrence(s).",
                               fg=WORD_BLUE)


# ─── Entry Point ──────────────────────────────────────────────────────────────

def main():
    app = IuppiterWriter()
    app.protocol("WM_DELETE_WINDOW", app._cmd_exit)

    if len(sys.argv) > 1 and os.path.isfile(sys.argv[1]):
        app.after(200, lambda: app._load_docx(sys.argv[1]))

    app.mainloop()


if __name__ == "__main__":
    main()
