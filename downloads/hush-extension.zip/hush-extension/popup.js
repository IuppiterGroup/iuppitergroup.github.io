// Hush - Popup Script

document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('toggle');
  const todayEl = document.getElementById('blockedToday');
  const allTimeEl = document.getElementById('blockedAllTime');
  const whitelistInput = document.getElementById('whitelistInput');
  const addWhitelistBtn = document.getElementById('addWhitelist');
  const whitelistList = document.getElementById('whitelistList');
  const statusText = document.getElementById('statusText');

  // Load current stats
  chrome.runtime.sendMessage({ type: 'GET_STATS' }, (response) => {
    if (!response) return;
    todayEl.textContent = response.blockedToday;
    allTimeEl.textContent = response.blockedAllTime;
    updateToggle(response.enabled);
    renderWhitelist(response.whitelist);
  });

  // Toggle on/off
  toggleBtn.addEventListener('click', () => {
    const isActive = toggleBtn.classList.contains('active');
    const newState = !isActive;
    chrome.runtime.sendMessage({ type: 'TOGGLE_ENABLED', enabled: newState }, () => {
      updateToggle(newState);
    });
  });

  function updateToggle(enabled) {
    if (enabled) {
      toggleBtn.classList.add('active');
      toggleBtn.title = 'Hush is ON — click to pause';
      if (statusText) statusText.textContent = 'Active';
    } else {
      toggleBtn.classList.remove('active');
      toggleBtn.title = 'Hush is OFF — click to enable';
      if (statusText) statusText.textContent = 'Paused';
    }
  }

  // Whitelist management
  addWhitelistBtn.addEventListener('click', addToWhitelist);
  whitelistInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addToWhitelist();
  });

  function addToWhitelist() {
    let domain = whitelistInput.value.trim().toLowerCase();
    if (!domain) return;
    // Strip protocol and path
    domain = domain.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (!domain) return;

    chrome.runtime.sendMessage({ type: 'GET_STATS' }, (response) => {
      const list = response.whitelist || [];
      if (!list.includes(domain)) {
        list.push(domain);
        chrome.runtime.sendMessage({ type: 'UPDATE_WHITELIST', whitelist: list }, () => {
          renderWhitelist(list);
          whitelistInput.value = '';
        });
      }
    });
  }

  function renderWhitelist(list) {
    whitelistList.innerHTML = '';
    if (!list || list.length === 0) {
      whitelistList.innerHTML = '<li class="empty">No sites whitelisted</li>';
      return;
    }
    for (const domain of list) {
      const li = document.createElement('li');
      li.innerHTML = `
        <span class="domain">${domain}</span>
        <button class="remove-btn" data-domain="${domain}" title="Remove">✕</button>
      `;
      whitelistList.appendChild(li);
    }
    // Attach remove handlers
    whitelistList.querySelectorAll('.remove-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const domain = btn.dataset.domain;
        chrome.runtime.sendMessage({ type: 'GET_STATS' }, (response) => {
          const newList = (response.whitelist || []).filter((d) => d !== domain);
          chrome.runtime.sendMessage({ type: 'UPDATE_WHITELIST', whitelist: newList }, () => {
            renderWhitelist(newList);
          });
        });
      });
    });
  }
});
