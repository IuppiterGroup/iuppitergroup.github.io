// Hush - Background Service Worker

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['enabled', 'blockedToday', 'blockedAllTime', 'whitelist', 'lastResetDate'], (result) => {
    const today = new Date().toDateString();
    chrome.storage.local.set({
      enabled: result.enabled !== false,
      blockedToday: result.lastResetDate === today ? (result.blockedToday || 0) : 0,
      blockedAllTime: result.blockedAllTime || 0,
      whitelist: result.whitelist || [],
      lastResetDate: today,
    });
  });
});

// Handle messages from content script and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'POPUP_BLOCKED') {
    chrome.storage.local.get(['blockedToday', 'blockedAllTime', 'declinedAllTime', 'hiddenAllTime', 'lastResetDate', 'whitelist'], (result) => {
      // Check whitelist against the top-level page (the report may come from a CMP iframe)
      const pageUrl = (sender.tab && sender.tab.url) || sender.url;
      if (pageUrl) {
        let domain = '';
        try { domain = new URL(pageUrl).hostname.toLowerCase(); } catch (e) { /* ignore */ }
        const wl = result.whitelist || [];
        if (domain && wl.some((d) => domain === d || domain.endsWith('.' + d))) {
          sendResponse({ success: false, reason: 'whitelisted' });
          return;
        }
      }

      const today = new Date().toDateString();
      const todayCount = result.lastResetDate === today ? (result.blockedToday || 0) : 0;

      // method: 'declined' (reject / opt-out saved) or 'hidden' (banner hidden, nothing accepted)
      const update = {
        blockedToday: todayCount + 1,
        blockedAllTime: (result.blockedAllTime || 0) + 1,
        lastResetDate: today,
      };
      if (request.method === 'hidden') update.hiddenAllTime = (result.hiddenAllTime || 0) + 1;
      else update.declinedAllTime = (result.declinedAllTime || 0) + 1;
      chrome.storage.local.set(update);

      // Update badge
      chrome.action.setBadgeText({ text: String(todayCount + 1) });
      chrome.action.setBadgeBackgroundColor({ color: '#6C5CE7' });

      sendResponse({ success: true });
    });
    return true;
  }

  if (request.type === 'GET_STATS') {
    chrome.storage.local.get(['blockedToday', 'blockedAllTime', 'declinedAllTime', 'hiddenAllTime', 'whitelist', 'enabled', 'lastResetDate'], (result) => {
      const today = new Date().toDateString();
      sendResponse({
        enabled: result.enabled !== false,
        blockedToday: result.lastResetDate === today ? (result.blockedToday || 0) : 0,
        blockedAllTime: result.blockedAllTime || 0,
        declinedAllTime: result.declinedAllTime || 0,
        hiddenAllTime: result.hiddenAllTime || 0,
        whitelist: result.whitelist || [],
      });
    });
    return true;
  }

  if (request.type === 'TOGGLE_ENABLED') {
    chrome.storage.local.set({ enabled: request.enabled });
    // Update badge
    if (!request.enabled) {
      chrome.action.setBadgeText({ text: 'OFF' });
      chrome.action.setBadgeBackgroundColor({ color: '#999' });
    } else {
      chrome.storage.local.get(['blockedToday', 'lastResetDate'], (result) => {
        const today = new Date().toDateString();
        const count = result.lastResetDate === today ? (result.blockedToday || 0) : 0;
        chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
        chrome.action.setBadgeBackgroundColor({ color: '#6C5CE7' });
      });
    }
    sendResponse({ success: true });
    return true;
  }

  if (request.type === 'UPDATE_WHITELIST') {
    chrome.storage.local.set({ whitelist: request.whitelist });
    sendResponse({ success: true });
    return true;
  }
});

// Reset daily counter on startup
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(['lastResetDate', 'blockedToday'], (result) => {
    const today = new Date().toDateString();
    if (result.lastResetDate !== today) {
      chrome.storage.local.set({ blockedToday: 0, lastResetDate: today });
      chrome.action.setBadgeText({ text: '' });
    } else if (result.blockedToday > 0) {
      chrome.action.setBadgeText({ text: String(result.blockedToday) });
      chrome.action.setBadgeBackgroundColor({ color: '#6C5CE7' });
    }
  });
});
