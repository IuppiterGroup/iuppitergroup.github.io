// Hush - Content Script
// Detects and dismisses cookie consent popups and overlays

(function () {
  'use strict';

  if (window.__hushLoaded) return;
  window.__hushLoaded = true;

  let enabled = true;
  let whitelist = [];
  const currentDomain = window.location.hostname;

  // Load settings
  chrome.storage.local.get(['enabled', 'whitelist'], (result) => {
    enabled = result.enabled !== false;
    whitelist = result.whitelist || [];
    if (enabled && !whitelist.includes(currentDomain)) {
      startHush();
    }
  });

  // Listen for toggle changes
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.enabled) enabled = changes.enabled.newValue;
    if (changes.whitelist) whitelist = changes.whitelist.newValue || [];
  });

  // ========== KNOWN CONSENT FRAMEWORK SELECTORS ==========
  const CONSENT_SELECTORS = [
    // OneTrust
    '#onetrust-consent-sdk',
    '#onetrust-banner-sdk',
    '.onetrust-pc-dark-filter',
    '.optanon-alert-box-wrapper',
    // CookieBot
    '#CybotCookiebotDialog',
    '#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll',
    // Quantcast / CMP
    '.qc-cmp2-container',
    '#qc-cmp2-main',
    '.qc-cmp-ui-container',
    // TrustArc / TrustE
    '.truste_box_overlay',
    '#truste-consent-track',
    '.truste-consent-content',
    // Cookielaw / Osano
    '.osano-cm-window',
    '.osano-cm-dialog',
    // Didomi
    '#didomi-host',
    '#didomi-popup',
    // Complianz
    '#cmplz-cookiebanner-container',
    '.cmplz-cookiebanner',
    // Cookie Notice
    '#cookie-notice',
    '#cookie_notice',
    '.cookie-notice',
    '.cookie-notice-container',
    // Cookie Consent (various)
    '#cookie-consent',
    '#cookieconsent',
    '.cookie-consent',
    '.cc-window',
    '.cc-banner',
    '.cc-dialog',
    // GDPR banners
    '.gdpr-banner',
    '.gdpr-consent',
    '#gdpr-banner',
    '#gdpr-consent',
    // Generic cookie banners
    '.cookie-banner',
    '.cookie-bar',
    '.cookie-popup',
    '.cookie-modal',
    '.cookie-overlay',
    '#cookie-banner',
    '#cookie-bar',
    '#cookie-popup',
    '#cookie-modal',
    '.cookieBanner',
    '.cookieBar',
    '#cookieBanner',
    // Consent banners
    '.consent-banner',
    '.consent-bar',
    '.consent-modal',
    '.consent-popup',
    '#consent-banner',
    '#consent-bar',
    // Privacy banners
    '.privacy-banner',
    '.privacy-bar',
    '.privacy-popup',
    '#privacy-banner',
    // Newsletter / notification nags
    '.newsletter-popup',
    '.newsletter-modal',
    '#newsletter-popup',
    '#newsletter-modal',
    // EU Cookie Law
    '#eu-cookie-law',
    '.eu-cookie-compliance-banner',
    // Sirdata
    '#sd-cmp',
    // Usercentrics
    '#usercentrics-root',
    // Admiral / Sourcepoint
    '[id^="sp_message_container"]',
    // Termly
    '.t-consentPrompt',
    // iubenda
    '#iubenda-cs-banner',
    // Klaro
    '.klaro .cookie-modal',
    '.klaro .cookie-notice',
  ];

  // Accept button selectors within consent containers
  const ACCEPT_BUTTON_SELECTORS = [
    // OneTrust
    '#onetrust-accept-btn-handler',
    '.onetrust-close-btn-handler',
    // CookieBot
    '#CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll',
    '#CybotCookiebotDialogBodyButtonAccept',
    // Quantcast
    '.qc-cmp2-summary-buttons button[mode="primary"]',
    // Osano
    '.osano-cm-accept-all',
    '.osano-cm-close',
    // Didomi
    '#didomi-notice-agree-button',
    // Complianz
    '.cmplz-btn.cmplz-accept',
    // CC
    '.cc-accept',
    '.cc-allow',
    '.cc-dismiss',
    '.cc-btn.cc-accept',
    // iubenda
    '.iubenda-cs-accept-btn',
    // Klaro
    '.klaro .cm-btn-accept',
    // Generic
    '[data-cookiefirst-action="accept"]',
    '[data-cc="accept"]',
    '[data-consent="accept"]',
    'button[data-action="accept"]',
  ];

  // Text patterns for accept buttons (case-insensitive)
  const ACCEPT_TEXT_PATTERNS = [
    /^accept\s*(all|cookies)?$/i,
    /^(i\s+)?agree$/i,
    /^(i\s+)?accept$/i,
    /^allow\s*(all|cookies)?$/i,
    /^got\s*it$/i,
    /^ok(ay)?$/i,
    /^consent$/i,
    /^continue$/i,
    /^understood$/i,
    /^accept\s*&?\s*close$/i,
    /^accept\s*and\s*continue$/i,
    /^yes,?\s*i\s*(agree|accept)/i,
    /^alle\s*akzeptieren$/i,      // German
    /^akzeptieren$/i,              // German
    /^accepter\s*(tout)?$/i,       // French
    /^tout\s*accepter$/i,          // French
    /^aceptar\s*(todo)?$/i,        // Spanish
    /^accetta\s*(tutto)?$/i,       // Italian
  ];

  function startHush() {
    // Run immediately
    setTimeout(scan, 500);
    setTimeout(scan, 1500);
    setTimeout(scan, 3000);

    // Watch for dynamically added popups
    const observer = new MutationObserver(() => {
      scan();
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
  }

  function scan() {
    if (!enabled || whitelist.includes(currentDomain)) return;

    // Method 1: Try known accept buttons directly
    for (const sel of ACCEPT_BUTTON_SELECTORS) {
      try {
        const btn = document.querySelector(sel);
        if (btn && isVisible(btn)) {
          btn.click();
          reportBlocked();
          return;
        }
      } catch (e) { /* invalid selector, skip */ }
    }

    // Method 2: Find consent containers and click accept within them
    for (const sel of CONSENT_SELECTORS) {
      try {
        const container = document.querySelector(sel);
        if (container && isVisible(container)) {
          if (clickAcceptInside(container)) return;
          // No accept button found — hide the container
          hideElement(container);
          reportBlocked();
          return;
        }
      } catch (e) { /* skip */ }
    }

    // Method 3: Scan all visible buttons/links for consent text
    const clickables = document.querySelectorAll(
      'button, a, [role="button"], input[type="button"], input[type="submit"]'
    );
    for (const el of clickables) {
      const text = (el.textContent || el.value || '').trim();
      if (text.length > 50) continue; // skip long text — not a button label
      for (const pattern of ACCEPT_TEXT_PATTERNS) {
        if (pattern.test(text) && isVisible(el) && isInsideConsentUI(el)) {
          el.click();
          reportBlocked();
          return;
        }
      }
    }
  }

  function clickAcceptInside(container) {
    // Look for accept-style buttons within the container
    const clickables = container.querySelectorAll(
      'button, a, [role="button"], input[type="button"], input[type="submit"]'
    );
    for (const el of clickables) {
      const text = (el.textContent || el.value || '').trim();
      for (const pattern of ACCEPT_TEXT_PATTERNS) {
        if (pattern.test(text) && isVisible(el)) {
          el.click();
          reportBlocked();
          return true;
        }
      }
    }
    // Try known button selectors within container
    for (const sel of ACCEPT_BUTTON_SELECTORS) {
      try {
        const btn = container.querySelector(sel);
        if (btn && isVisible(btn)) {
          btn.click();
          reportBlocked();
          return true;
        }
      } catch (e) { /* skip */ }
    }
    return false;
  }

  function isInsideConsentUI(el) {
    // Walk up the DOM — is this button inside something that looks like a consent popup?
    let node = el.parentElement;
    let depth = 0;
    while (node && depth < 10) {
      const id = (node.id || '').toLowerCase();
      const cls = (node.className || '').toString().toLowerCase();
      const text = id + ' ' + cls;
      if (
        text.match(/cookie|consent|gdpr|privacy|banner|cc-|cmp|notice|compliance|iubenda|didomi|osano|onetrust|trustac|quantcast/)
      ) {
        return true;
      }
      // Check if fixed/sticky positioned (likely an overlay)
      const style = window.getComputedStyle(node);
      if (
        (style.position === 'fixed' || style.position === 'sticky') &&
        parseInt(style.zIndex) > 999
      ) {
        return true;
      }
      node = node.parentElement;
      depth++;
    }
    return false;
  }

  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function hideElement(el) {
    el.style.setProperty('display', 'none', 'important');
    // Also remove any backdrop/overlay siblings
    if (el.parentElement) {
      const siblings = el.parentElement.children;
      for (const sib of siblings) {
        if (sib === el) continue;
        const style = window.getComputedStyle(sib);
        if (
          style.position === 'fixed' &&
          parseFloat(style.opacity) < 1 &&
          sib.offsetWidth >= window.innerWidth * 0.9
        ) {
          sib.style.setProperty('display', 'none', 'important');
        }
      }
    }
    // Restore body scroll if locked
    document.body.style.removeProperty('overflow');
    document.documentElement.style.removeProperty('overflow');
  }

  function reportBlocked() {
    try {
      chrome.runtime.sendMessage({ type: 'POPUP_BLOCKED' });
    } catch (e) { /* context invalidated */ }
  }
})();
