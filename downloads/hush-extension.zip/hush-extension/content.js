// Hush - Content Script
// Silences cookie consent popups by DECLINING them. Hush never clicks
// accept / agree / allow buttons. Order of preference:
//   1. The CMP's own reject control (known selectors, then reject-text match)
//   2. "Manage options" -> uncheck every optional toggle -> save choices
//   3. Hide the banner and its overlay and restore page scrolling (no consent given)
// Runs in all frames so it can act inside CMP iframes (Sourcepoint, etc.).

(function () {
  'use strict';

  if (window.__hushLoaded) return;
  window.__hushLoaded = true;

  // ========== SETTINGS ==========
  let enabled = true;
  let whitelist = [];
  let started = false;

  // Whitelist applies to the top-level site, also when running inside an iframe.
  const siteHost = (() => {
    try {
      const ao = window.location.ancestorOrigins;
      if (ao && ao.length) return new URL(ao[ao.length - 1]).hostname;
    } catch (e) { /* ignore */ }
    return window.location.hostname;
  })();
  const isTopFrame = window === window.top;

  function isWhitelisted() {
    const host = (siteHost || '').toLowerCase();
    return whitelist.some((d) => {
      d = String(d || '').toLowerCase();
      return d && (host === d || host.endsWith('.' + d));
    });
  }

  function isActive() {
    return enabled && !isWhitelisted();
  }

  chrome.storage.local.get(['enabled', 'whitelist'], (result) => {
    enabled = result.enabled !== false;
    whitelist = result.whitelist || [];
    if (isActive()) startHush();
  });

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.enabled) enabled = changes.enabled.newValue !== false;
    if (changes.whitelist) whitelist = changes.whitelist.newValue || [];
    if (isActive()) startHush();
  });

  // ========== KNOWN CMP REJECT CONTROLS ==========
  // textCheck: true means the element's label must read as a reject phrase.
  // Every element is also skipped if its label reads as an accept phrase.
  const REJECT_SELECTORS = [
    // OneTrust (banner + preference center)
    { sel: '#onetrust-reject-all-handler' },
    { sel: '.ot-pc-refuse-all-handler' },
    // Cookiebot
    { sel: '#CybotCookiebotDialogBodyButtonDecline' },
    { sel: '#CybotCookiebotDialogBodyLevelButtonLevelOptinDeclineAll' },
    // Didomi
    { sel: '#didomi-notice-disagree-button' },
    { sel: '.didomi-continue-without-agreeing' },
    // Quantcast Choice: the secondary button can be "More options", so check its label
    { sel: '.qc-cmp2-summary-buttons button[mode="secondary"]', textCheck: true },
    // TrustArc
    { sel: '#truste-consent-required' },
    // Osano
    { sel: '.osano-cm-denyAll' },
    { sel: '.osano-cm-button--type_deny' },
    // Complianz
    { sel: '.cmplz-deny' },
    // iubenda
    { sel: '.iubenda-cs-reject-btn' },
    // Klaro
    { sel: '.cm-btn-decline' },
    // Usercentrics (shadow DOM of #usercentrics-root)
    { sel: '[data-testid="uc-deny-all-button"]' },
    // Borlabs Cookie
    { sel: 'a._brlbs-refuse-btn' },
    { sel: '[data-cookie-refuse]' },
    // CookieYes
    { sel: '.cky-btn-reject' },
    // Termly
    { sel: '[data-tid="banner-decline"]' },
    // Google Funding Choices
    { sel: '.fc-cta-do-not-consent' },
    // Sourcepoint (runs inside its message iframe)
    { sel: 'button.sp_choice_type_13', textCheck: true },
    { sel: 'button.sp_choice_type_REJECT_ALL', textCheck: true },
    // Osano-style / cookieconsent (Insites)
    { sel: '.cc-deny' },
    // Cookie Notice (dFactory)
    { sel: '#cn-refuse-cookie' },
    // consentmanager.net
    { sel: '.cmpboxbtnno', textCheck: true },
    // tarteaucitron
    { sel: '#tarteaucitronAllDenied2' },
    // CookieFirst
    { sel: '[data-cookiefirst-action="reject"]' },
    // Moove GDPR
    { sel: '.moove-gdpr-infobar-reject-btn' },
    // Generic data attributes
    { sel: '[data-consent="reject"]', textCheck: true },
    { sel: '[data-cc="reject"]', textCheck: true },
    { sel: 'button[data-action="reject"]', textCheck: true },
  ];

  // Containers that hold consent UI (used for scoping and for the hide fallback)
  const CONSENT_CONTAINERS = [
    '#onetrust-consent-sdk', '#onetrust-banner-sdk', '#onetrust-pc-sdk', '.optanon-alert-box-wrapper',
    '#CybotCookiebotDialog',
    '.qc-cmp2-container', '#qc-cmp2-main', '.qc-cmp-ui-container',
    '.truste_box_overlay', '#truste-consent-track', '.truste-consent-content',
    '.osano-cm-window', '.osano-cm-dialog',
    '#didomi-host', '#didomi-popup', '#didomi-notice',
    '#cmplz-cookiebanner-container', '.cmplz-cookiebanner',
    '#cookie-notice', '#cookie_notice', '.cookie-notice', '.cookie-notice-container',
    '#cookie-consent', '#cookieconsent', '.cookie-consent', '.cc-window', '.cc-banner', '.cc-dialog',
    '.gdpr-banner', '.gdpr-consent', '#gdpr-banner', '#gdpr-consent',
    '.cookie-banner', '.cookie-bar', '.cookie-popup', '.cookie-modal', '.cookie-overlay',
    '#cookie-banner', '#cookie-bar', '#cookie-popup', '#cookie-modal',
    '.cookieBanner', '.cookieBar', '#cookieBanner',
    '.consent-banner', '.consent-bar', '.consent-modal', '.consent-popup', '#consent-banner', '#consent-bar',
    '.privacy-banner', '.privacy-bar', '.privacy-popup', '#privacy-banner',
    '#eu-cookie-law', '.eu-cookie-compliance-banner',
    '#sd-cmp',
    '#usercentrics-root', '#usercentrics-cmp-ui',
    '[id^="sp_message_container"]',
    '.t-consentPrompt', '#termly-code-snippet-support',
    '#iubenda-cs-banner',
    '.klaro .cookie-modal', '.klaro .cookie-notice',
    '#BorlabsCookieBox',
    '.cky-consent-container', '.cky-modal',
    '.fc-consent-root',
    '#cmpbox', '#cmpwrapper',
    '#tarteaucitronRoot',
    '.cookiefirst-root',
    '#moove_gdpr_cookie_info_bar',
  ];

  // Non-consent nags: these are simply hidden
  const NAG_CONTAINERS = [
    '.newsletter-popup', '.newsletter-modal', '#newsletter-popup', '#newsletter-modal',
  ];

  // Backdrops that CMPs put behind their dialogs
  const OVERLAY_SELECTORS = [
    '.onetrust-pc-dark-filter', '#CybotCookiebotDialogBodyUnderlay', '.didomi-popup-backdrop',
    '.cky-overlay', '.cmplz-soft-cookiewall', '.fc-dialog-overlay', '.truste_overlay',
    '[id^="sp_message_container"]',
  ];

  // Shadow hosts used by CMPs
  const SHADOW_HOSTS = ['#usercentrics-root', '#usercentrics-cmp-ui', '#cmpwrapper', '.cookiefirst-root'];

  // Frames served by CMP vendors: everything in them is consent UI
  const CMP_FRAME_HOST = /(privacy-mgmt\.com|sourcepoint|consentmanager\.(net|de)|cookielaw\.org|onetrust|trustarc\.com|truste\.com|usercentrics|cookiebot|quantcast|didomi|consensu\.org|fundingchoicesmessages\.google\.com)/i;
  const inCmpFrame = !isTopFrame && CMP_FRAME_HOST.test(window.location.hostname);

  // ========== TEXT CLASSIFICATION ==========
  // Hard accept: never clicked under any circumstance.
  const ACCEPT_ALL_RE = [
    /\baccept\s+(all|everything|cookies|and\s+(close|continue))\b/,
    /\ballow\s+(all|everything|cookies)\b/,
    /\bagree\s+(to\s+all|and\s+(close|continue)|&)/,
    /\b(ok|okay)\s+(to|for)\s+all\b/,
    /\balle\s+(akzeptieren|annehmen|zulassen|erlauben|cookies\s+akzeptieren)\b/,
    /\btout\s+(accepter|autoriser)\b/,
    /\baccepter\s+(tout|et\s+(fermer|continuer))\b/,
    /\baceptar\s+(todo|todas|todos|y\s+(cerrar|continuar))\b/,
    /\bpermitir\s+(todo|todas)\b/,
    /\baccetta\s+(tutto|tutti|e\s+(chiudi|continua))\b/,
    /\bconsenti\s+(tutto|tutti)\b/,
  ];
  // Phrases that decline even though they contain an accept word
  const NEGATED_RE = [
    /\bcontinue\s+without\s+(accepting|agreeing|consent(ing)?)\b/,
    /\b(do\s+not|don'?t|i\s+do\s+not)\s+(consent|accept|agree)\b/,
    /\bnicht\s+(einwilligen|zustimmen|akzeptieren|einverstanden)\b/,
    /\bohne\s+(zustimmung|einwilligung|akzeptieren|zuzustimmen)\b/,
    /\bcontinuer\s+sans\s+accepter\b/,
    /\bne\s+pas\s+(consentir|accepter)\b/,
    /\bcontinuar\s+sin\s+aceptar\b/,
    /\bno\s+(consentir|acepto|aceptar)\b/,
    /\bcontinua\s+senza\s+accettare\b/,
    /\bnon\s+(acconsento|accetto|accettare)\b/,
  ];
  const ONLY_NECESSARY_RE = [
    /\bonly\s+(strictly\s+)?(necessary|essential|required)\b/,
    /\b(strictly\s+)?(necessary|essential|required)(\s+cookies)?\s+only\b/,
    /\buse\s+(only\s+)?(strictly\s+)?necessary\s+cookies\b/,
    /\bnur\s+(technisch\s+)?(notwendige|erforderliche|essenzielle|essentielle|notwendigen|erforderlichen|essenziellen)\b/,
    /\buniquement\s+(les\s+)?(cookies\s+)?(n[ée]cessaires|essentiels|strictement)\b/,
    /\bs[oó]lo\s+(las\s+)?(cookies\s+)?(necesarias|esenciales|t[ée]cnicas)\b/,
    /\bsolo\s+(i\s+)?(cookie\s+)?(necessari[eo]?|essenziali|tecnici)\b/,
  ];
  const ALL_WORD_RE = /\b(all|alle|tout|tous|todo|todas|todos|tutto|tutti|tutte)\b/;
  const ACCEPT_WORD_RE = /\b(accept|agree|allow|consent|ok|okay|got\s+it|understood|akzeptieren|annehmen|zustimmen|einverstanden|erlauben|zulassen|accepter|j'accepte|autoriser|aceptar|acepto|permitir|accetta|accetto|consenti|acconsento)\b/;
  const REJECT_RE = [
    /\breject(\s+all)?\b/,
    /\bdecline(\s+all)?\b/,
    /\bdeny(\s+all)?\b/,
    /\brefuse(\s+all)?\b/,
    /\bdisagree\b/,
    /\bopt[\s-]?out\b/,
    /\brequired\s+only\b/,
    /\bno,?\s+thanks\b/,
    /\balle\s+ablehnen\b/,
    /\bablehnen\b/,
    /\bverweigern\b/,
    /\btout\s+refuser\b/,
    /\brefuser\b/,
    /\bje\s+refuse\b/,
    /\brechazar\b/,
    /\bdenegar\b/,
    /\brifiuta\b/,
    /\brifiutare\b/,
  ];

  function normText(el) {
    let t = '';
    if (el.tagName === 'INPUT') t = el.value || '';
    else t = el.textContent || '';
    if (!t.trim()) t = el.getAttribute('aria-label') || el.getAttribute('title') || '';
    return t.toLowerCase().replace(/[’`]/g, "'").replace(/[×✕✖]/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function matchesAny(list, t) {
    return list.some((re) => re.test(t));
  }

  // 'accept' | 'reject' | 'neutral'
  function classify(t) {
    if (!t || t.length > 80) return 'neutral';
    if (matchesAny(ACCEPT_ALL_RE, t)) return 'accept';
    if (matchesAny(NEGATED_RE, t)) return 'reject';
    if (matchesAny(ONLY_NECESSARY_RE, t)) {
      return ACCEPT_WORD_RE.test(t) && ALL_WORD_RE.test(t) ? 'accept' : 'reject';
    }
    if (ACCEPT_WORD_RE.test(t)) return 'accept';
    if (matchesAny(REJECT_RE, t)) return 'reject';
    return 'neutral';
  }

  const MANAGE_RE = /\b(manage|customi[sz]e|settings|preferences|options|more\s+options|configure|let\s+me\s+choose|einstellungen|anpassen|optionen|verwalten|pr[äa]ferenzen|param[ée]trer|param[eè]tres|personnaliser|g[ée]rer|pr[ée]f[ée]rences|configurar|gestionar|personalizar|preferencias|opciones|ajustes|impostazioni|personalizza|gestisci|preferenze|opzioni)\b/;
  const SAVE_RE = [
    /\b(save|confirm|submit)\b.{0,20}\b(choices?|preferences|settings|selection|exit|close)\b/,
    /^(save|confirm|done)$/,
    /\bauswahl\s+(speichern|best[äa]tigen)\b/,
    /\b(einstellungen|pr[äa]ferenzen)\s+speichern\b/,
    /^speichern(\s+und\s+schlie(ß|ss)en)?$/,
    /\benregistrer\b/,
    /\bconfirmer\s+(mes\s+)?choix\b/,
    /^valider(\s+mes\s+choix)?$/,
    /\bguardar\b/,
    /\bconfirmar\s+(mis\s+)?(preferencias|selecci[oó]n|elecciones)\b/,
    /\bsalva\b/,
    /\bconferma\s+(le\s+)?(scelte|preferenze|selezione)\b/,
  ];
  const SAVE_SELECTORS = [
    '.save-preference-btn-handler', // OneTrust "Confirm my choices"
  ];
  const ALWAYS_ACTIVE_RE = /(always\s+active|immer\s+aktiv|toujours\s+actif|siempre\s+activ[oa]s?|sempre\s+attiv[oi])/;

  // ========== DOM HELPERS ==========
  const CLICKABLE = 'button, a, [role="button"], input[type="button"], input[type="submit"]';

  function getShadowRoots() {
    const roots = [];
    const seen = new Set();
    const add = (el) => {
      if (el && el.shadowRoot && !seen.has(el.shadowRoot)) {
        seen.add(el.shadowRoot);
        roots.push(el.shadowRoot);
      }
    };
    for (const sel of SHADOW_HOSTS) {
      try { document.querySelectorAll(sel).forEach(add); } catch (e) { /* skip */ }
    }
    if (document.body) for (const el of document.body.children) add(el);
    for (const el of document.documentElement.children) add(el);
    // one level of nesting inside CMP shadow roots
    for (const root of roots.slice()) {
      for (const el of root.querySelectorAll('*')) add(el);
    }
    return roots;
  }

  function deepQueryAll(sel, roots) {
    const out = [];
    try { out.push(...document.querySelectorAll(sel)); } catch (e) { return out; }
    for (const r of roots) {
      try { out.push(...r.querySelectorAll(sel)); } catch (e) { /* skip */ }
    }
    return out;
  }

  function parentOf(node) {
    if (node.parentElement) return node.parentElement;
    const p = node.parentNode;
    return p && p.host ? p.host : null; // cross a shadow boundary
  }

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function navigatesAway(el) {
    if (el.tagName !== 'A') return false;
    const href = (el.getAttribute('href') || '').trim();
    if (!href || href.startsWith('#') || href.toLowerCase().startsWith('javascript:')) return false;
    return true;
  }

  const CONSENT_WORD_RE = /cookie|consent|gdpr|cmpbox|cmpwrapper|qc-cmp|sd-cmp|privacy|onetrust|optanon|didomi|osano|cybot|cookiebot|qc-cmp|truste|usercentrics|iubenda|klaro|cmplz|complianz|borlabs|brlbs|cky-|termly|sp_message|tarteaucitron|cc-window|cc-banner|fc-consent|datenschutz|moove_gdpr/;
  const CONSENT_TEXT_RE = /cookie|consent|gdpr|privacy|tracking|datenschutz|einwilligung|zustimmung|confidentialit[ée]|consentement|traceurs|privacidad|consentimiento|riservatezza|consenso/i;

  function idClass(node) {
    const cls = typeof node.className === 'string' ? node.className : (node.getAttribute && node.getAttribute('class')) || '';
    return ((node.id || '') + ' ' + cls).toLowerCase();
  }

  function isOverlayish(node) {
    if (!node.getAttribute) return false;
    if (node.tagName === 'DIALOG' || node.getAttribute('role') === 'dialog' || node.getAttribute('role') === 'alertdialog' || node.getAttribute('aria-modal') === 'true') return true;
    const pos = window.getComputedStyle(node).position;
    return pos === 'fixed' || pos === 'sticky';
  }

  // Returns the consent dialog box (innermost fixed/sticky/dialog ancestor that
  // is about cookies/consent) containing el, or null. Page content that is not an
  // overlay never qualifies, so Hush does not press buttons in normal page UI.
  function consentRootOf(el) {
    if (inCmpFrame) return document.body || document.documentElement;
    let node = parentOf(el);
    let depth = 0;
    let keyword = false;
    const overlays = [];
    while (node && node !== document.body && node !== document.documentElement && depth < 25) {
      if (!keyword && CONSENT_WORD_RE.test(idClass(node))) keyword = true;
      if (isOverlayish(node)) overlays.push(node);
      node = parentOf(node);
      depth++;
    }
    for (const o of overlays) {
      const text = o.textContent || '';
      if (text.length > 6000) continue; // an app shell, not a banner
      if (keyword || CONSENT_TEXT_RE.test(text)) return o;
    }
    return null;
  }

  function containsDeep(container, el) {
    let node = el;
    while (node) {
      if (node === container) return true;
      node = parentOf(node);
    }
    return false;
  }

  // ========== ACTIONS ==========
  const clicked = new WeakSet();
  let actions = 0;
  const MAX_ACTIONS = 6;
  let cooldownUntil = 0;
  let reported = false;
  let manageState = 'idle'; // idle | running | done
  const firstSeen = new WeakMap();
  const hidden = new WeakSet();

  function click(el) {
    clicked.add(el);
    actions++;
    cooldownUntil = Date.now() + 800;
    try { el.click(); } catch (e) { /* ignore */ }
  }

  function report(method) {
    if (reported) return;
    reported = true;
    try {
      chrome.runtime.sendMessage({ type: 'POPUP_BLOCKED', method });
    } catch (e) { /* context invalidated */ }
  }

  function canClick(el) {
    return el && !clicked.has(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true' && isVisible(el);
  }

  // Step 1: known CMP reject controls
  function findKnownReject(roots) {
    for (const { sel, textCheck } of REJECT_SELECTORS) {
      for (const el of deepQueryAll(sel, roots)) {
        if (!canClick(el)) continue;
        const kind = classify(normText(el));
        if (kind === 'accept') continue;
        if (textCheck && kind !== 'reject') continue;
        return el;
      }
    }
    return null;
  }

  // Step 2: any clickable in consent UI whose label is a reject phrase
  function findTextReject(roots) {
    const candidates = deepQueryAll(CLICKABLE, roots);
    for (const el of candidates) {
      if (classify(normText(el)) !== 'reject') continue;
      if (!canClick(el) || navigatesAway(el)) continue;
      if (consentRootOf(el)) return el;
    }
    return null;
  }

  function visibleContainers(roots) {
    const out = [];
    for (const sel of CONSENT_CONTAINERS) {
      for (const el of deepQueryAll(sel, roots)) {
        if (!hidden.has(el) && isVisible(el) && !out.some((o) => o.contains(el))) out.push(el);
      }
    }
    // Custom banners: the consent box around any visible accept-style button
    for (const el of deepQueryAll(CLICKABLE, roots)) {
      const t = normText(el);
      if (!t || t.length > 50 || classify(t) !== 'accept' || !isVisible(el)) continue;
      const root = consentRootOf(el);
      if (root && root !== document.body && !hidden.has(root) && isVisible(root) &&
          !out.some((o) => containsDeep(o, root) || containsDeep(root, o))) {
        out.push(root);
      }
    }
    if (inCmpFrame && document.body && isVisible(document.body) && !out.length) out.push(document.body);
    return out;
  }

  function findManageButton(roots, containers) {
    const inside = (el) => containers.some((c) => containsDeep(c, el));
    for (const el of deepQueryAll(CLICKABLE, roots)) {
      const t = normText(el);
      if (!t || t.length > 50 || classify(t) !== 'neutral' || !MANAGE_RE.test(t)) continue;
      if (!canClick(el) || navigatesAway(el)) continue;
      if (inside(el)) return el;
    }
    // OneTrust / Cookiebot specific settings buttons
    for (const sel of ['#onetrust-pc-btn-handler', '#CybotCookiebotDialogBodyLevelButtonCustomize', '#truste-show-consent', '.fc-cta-manage-options', '#didomi-notice-learn-more-button', '.cky-btn-customize', '.cmplz-manage-options']) {
      for (const el of deepQueryAll(sel, roots)) {
        if (canClick(el) && classify(normText(el)) !== 'accept' && inside(el)) return el;
      }
    }
    return null;
  }

  function findSaveButton(roots) {
    for (const el of deepQueryAll(CLICKABLE + ', ' + SAVE_SELECTORS.join(', '), roots)) {
      const t = normText(el);
      if (!t || t.length > 60 || classify(t) === 'accept' || !(matchesAny(SAVE_RE, t) || el.matches(SAVE_SELECTORS.join(', ')))) continue;
      if (!canClick(el) || navigatesAway(el)) continue;
      if (consentRootOf(el)) return el;
    }
    return null;
  }

  // Uncheck every optional toggle inside the consent UI
  function uncheckOptional(scopeRoots) {
    let n = 0;
    for (const scope of scopeRoots) {
      const inputs = scope.querySelectorAll('input[type="checkbox"], [role="switch"], [role="checkbox"]');
      for (const el of inputs) {
        const isInput = el.tagName === 'INPUT';
        const on = isInput ? el.checked : el.getAttribute('aria-checked') === 'true';
        if (!on) continue;
        if ((isInput && (el.disabled || el.required)) || el.getAttribute('aria-disabled') === 'true') continue;
        const row = el.closest('li, tr, label, [class*="category"], [class*="purpose"], [class*="item"]') || el.parentElement;
        if (row && ALWAYS_ACTIVE_RE.test((row.textContent || '').toLowerCase())) continue;
        try { el.click(); } catch (e) { /* ignore */ }
        if (isInput && el.checked) {
          el.checked = false;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
        }
        n++;
      }
    }
    return n;
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  // Step 3: open "Manage options", decline there. One attempt per page.
  async function runManageFlow(manageBtn) {
    manageState = 'running';
    click(manageBtn);
    try {
      for (let i = 0; i < 20; i++) {
        await sleep(250);
        const roots = getShadowRoots();
        const reject = findKnownReject(roots) || findTextReject(roots);
        if (reject) {
          click(reject);
          report('declined');
          return;
        }
        const save = findSaveButton(roots);
        if (save) {
          const scopes = new Set();
          const r = consentRootOf(save);
          if (r) scopes.add(r);
          for (const c of visibleContainers(roots)) scopes.add(c);
          for (const sr of roots) scopes.add(sr);
          uncheckOptional([...scopes]);
          await sleep(150);
          click(save);
          report('declined');
          return;
        }
      }
    } finally {
      manageState = 'done';
    }
  }

  // Step 4: hide banner + overlay and unlock scrolling, without consenting
  function hideConsent(el, method) {
    hidden.add(el);
    el.style.setProperty('display', 'none', 'important');
    for (const sel of OVERLAY_SELECTORS) {
      try {
        document.querySelectorAll(sel).forEach((o) => {
          if (isVisible(o)) { hidden.add(o); o.style.setProperty('display', 'none', 'important'); }
        });
      } catch (e) { /* skip */ }
    }
    // Full-viewport translucent backdrops next to the banner
    const parent = parentOf(el);
    if (parent) {
      for (const sib of parent.children) {
        if (sib === el) continue;
        const s = window.getComputedStyle(sib);
        if (s.position === 'fixed' && sib.offsetWidth >= window.innerWidth * 0.9 && sib.offsetHeight >= window.innerHeight * 0.9 &&
            (parseFloat(s.opacity) < 1 || /rgba\(.*,\s*0?\.\d+\)/.test(s.backgroundColor))) {
          hidden.add(sib);
          sib.style.setProperty('display', 'none', 'important');
        }
      }
    }
    restoreScroll();
    report(method);
  }

  function restoreScroll() {
    for (const el of [document.documentElement, document.body]) {
      if (!el) continue;
      const s = window.getComputedStyle(el);
      if (s.overflow === 'hidden' || s.overflowY === 'hidden') {
        el.style.setProperty('overflow', 'auto', 'important');
        el.style.setProperty('overflow-y', 'auto', 'important');
      }
      if (el === document.body && el.style.position === 'fixed') {
        el.style.removeProperty('position');
        el.style.removeProperty('top');
      }
    }
  }

  // ========== SCAN LOOP ==========
  function scan() {
    if (!isActive()) return;
    if (Date.now() < cooldownUntil || manageState === 'running') return;
    const roots = getShadowRoots();

    if (actions < MAX_ACTIONS) {
      // 1 + 2: reject control
      const reject = findKnownReject(roots) || findTextReject(roots);
      if (reject) {
        click(reject);
        report('declined');
        return;
      }
    }

    const containers = visibleContainers(roots);
    const now = Date.now();

    // 3: manage options -> uncheck -> save (once per page)
    if (containers.length && manageState === 'idle' && actions < MAX_ACTIONS) {
      const manage = findManageButton(roots, containers);
      if (manage) {
        runManageFlow(manage);
        return;
      }
    }

    // 4: hide whatever consent UI is still showing after a grace period
    for (const c of containers) {
      if (!firstSeen.has(c)) firstSeen.set(c, now);
      // Give CMP iframes time to decline from inside before hiding their host
      const grace = c.querySelector && c.querySelector('iframe') ? 5000 : 2500;
      if (now - firstSeen.get(c) >= grace || actions >= MAX_ACTIONS) {
        if (c === document.body) continue; // never hide a whole frame body
        hideConsent(c, 'hidden');
      }
    }

    // Newsletter nags: hide right away
    for (const sel of NAG_CONTAINERS) {
      for (const el of document.querySelectorAll(sel)) {
        if (!hidden.has(el) && isVisible(el)) hideConsent(el, 'hidden');
      }
    }
  }

  let scheduled = null;
  function scheduleScan(delay = 300) {
    if (scheduled) return;
    scheduled = setTimeout(() => {
      scheduled = null;
      scan();
    }, delay);
  }

  function startHush() {
    if (started) return;
    started = true;
    setTimeout(scan, 500);
    setTimeout(scan, 1500);
    setTimeout(scan, 3000);
    setTimeout(scan, 6000);
    // Keep polling briefly so grace-period hiding happens even on quiet pages
    let ticks = 0;
    const iv = setInterval(() => {
      scan();
      if (++ticks >= 20) clearInterval(iv);
    }, 1000);

    const observer = new MutationObserver(() => scheduleScan());
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
})();
